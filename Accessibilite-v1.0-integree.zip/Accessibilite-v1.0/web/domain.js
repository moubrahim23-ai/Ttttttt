'use strict';
(function(root){
 const localDay=d=>{d=new Date(d);return Number.isNaN(+d)?'':`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;};
 const limits={1:7,2:3,3:5,4:2,5:4,6:3,8:2,9:9,10:11};
 const criteria=Object.entries(limits).flatMap(([theme,n])=>Array.from({length:n},(_,i)=>`${theme}.${i+1}`));
 const source='https://accessibilite.public.lu/fr/rapdf1.1/referentiel-technique.html';
 const min=t=>{const [h,m]=t.split(':').map(Number);return h*60+m;};
 function rule(config,day){const d=new Date(day+'T12:00:00');return [0,6].includes(d.getDay())||(config.holidays||[]).includes(day)?null:config.hours[d.getDay()===5?'friday':'standard'];}
 function businessAfter(day,count,config){let d=new Date(day+'T12:00:00');if(Number.isNaN(+d))return '';let guard=0;while(count>0&&guard++<3700){d.setDate(d.getDate()+1);if(rule(config,localDay(d)))count--;}return count?'':localDay(d);}
 function mergedMinutes(intervals,start,end){const rows=intervals.map(x=>[Math.max(start,x[0]),Math.min(end,x[1])]).filter(x=>x[1]>x[0]).sort((a,b)=>a[0]-b[0]);let total=0,right=start;for(const [a,b] of rows){total+=Math.max(0,b-Math.max(a,right));right=Math.max(right,b);}return total;}
 function capacity(config,absences,owner,day){const r=rule(config,day);if(!r)return {theoretical:0,unavailable:0,available:0};const start=min(r.start),end=min(r.end),gross=end-start;
  // Pause/déjeuner sans créneau précis : disponibilité prudente, clairement estimative.
  const unavailable=mergedMinutes(absences.filter(a=>a.owner===owner&&a.day===day&&a.status==='Validée').map(a=>[a.start,a.end]),start,end);
  const theoretical=Math.max(0,gross-r.pauseMinutes-r.lunchMinutes);return {theoretical,unavailable,available:Math.max(0,theoretical-unavailable)};
 }
 function inPeriod(at,from,to){const day=at?localDay(at):'';return !!day&&(!from||day>=from)&&(!to||day<=to);}
 function effectiveDue(d,ops){const p=(ops.plans||[]).find(p=>p.id===d.id);return p?.due||(ops.lots||[]).find(l=>l.id===p?.lot)?.due||'';}
 function reminderDue(d,state){if(d.status!=='NON CONFORME')return '';const block=state.events.filter(e=>e.document===d.id&&e.action==='BLOCK').slice(-1)[0];const sent=(state.operations?.reminders||[]).filter(r=>r.document===d.id&&(!block||new Date(r.at)>=new Date(block.at))).slice(-1)[0];return businessAfter(localDay(sent?.at||block?.at||d.received),2,state.config);}
 function report(state,filter={}){
  const match=d=>!!d&&(!filter.entity||d.entity===filter.entity)&&(!filter.owner||d.owner===filter.owner)&&(!filter.nature||d.nature===filter.nature);
  const hasPdf=d=>!d.sourceFiles||[...(d.sourceFiles||[]),...(d.finalFiles||[])].some(f=>String(f.ext||f.name).toLowerCase().endsWith('.pdf'));
  const rows=state.docs.filter(match).filter(d=>(filter.examples||d.physical)&&hasPdf(d));
  const ids=new Set(rows.map(d=>d.id));
  const closes=state.events.filter(e=>{const d=e.after||state.docs.find(d=>d.id===e.document);return ['CLOSE','CLOTURE_ET_REPUBLICATION_ACM'].includes(e.action)&&inPeriod(e.at,filter.from,filter.to)&&match(d)&&(filter.examples||d.physical)&&hasPdf(d);});
  const statuses=['A TRAITER','EN COURS','NON CONFORME','TRAITES'];
  const stocks=Object.fromEntries(statuses.map(s=>[s,rows.filter(d=>d.status===s).length]));
  return {rows,stocks,received:rows.filter(d=>inPeriod(d.received,filter.from,filter.to)).length,initial:closes.filter(e=>!(e.after?.reworks)).length,reworks:closes.filter(e=>e.after?.reworks>0).length,closes,published:rows.filter(d=>d.status==='TRAITES'&&d.published).length,unknownReceived:rows.filter(d=>!d.received).length,unknownNature:rows.filter(d=>!d.nature).length};
 }
 const safeCell=v=>{let s=String(v??'');return /^[\s]*[=+@-]/.test(s)?"'"+s:s;};
 const csv=rows=>'\ufeff'+rows.map(row=>row.map(v=>'"'+safeCell(v).replace(/"/g,'""')+'"').join(';')).join('\r\n');
 const xmlEsc=s=>String(s??'').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
 function excel(sheets){return '<?xml version="1.0" encoding="UTF-8"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">'+sheets.map(s=>'<Worksheet ss:Name="'+xmlEsc(s.name)+'"><Table>'+s.rows.map(r=>'<Row>'+r.map(c=>'<Cell><Data ss:Type="String">'+xmlEsc(c)+'</Data></Cell>').join('')+'</Row>').join('')+'</Table></Worksheet>').join('')+'</Workbook>';}
 function quality(answers){const count=Object.fromEntries(['C','NC','NA','NE'].map(k=>[k,answers.filter(a=>a.result===k).length]));const applicable=count.C+count.NC;return {...count,rate:applicable?Math.round(100*count.C/applicable):null,complete:answers.length===46&&count.NE===0&&!answers.some(a=>a.result==='NC'&&!a.note.trim())};}
 const api={localDay,criteria,source,rule,businessAfter,mergedMinutes,capacity,inPeriod,effectiveDue,reminderDue,report,csv,excel,quality};
 if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.AccDomain=api;
})(typeof globalThis!=='undefined'?globalThis:this);
