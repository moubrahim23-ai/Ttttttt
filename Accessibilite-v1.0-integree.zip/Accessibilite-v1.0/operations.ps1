﻿# Pilotage additionnel : toutes les écritures passent par la transaction du serveur.
function Ensure-Operations {
    if(-not $script:state.PSObject.Properties['operations']){
        $script:state|Add-Member -NotePropertyName operations -NotePropertyValue ([pscustomobject]@{version=0;plans=@();lots=@();contacts=@();reminders=@();absences=@();reviews=@()})
    }
}
function Ops-Text($value,$limit=500,$required=$false){
    $s=([string]$value).Trim()
    if($s.Length -gt $limit -or ($required -and -not $s)){throw "Texte requis ou trop long (maximum $limit caractères)"}
    return $s
}
function Ops-Date($value){
    $s=[string]$value;$dt=[datetime]::MinValue
    if(-not [datetime]::TryParseExact($s,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$dt)){throw 'Date attendue au format AAAA-MM-JJ'}
    return $s
}
function Ops-Emails($value){
    $text=Ops-Text $value 1000
    foreach($address in @($text -split ';'|Where-Object {$_})){if($address.Trim() -notmatch '^[^\s<>;,]+@[^\s<>;,]+\.[^\s<>;,]+$'){throw 'Adresses email invalides ; séparer par des points-virgules'}}
    return $text
}
function Ops-Criteria {
    $limits=@{1=7;2=3;3=5;4=2;5=4;6=3;8=2;9=9;10=11}
    foreach($theme in @($limits.Keys|Sort-Object)){foreach($n in 1..$limits[$theme]){"$theme.$n"}}
}
function Ops-Week($date){
    $d=([datetime]$date).Date;$shift=(([int]$d.DayOfWeek+6)%7)
    return $d.AddDays(-$shift).ToString('yyyy-MM-dd')
}
function Operations-Request($p){
    $script:actor=[string]$p.actor
    if(@($script:state.config.users|Where-Object {$_.id -eq $script:actor -and $_.active}).Count -ne 1){throw 'Compte inconnu ou inactif'}
    Ensure-Operations;$o=$script:state.operations
    if($null -eq $p.opsVersion -or [int]$p.opsVersion -ne [int]$o.version){throw 'Le pilotage a changé. Actualisez puis recommencez.'}
    $manager=Is-Manager $script:actor;$op=([string]$p.action).Substring(4)
    if($op -notin @('absence','review-reply') -and -not $manager){throw 'Action réservée au manager ou suppléant'}
    $before=$o|ConvertTo-Json -Depth 25;$document='';$now=[DateTimeOffset]::Now.ToString('o')
    switch($op){
        'plan' {
            $d=@($script:state.docs|Where-Object id -eq $p.id);if($d.Count -ne 1){throw 'Document introuvable'}
            $document=$d[0].id;$due='';if($p.due){$due=Ops-Date $p.due}
            $lot=Ops-Text $p.lot 80;if($lot -and @($o.lots|Where-Object id -eq $lot).Count -ne 1){throw 'Lot inconnu'}
            $remaining=$null;if($null -ne $p.remaining -and [string]$p.remaining -ne ''){$remaining=Config-Integer $p.remaining 0 60000 'Reste estimé'}
            $row=[pscustomobject]@{id=$document;due=$due;lot=$lot;remaining=$remaining;note=(Ops-Text $p.note);at=$now;actor=$script:actor}
            $o.plans=@($o.plans|Where-Object id -ne $document)+@($row)
        }
        'lot' {
            $id=Ops-Text $p.id 80 $true;$due=Ops-Date $p.due
            $row=[pscustomobject]@{id=$id;due=$due;note=(Ops-Text $p.note);at=$now;actor=$script:actor}
            $o.lots=@($o.lots|Where-Object id -ne $id)+@($row)
        }
        'contact' {
            if($p.entity -notin @($script:state.config.entities.id)){throw 'Entité inconnue'}
            $row=[pscustomobject]@{entity=[string]$p.entity;to=(Ops-Emails $p.to);cc=(Ops-Emails $p.cc)}
            $o.contacts=@($o.contacts|Where-Object entity -ne $p.entity)+@($row)
        }
        'reminder' {
            $d=@($script:state.docs|Where-Object {$_.id -eq $p.id -and $_.status -eq 'NON CONFORME'})
            if($d.Count -ne 1){throw 'La relance concerne uniquement un document non conforme'}
            if($p.confirm -ne $true){throw 'Confirmez que le message a réellement été envoyé'}
            $document=$d[0].id;$reference=Ops-Text $p.note 500 $true
            $o.reminders+=@([pscustomobject]@{id=[Guid]::NewGuid().ToString('N');document=$document;at=$now;actor=$script:actor;reference=$reference})
        }
        'absence' {
            $owner=$script:actor;if($manager){$owner=[string]$p.owner}
            if($owner -notin @(Active-Collaborators)){throw 'Collaborateur invalide'}
            $day=Ops-Date $p.day;$start=Minute-OfDay ([string]$p.start);$end=Minute-OfDay ([string]$p.end)
            if($end -le $start){throw 'Fin nécessairement après le début'}
            if($p.kind -notin @('Absence','Réunion','Formation')){throw 'Type indisponibilité invalide'}
            $o.absences+=@([pscustomobject]@{id=[Guid]::NewGuid().ToString('N');owner=$owner;day=$day;start=$start;end=$end;kind=[string]$p.kind;note=(Ops-Text $p.note);status=$(if($manager){'Validée'}else{'À valider'});actor=$script:actor;at=$now})
        }
        'absence-decision' {
            $a=@($o.absences|Where-Object id -eq $p.id);if($a.Count -ne 1){throw 'Indisponibilité introuvable'}
            if($p.status -notin @('Validée','Refusée','Annulée')){throw 'Décision invalide'}
            $a[0].status=[string]$p.status;$a[0]|Add-Member -NotePropertyName decision -NotePropertyValue ([pscustomobject]@{actor=$script:actor;at=$now;note=(Ops-Text $p.note 500 $true)}) -Force
        }
        'review-draw' {
            $week=Ops-Week (Get-Date)
            foreach($owner in @(Active-Collaborators)){
                if(@($o.reviews|Where-Object {$_.owner -eq $owner -and $_.week -eq $week}).Count){continue}
                $used=@($o.reviews|ForEach-Object {$_.document+'|'+$_.finished})
                $candidates=@($script:state.docs|Where-Object {$_.owner -eq $owner -and $_.status -eq 'TRAITES' -and $_.finished -and ($_.id+'|'+$_.finished) -notin $used})
                if(-not $candidates.Count){Event 'QUALITE_SANS_CANDIDAT' '' $owner;continue}
                $recent=@($candidates|Where-Object {([datetimeoffset]$_.finished).LocalDateTime.Date -ge [datetime]$week})
                if($recent.Count){$candidates=$recent};$d=$candidates|Get-Random
                $answers=@(Ops-Criteria|ForEach-Object {[pscustomobject]@{id=$_;result='NE';note=''}})
                $o.reviews+=@([pscustomobject]@{id=[Guid]::NewGuid().ToString('N');document=$d.id;owner=$owner;week=$week;finished=$d.finished;sourceVersion=$d.sourceVersion;finalFiles=$d.finalFiles;snapshot=($d|ConvertTo-Json -Depth 15|ConvertFrom-Json);reference='RAPDF 1.1';status='Brouillon';answers=$answers;history=@();replies=@();at=$now;finalizedAt=$null})
            }
        }
        'review-save' {
            $r=@($o.reviews|Where-Object id -eq $p.id);if($r.Count -ne 1){throw 'Évaluation introuvable'};$r=$r[0]
            if($r.status -eq 'Finalisée'){throw 'Ouvrez une révision motivée avant de modifier une évaluation finalisée'}
            $ids=@(Ops-Criteria);$answers=@($p.answers)
            if($answers.Count -ne $ids.Count -or @($answers.id|Select-Object -Unique).Count -ne $ids.Count){throw 'Tous les critères doivent être présents une seule fois'}
            $clean=@();foreach($a in $answers){
                if($a.id -notin $ids -or $a.result -notin @('C','NC','NA','NE')){throw 'Critère ou résultat invalide'}
                $note=Ops-Text $a.note 1000
                if($p.finalize -eq $true -and ($a.result -eq 'NE' -or ($a.result -eq 'NC' -and -not $note))){throw 'Finalisation impossible : critères non évalués ou non-conformités sans observation'}
                $clean+=@([pscustomobject]@{id=[string]$a.id;result=[string]$a.result;note=$note})
            }
            $r.answers=$clean
            if($p.finalize -eq $true){$r.status='Finalisée';$r.finalizedAt=$now}
            $r.history+=@([pscustomobject]@{at=$now;actor=$script:actor;status=$r.status;answers=($clean|ConvertTo-Json -Depth 10|ConvertFrom-Json)})
            $document=$r.document
        }
        'review-reopen' {
            $r=@($o.reviews|Where-Object id -eq $p.id);if($r.Count -ne 1 -or $r[0].status -ne 'Finalisée'){throw 'Évaluation finalisée requise'}
            $note=Ops-Text $p.note 1000 $true;$r[0].status='Brouillon';$r[0].replies+=@([pscustomobject]@{at=$now;actor=$script:actor;kind='Révision ouverte';note=$note});$document=$r[0].document
        }
        'review-reply' {
            $r=@($o.reviews|Where-Object id -eq $p.id);if($r.Count -ne 1 -or $r[0].status -ne 'Finalisée'){throw 'Évaluation finalisée requise'}
            if($r[0].owner -ne $script:actor){throw 'Réponse réservée au collaborateur évalué'}
            if($p.kind -notin @('Pris connaissance','Demande de révision','Commentaire')){throw 'Réponse invalide'}
            $note=Ops-Text $p.note 1000 ($p.kind -ne 'Pris connaissance')
            $r[0].replies+=@([pscustomobject]@{at=$now;actor=$script:actor;kind=[string]$p.kind;note=$note});$document=$r[0].document
        }
        default {throw 'Opération pilotage inconnue'}
    }
    $o.version++;Event ('PILOTAGE_'+$op.ToUpperInvariant()) $document 'Modification du pilotage'
    $script:state.events[-1]|Add-Member -NotePropertyName before -NotePropertyValue ($before|ConvertFrom-Json)
    $script:state.events[-1]|Add-Member -NotePropertyName after -NotePropertyValue ($o|ConvertTo-Json -Depth 25|ConvertFrom-Json)
    Save-State
    if($op -eq 'review-save' -and $p.finalize -eq $true){
        try{$export=Review-Export $r;$r|Add-Member -NotePropertyName exportPath -NotePropertyValue $export -Force;Event 'ARCHIVE_EVALUATION_XLSX' $document $export}
        catch{$r|Add-Member -NotePropertyName exportError -NotePropertyValue $_.Exception.Message -Force;Event 'ECHEC_EXPORT_EVALUATION' $document $_.Exception.Message}
        Save-State
    }
}

