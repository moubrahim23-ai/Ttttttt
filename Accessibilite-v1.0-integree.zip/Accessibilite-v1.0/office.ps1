﻿# Exports natifs XLSX et brouillons Outlook. Aucune méthode Send n'est utilisée.
function Xlsx-Text($value){return [Security.SecurityElement]::Escape(([string]$value -replace '[\x00-\x08\x0B\x0C\x0E-\x1F]',''))}
function Write-Xlsx($sheets,$destination){
    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $dir=[IO.Path]::GetDirectoryName($destination);[IO.Directory]::CreateDirectory($dir)|Out-Null
    if(Test-Path -LiteralPath $destination){throw 'Cet export existe déjà'}
    $tmp=$destination+'.tmp';$stream=[IO.File]::Open($tmp,[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $zip=New-Object IO.Compression.ZipArchive($stream,[IO.Compression.ZipArchiveMode]::Create,$true)
    try{
        $contents='<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        $workbook='<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'
        $rels='<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';$entries=@{}
        $i=0
        foreach($sheet in $sheets){
            $i++;$name=Xlsx-Text $sheet.name
            $workbook+='<sheet name="'+$name+'" sheetId="'+$i+'" r:id="rId'+$i+'"/>'
            $rels+='<Relationship Id="rId'+$i+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet'+$i+'.xml"/>'
            $contents+='<Override PartName="/xl/worksheets/sheet'+$i+'.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            $xml=New-Object Text.StringBuilder;[void]$xml.Append('<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>')
            foreach($row in $sheet.rows){[void]$xml.Append('<row>');foreach($cell in $row){[void]$xml.Append('<c t="inlineStr"><is><t xml:space="preserve">'+(Xlsx-Text $cell)+'</t></is></c>')};[void]$xml.Append('</row>')};[void]$xml.Append('</sheetData></worksheet>')
            $entries['xl/worksheets/sheet'+$i+'.xml']=$xml.ToString()
        }
        $entries['[Content_Types].xml']=$contents+'</Types>';$entries['xl/workbook.xml']=$workbook+'</sheets></workbook>';$entries['xl/_rels/workbook.xml.rels']=$rels+'</Relationships>'
        $entries['_rels/.rels']='<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'
        foreach($path in $entries.Keys){$entry=$zip.CreateEntry($path);$writer=New-Object IO.StreamWriter($entry.Open(),[Text.UTF8Encoding]::new($false));try{$writer.Write($entries[$path])}finally{$writer.Dispose()}}
    }finally{$zip.Dispose();$stream.Dispose()}
    [IO.File]::Move($tmp,$destination)
}
function Review-Export($r){
    $date=[datetimeoffset]::Now;if($r.finalizedAt){$date=[datetimeoffset]::Parse([string]$r.finalizedAt)}
    $relative='Exports/Evaluations/'+$r.owner+'/'+$date.ToString('yyyy/MM')+'/Semaine-'+$r.week+'/'+$r.id+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8)+'.xlsx'
    $rows=@();$rows+=,@('Document',$r.snapshot.name);$rows+=,@('Agent',$r.owner);$rows+=,@('Référentiel','RAPDF 1.1');$rows+=,@('Évaluation',$r.id);$rows+=,@('État',$r.status);$rows+=,@('Critère','Résultat','Observation')
    foreach($a in $r.answers){$rows+=,@($a.id,$a.result,$a.note)}
    $history=@();$history+=,@('Date','Auteur','État','Résultats conservés')
    foreach($h in $r.history){$history+=,@($h.at,$h.actor,$h.status,($h.answers|ConvertTo-Json -Depth 10 -Compress))}
    foreach($h in $r.replies){$history+=,@($h.at,$h.actor,$h.kind,$h.note)}
    Write-Xlsx @([pscustomobject]@{name='Evaluation';rows=$rows},[pscustomobject]@{name='Historique';rows=$history}) (File-Path $relative)
    return $relative
}
function Office-Request($p){
    . (Join-Path $root 'operations.ps1');$script:actor=[string]$p.actor
    if(@($script:state.config.users|Where-Object {$_.id -eq $p.actor -and $_.active}).Count -ne 1){throw 'Compte inconnu'}
    if($p.action -eq 'office:review-export'){
        $r=@($script:state.operations.reviews|Where-Object id -eq $p.id)
        if($r.Count -ne 1 -or (-not (Is-Manager $p.actor) -and ($r[0].owner -ne $p.actor -or $r[0].status -ne 'Finalisée'))){throw 'Évaluation inaccessible'}
        $file=Review-Export $r[0];Event 'EXPORT_EVALUATION' $r[0].document $file;Save-State;return [pscustomobject]@{relative=$file}
    }
    if(-not (Is-Manager $p.actor)){throw 'Fonction réservée au manager'}
    if($p.action -eq 'office:report-export'){
        $rows=@();$rows+=,@('Document','Entité','Métier','Nature','Collaborateur','Statut','Premier dépôt','Dernière clôture','Reprises','Secondes cumulées')
        foreach($d in $script:state.docs){$rows+=,@($d.name,$d.entity,$d.shareOrigin.metier,$d.nature,$d.owner,$d.status,$d.received,$d.finished,$d.reworks,$d.seconds)}
        $events=@();$events+=,@('Date','Action','Document','Compte','Rôle','Motif')
        foreach($e in $script:state.events){$events+=,@($e.at,$e.action,$e.document,$e.account,$e.actor,$e.message)}
        $file='Exports/Reportings/'+[DateTime]::Now.ToString('yyyy/MM')+'/Production-'+[Guid]::NewGuid().ToString('N')+'.xlsx'
        Write-Xlsx @([pscustomobject]@{name='Documents';rows=$rows},[pscustomobject]@{name='Journal';rows=$events}) (File-Path $file)
        Event 'EXPORT_PRODUCTION' '' $file;Save-State;return [pscustomobject]@{relative=$file}
    }
    if($p.action -ne 'office:draft'){throw 'Opération Office inconnue'}
    if($p.confirm -ne $true){throw 'Confirmer la création du brouillon'}
    $to=Ops-Emails $p.to;$cc=Ops-Emails $p.cc;$subject=Ops-Text $p.subject 250 $true;$body=Ops-Text $p.body 10000 $true
    $attachment=$null
    if($p.attachment){$relative=[string]$p.attachment;if($relative -notmatch '^Exports/.+\.xlsx$'){throw 'Joindre uniquement un export de cette application'};$attachment=File-Path $relative;if(-not (Test-Path -LiteralPath $attachment -PathType Leaf)){throw 'Pièce jointe absente'}}
    if([IO.Path]::DirectorySeparatorChar -ne [char]92){throw 'Outlook nécessite une session Windows avec Outlook classique'}
    $outlook=$null;$mail=$null
    try{
        $outlook=New-Object -ComObject Outlook.Application;$mail=$outlook.CreateItem(0)
        $mail.To=$to;$mail.CC=$cc;$mail.Subject=$subject;$mail.Body=$body
        if($attachment){[void]$mail.Attachments.Add($attachment)}
        $mail.Save();$entry=[string]$mail.EntryID;$mail.Display()
        Event 'BROUILLON_OUTLOOK_CREE' '' ('Brouillon enregistré, non envoyé : '+$subject)
        $script:state.events[-1]|Add-Member -NotePropertyName outlookEntryId -NotePropertyValue $entry;Save-State
        return [pscustomobject]@{draft=$true;sent=$false}
    }finally{if($mail){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($mail)};if($outlook){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($outlook)}}
}
