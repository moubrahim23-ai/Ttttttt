# Accessibilité — livraison intégrée v1.0

Cette livraison regroupe le code de l’application. Aucun nouveau test, contrôle de syntaxe ou lancement de recette n’a été exécuté pour cette version, conformément à la demande de Mohammed. Le fonctionnement Windows, Outlook et multi-postes n’est donc pas certifié par cette livraison.

## Lancement

1. Extraire entièrement le ZIP dans un dossier local accessible en écriture.
2. Ouvrir `DEMARRER.cmd`.
3. Choisir **1** pour reprendre la démonstration locale, **2** pour utiliser un espace interne commun avec la session Windows.
4. Garder la fenêtre PowerShell ouverte pendant l’utilisation. L’application s’ouvre dans le navigateur sur `http://127.0.0.1:8090`.

PowerShell Windows 5.1, un navigateur récent et les autorisations habituelles de lecture/écriture sont nécessaires. Aucune installation Node, aucun droit administrateur et aucun contournement de la stratégie PowerShell ne sont prévus. La création de brouillons utilise Outlook classique installé sur le poste ; les autres fonctions n’en dépendent pas.

## Reprendre une installation existante

Fermer l’application et sa fenêtre PowerShell sur les postes concernés, puis remplacer les fichiers applicatifs et tout le dossier `web` par ceux de cette livraison. Conserver les répertoires `TEST-DATA`, `TEST-FILES`, `SAUVEGARDES`, `LOCAL-PENDING` et le fichier `poste.json`. Ne pas mélanger les scripts de versions différentes. Le nom historique `TEST-FILES` est conservé pour ne pas casser les données existantes.

Ne pas ouvrir un ancien programme sur des données déjà utilisées par cette version. La restauration des sauvegardes crée un autre dossier : elle ne remplace pas les données en place.

## Espace partagé

Chaque poste possède sa copie locale du programme. Le choix 2 demande un **dossier interne commun distinct des dépôts clients**, par exemple `\\serveur\partage-interne\PilotageAccessibilite`. Tous les postes doivent utiliser exactement le même dossier. Ce chemin et le port sont conservés dans `poste.json`, localement sur chaque poste.

Le premier lancement sur un dossier interne vide crée l’espace sans documents fictifs et inscrit le compte Windows courant comme manager. Ce manager configure ensuite les identifiants Windows exacts des collaborateurs et du suppléant dans **Paramètres**. Les identifiants initialement fournis pour l’équipe sont des valeurs à adapter aux comptes réels. Youssef reste à ajouter/activer lors de son intégration.

Les écritures sont sérialisées par un verrou de fichier et chaque action recharge l’état commun. Si un autre poste détient le verrou, l’action est refusée avec une invitation à actualiser ; elle n’est pas confirmée à tort. Les restrictions des utilisateurs dans l’application ne remplacent pas les droits Windows du partage : une personne ayant accès direct aux fichiers de données reste capable d’y accéder hors application.

## Parcours quotidien

1. **Paramètres** : collaborateurs, manager/suppléant, entités, horaires, jours fermés et estimations.
2. **Dossiers partagés** : enregistrer une racine par entité. La recherche descend dans tous les niveaux de sous-répertoires pour repérer PDF et Word. Historique et À publier sont distingués des quatre statuts de travail.
3. **Préparer l’import** d’un document À traiter : confirmer la source complète, renseigner le premier dépôt client, la nature et, si connus, le métier et la catégorie. Le PDF et le DOCX de même nom peuvent être associés. Un même chemin déjà importé est signalé.
4. **Documents** : un collaborateur prend en charge un document, le met en pause, reprend et renseigne son étape. Un seul document peut être actif par collaborateur. Le manager peut affecter et imposer une priorité.
5. Déposer le PDF final et la fiche d’audit XLSX ; ajouter le DOCX final si la source comportait un Word. Clôturer ensuite vers Traités, sans validation préalable obligatoire du manager.
6. En cas de blocage, passer en Non conforme avec motif. Le retour corrigé reçu par mail est importé sur la fiche existante : il devient une reprise, conserve le premier dépôt et archive la précédente version.
7. **Nouvelle version client** permet au manager de remplacer une source, y compris hors Non conforme, après mise en pause et avec un motif. Une éventuelle copie publiée est retirée de l’espace publié et archivée.

Les mouvements ont lieu dans l’espace interne `TEST-FILES`. Les répertoires clients sont consultés en lecture seule : cette version ne déplace pas leurs originaux et ne transforme pas automatiquement un fichier découvert en réception. Les Word `.doc` et `.docm` sont inventoriés ; seuls PDF et DOCX sont acceptés dans le workflow géré.

## Pilotage et qualité

**Pilotage et qualité** regroupe les filtres de période, les stocks, les réceptions, les clôtures initiales et reprises, les échéances par lot/document, les relances Non conforme après deux jours ouvrés, les disponibilités et les évaluations.

Les stocks sont une photographie actuelle. Les réceptions et clôtures portent sur la période filtrée. Le chronomètre cumulé d’une fiche n’est pas une DMT de la période. Les pauses sont déclenchées par le bouton Pause ; les temps de déjeuner et de pause prévus réduisent la capacité théorique, ils ne sont pas retirés une deuxième fois des temps réellement chronométrés.

Les contrôles utilisent les 46 numéros de critères actifs RAPDF 1.1, avec les valeurs conforme, non conforme, non applicable et non évalué. Le critère obsolète 7.1 est exclu. Les tests et exceptions normatifs se consultent dans le référentiel officiel : https://accessibilite.public.lu/fr/rapdf1.1/referentiel-technique.html. La fiche ne réalise pas un audit automatique du PDF.

Une finalisation exige une réponse pour chaque critère et une observation pour chaque non-conformité. L’agent peut prendre connaissance ou demander une révision ; le manager conserve les révisions. Un export XLSX est créé à la finalisation dans `TEST-FILES/Exports/Evaluations/<agent>/<année>/<mois>/Semaine-<lundi>/`. Il peut être recréé depuis la fiche si un export a échoué.

Un poste manager ouvert en mode Windows effectue un passage quotidien de tirage, sans deuxième évaluation pour un agent déjà tiré cette semaine, et un export quotidien de production. Le tirage manuel reste disponible. Sans candidat au moment du passage, le journal le signale et le passage du jour suivant pourra en trouver un. Une semaine sans document traité ne produit pas artificiellement une évaluation. Les règles de prime restent à confirmer ; aucun droit à prime n’est calculé. Les seuils et le nombre minimal de contrôles peuvent être renseignés avec leur référence société dans Imports et échanges. Le tableau mensuel indique ensuite le respect des paramètres, sans attribution de prime.

## Imports et échanges

Le classeur Excel consolidé peut contenir plusieurs feuilles. Choisir les colonnes de chacune, puis préparer les correspondances. La première ligne de chaque feuille doit contenir les en-têtes. Les formats PDF seuls sont retenus. Les homonymes sont signalés sans fusion ni suppression. Les valeurs originales, le fichier, la feuille, la ligne et l’empreinte sont conservés ; réimporter la même ligne du même fichier ne la duplique pas. Un fichier modifié a une autre empreinte et doit être rapproché explicitement.

Ces lignes historiques restent séparées du stock vivant : aucun fichier physique n’est inventé, aucune durée VBA n’est assimilée à du travail réel. Les dates importées sont conservées telles que présentées dans Excel. Les exports de correspondances permettent de poursuivre le rapprochement, y compris les lignes non visibles dans l’aperçu.

Les exports filtrés sont de véritables fichiers XLSX. L’export complet est archivé dans l’espace interne et peut être joint à un brouillon Outlook créé sur le poste. L’application appelle l’enregistrement et l’affichage du brouillon, jamais l’envoi. L’envoi effectif des relances doit être confirmé séparément dans le pilotage.

## Surveillance et interruptions

Les notifications Windows de changement déclenchent un inventaire en arrière-plan. Un passage périodique toutes les quinze minutes complète les notifications, notamment si elles ne fonctionnent pas sur le réseau. Les inventaires peuvent être incomplets si un dossier est inaccessible ; ce statut est affiché. Un cache local est écrit après lecture ; il ne remplace pas un nouvel inventaire au redémarrage.

Si le partage est inaccessible, aucune action de production n’est confirmée. Le temps du traitement actif peut être conservé dans `LOCAL-PENDING`, puis proposé au manager au retour du réseau. Il n’est jamais ajouté silencieusement. Dans **Imports et échanges**, le manager accepte ou refuse avec un motif, après comparaison des intervalles. Le programme doit rester ouvert pour enregistrer ces propositions. Une fermeture du programme ne mesure pas le travail effectué ensuite.

## Sauvegardes et publication ACM

Les sauvegardes complètes quotidiennes conservent données, fichiers et exports avec manifeste. Elles nécessitent un programme ouvert et un dossier destination accessible. Une erreur reste visible dans Sauvegardes. Choisir de préférence une destination interne différente du disque de travail. Aucune purge automatique de l’historique n’est effectuée.

La publication ACM copie la totalité des livrables traités de l’espace géré vers son dossier À publier, avec archivage de la publication précédente. Le manager lance la publication après consultation de l’aperçu. Les autres entités ne sont pas publiées automatiquement. Il n’y a pas de copie automatique vers le répertoire client externe dans cette livraison.

## Limites explicites de la livraison

L’intégration directe des déplacements dans les dossiers clients, l’import automatique de chaque nouveau dépôt, la synchronisation complète des actions hors réseau, le calcul financier des primes ne sont pas fournis. L’historique Excel importé ne fusionne pas automatiquement avec les dossiers gérés. Ces points empêchent de qualifier cette version de fin complète du périmètre initial.

Les limites d’envoi sont de 10 Mio par fichier et 12 Mio par document. Le programme ne réalise ni balisage PDF, ni correction Word, ni vérification automatique des 46 critères. La conservation sans purge reste dépendante de la capacité et des sauvegardes de l’infrastructure.

## Import CRM

Dans Imports et échanges, choisir le fichier CRM et associer les colonnes de sa première feuille : identifiant Windows, jour AAAA-MM-JJ, minutes connectées et minutes de pause. Les dates doivent déjà avoir ce format et les durées être des entiers en minutes. Une ligne correspond à une personne et une journée. Le déjeuner déjà déconnecté du CRM n’est pas soustrait de nouveau. Le remplacement d’une journée existante exige une confirmation ; les anciennes valeurs restent conservées. Les journées CRM sont exportables séparément et ne remplacent pas les chronomètres documentaires.
