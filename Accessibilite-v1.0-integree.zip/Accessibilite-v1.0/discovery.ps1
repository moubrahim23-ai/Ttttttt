﻿function Discovery-Location($relative,$folders){
                    $parts=@($relative -split '[\\/]');$levels=@();if($parts.Count -gt 1){$levels=@($parts[0..($parts.Count-2)])}
                    $statuses=@();$historical=$false
                    foreach($level in $levels){
                        if($level -in @('Historique','A PUBLIER','À PUBLIER')){$historical=$true}
                        foreach($status in @('A TRAITER','EN COURS','NON CONFORME','TRAITES')){if($level -ieq [string]$folders.$status){$statuses+=@($status)}}
                    }
                    $unique=@($statuses|Select-Object -Unique);$status='Non déterminé'
                    if($historical){$status='Historique / publication'}elseif($unique.Count -eq 1){$status=$unique[0]}elseif($unique.Count -gt 1){$status='Ambigu'}
    return [pscustomobject]@{levels=@($levels);status=$status}
}
# Parcours depuis la racine, sans limite logique de profondeur ni nombre de fichiers.
function Discover-Documents($directory,$entity,$folders){
    $started=[DateTime]::UtcNow.ToString('o');$base=Full-Path $directory
    $files=New-Object 'System.Collections.Generic.List[object]';$issues=New-Object 'System.Collections.Generic.List[object]'
    $queue=New-Object 'System.Collections.Generic.Queue[string]';$visited=0;$others=0
    try{Assert-NoLink $base;if(-not (Test-Path -LiteralPath $base -PathType Container)){throw 'Racine absente ou inaccessible'};$queue.Enqueue($base)}catch{$issues.Add([pscustomobject]@{path=$base;message=$_.Exception.Message})}
    while($queue.Count){
        $current=$queue.Dequeue();$visited++
        try{
            Assert-NoLink $current
            $info=[IO.DirectoryInfo]::new($current)
            foreach($entry in $info.EnumerateFileSystemInfos()){
                try{
                    Assert-BackupEntry $entry
                    if($entry -is [IO.DirectoryInfo]){$queue.Enqueue($entry.FullName);continue}
                    $ext=$entry.Extension.ToLowerInvariant()
                    if($ext -notin @('.pdf','.doc','.docx','.docm')){$others++;continue}
                    $relative=$entry.FullName.Substring($base.TrimEnd([char[]]@([char]92,[char]47)).Length+1)
                    $location=Discovery-Location $relative $folders;$levels=@($location.levels);$status=$location.status
                    $files.Add([pscustomobject]@{entity=$entity;name=$entry.Name;format=$ext.TrimStart('.');kind=$(if($ext -eq '.pdf'){'PDF'}else{'Word'});path=$entry.FullName;relative=$relative;folders=($levels -join ' / ');depth=$levels.Count;status=$status;bytes=$entry.Length;modified=$entry.LastWriteTimeUtc.ToString('o')})
                }catch{$issues.Add([pscustomobject]@{path=$entry.FullName;message=$_.Exception.Message})}
            }
        }catch{$issues.Add([pscustomobject]@{path=$current;message=$_.Exception.Message})}
    }
    return [pscustomobject]@{entity=$entity;root=$base;started=$started;at=[DateTime]::UtcNow.ToString('o');complete=($issues.Count -eq 0);directories=$visited;pdf=@($files|Where-Object {$_.kind -eq 'PDF'}).Count;word=@($files|Where-Object {$_.kind -eq 'Word'}).Count;other=$others;files=@($files.ToArray());issues=@($issues.ToArray())}
}
