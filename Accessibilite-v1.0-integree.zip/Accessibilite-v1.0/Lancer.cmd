@echo off
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -File "%~dp0server.ps1"
pause
