﻿# Surveillance locale, inventaires en tâche séparée, sources toujours en lecture seule.
$script:watchRows=@();$script:watchVersion='';$script:watchTask=$null
function Close-Watchers {
    foreach($r in $script:watchRows){foreach($id in $r.subscriptions){Unregister-Event -SourceIdentifier $id -ErrorAction SilentlyContinue;Get-Event -SourceIdentifier $id -ErrorAction SilentlyContinue|Remove-Event -ErrorAction SilentlyContinue};if($r.watcher){$r.watcher.Dispose()}}
    $script:watchRows=@()
}
function Watch-Tick {
    $config=Share-Config;$signature=$workspaceRoot+'|'+($config|ConvertTo-Json -Depth 10 -Compress)
    if($signature -ne $script:watchVersion){
        Close-Watchers
        if($script:watchTask){Stop-Job $script:watchTask.job;Remove-Job $script:watchTask.job -Force;$script:watchTask=$null}
        foreach($row in $config.rows){
            if(@($script:state.config.entities|Where-Object {$_.id -eq $row.entity -and $_.active}).Count -ne 1){continue}
            $r=[pscustomobject]@{entity=$row.entity;root=$row.root;folders=$row.folders;watcher=$null;subscriptions=@();due=[DateTime]::UtcNow;result=$null;error='';configVersion=$config.version}
            try{
                Assert-NoLink $r.root
                $w=[IO.FileSystemWatcher]::new($r.root);$w.IncludeSubdirectories=$true;$w.NotifyFilter=[IO.NotifyFilters]'FileName, DirectoryName, LastWrite, Size'
                foreach($eventName in @('Created','Changed','Deleted','Renamed','Error')){$id='ACC-WATCH-'+[Guid]::NewGuid().ToString('N');Register-ObjectEvent -InputObject $w -EventName $eventName -SourceIdentifier $id|Out-Null;$r.subscriptions+=@($id)}
                $w.EnableRaisingEvents=$true;$r.watcher=$w
            }catch{$r.error='Notifications indisponibles ; rapprochement périodique : '+$_.Exception.Message}
            $script:watchRows+=@($r)
        }
        $script:watchVersion=$signature
    }
    foreach($r in $script:watchRows){foreach($id in $r.subscriptions){$events=@(Get-Event -SourceIdentifier $id -ErrorAction SilentlyContinue);if($events.Count){$r.due=[DateTime]::UtcNow.AddSeconds(5);$events|Remove-Event -ErrorAction SilentlyContinue}}}
    if($script:watchTask){
        $task=$script:watchTask
        if($task.job.State -in @('Completed','Failed','Stopped')){
            $row=$task.row
            try{
                if($task.job.State -ne 'Completed'){throw 'Inventaire automatique interrompu'}
                $output=@(Receive-Job $task.job -ErrorAction Stop);if($output.Count -ne 1){throw 'Résultat automatique absent'}
                $result=$output[0]|ConvertFrom-Json;$result|Add-Member -NotePropertyName configVersion -NotePropertyValue $row.configVersion
                $row.result=$result
                if($row.watcher){$row.error=''}
                $cache=Join-Path $root 'LOCAL-CACHE';[IO.Directory]::CreateDirectory($cache)|Out-Null
                $hash=[Security.Cryptography.SHA256]::Create();try{$key=([BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($signature+'|'+$row.entity)))).Replace('-','')}finally{$hash.Dispose()}
                $path=Join-Path $cache ($key+'.json');$tmp=$path+'.tmp';[IO.File]::WriteAllText($tmp,($result|ConvertTo-Json -Depth 15),[Text.UTF8Encoding]::new($false));if(Test-Path -LiteralPath $path){[IO.File]::Replace($tmp,$path,$null)}else{[IO.File]::Move($tmp,$path)}
            }catch{$row.error=$_.Exception.Message}
            finally{Remove-Job $task.job -Force;$script:watchTask=$null}
        }else{return}
    }
    $next=@($script:watchRows|Where-Object {$_.due -le [DateTime]::UtcNow}|Sort-Object due|Select-Object -First 1)
    if(-not $next.Count){return};$r=$next[0];$r.due=[DateTime]::UtcNow.AddMinutes(15)
    $job=Start-Job -ArgumentList $root,$r.root,$r.entity,($r.folders|ConvertTo-Json -Compress) -ScriptBlock {
        param($appRoot,$scanRoot,$entity,$foldersJson)
        $ErrorActionPreference='Stop';. (Join-Path $appRoot 'backup.ps1');. (Join-Path $appRoot 'discovery.ps1')
        Discover-Documents $scanRoot $entity ($foldersJson|ConvertFrom-Json)|ConvertTo-Json -Depth 15 -Compress
    }
    $script:watchTask=[pscustomobject]@{row=$r;job=$job}
}
function Watch-Status {
    return @{items=@($script:watchRows|ForEach-Object {[pscustomobject]@{entity=$_.entity;at=$_.result.at;pdf=$_.result.pdf;word=$_.result.word;complete=$_.result.complete;error=$_.error}})}
}
