﻿param([int]$Port=8090)
$ErrorActionPreference='Stop'
$configFile=Join-Path $PSScriptRoot 'poste.json'
if(Test-Path -LiteralPath $configFile){$config=Get-Content -LiteralPath $configFile -Raw -Encoding UTF8|ConvertFrom-Json}
else{
    $path=Read-Host 'Dossier interne commun de recette (chemin absolu ou UNC, distinct des dossiers clients)'
    if(-not [IO.Path]::IsPathRooted($path)){throw 'Chemin absolu requis'}
    $config=[pscustomobject]@{dataDirectory=$path;port=$Port}
    [IO.File]::WriteAllText($configFile,($config|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
}
& (Join-Path $PSScriptRoot 'server.ps1') -DataDirectory $config.dataDirectory -Port $config.port -UseWindowsSession
