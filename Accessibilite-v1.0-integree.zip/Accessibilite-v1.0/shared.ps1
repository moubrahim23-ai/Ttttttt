﻿# Etat commun : verrou OS/SMB exclusif pendant chaque lecture cohérente ou transaction.
function Acquire-StateLock {
    try{return [IO.File]::Open((Join-Path $store 'server.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}
    catch{throw 'Données momentanément occupées ou réseau inaccessible. Actualisez pour réessayer.'}
}
function Reload-State {
    $latest=Get-ChildItem -LiteralPath $commits -Filter '*.json'|Sort-Object Name|Select-Object -Last 1
    if(-not $latest){throw 'Aucun état persistant disponible'}
    $script:state=Get-Content -LiteralPath $latest.FullName -Raw -Encoding UTF8|ConvertFrom-Json
    $script:sequence=[long]$latest.BaseName
    Resolve-FileTransaction
}
function Pause-StaleWorkers {
    $now=[DateTimeOffset]::Now;$changed=$false
    foreach($d in $script:state.docs){
        if(-not $d.active){continue}
        # Un document ancien sans propriétaire de chrono est arrêté sans ajouter du temps.
        if(-not $d.worker -or -not $d.pulse -or ($d.worker -ne $session -and ($now-[DateTimeOffset]::Parse([string]$d.pulse)).TotalSeconds -gt 45)){
            $d.active=$false;$d.started=$null;$d.version++;$changed=$true
            Event 'SESSION_INTERROMPUE' $d.id 'Chronomètre arrêté au dernier point enregistré ; éventuel temps local soumis à rapprochement'
        }
    }
    if($changed){Save-State}
}
function Offline-Directory {
    $sha=[Security.Cryptography.SHA256]::Create();try{$key=([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes((Full-Path $workspaceRoot))))).Replace('-','')}finally{$sha.Dispose()}
    $path=Join-Path (Join-Path $root 'LOCAL-PENDING') $key;[IO.Directory]::CreateDirectory($path)|Out-Null;return $path
}
function Record-OfflinePulse {
    if(-not $script:state){return}
    foreach($d in $script:state.docs){
        if(-not $d.active -or $d.worker -ne $session -or -not $d.started){continue}
        $from=[DateTimeOffset]::Parse([string]$d.started);$until=[DateTimeOffset]::Now;$rule=Day-Rule $from.LocalDateTime
        if(-not $rule){continue};$cut=[DateTimeOffset]($from.LocalDateTime.Date.AddMinutes((Minute-OfDay $rule.end)))
        if($until -gt $cut){$until=$cut};if($until -le $from){continue}
        $id=$session+'-'+$d.id+'-'+$d.version+'-'+$from.UtcDateTime.Ticks
        $file=Join-Path (Offline-Directory) ($id+'.json');$tmp=$file+'.tmp'
        $entry=[pscustomobject]@{id=$id;document=$d.id;owner=$d.owner;worker=$session;version=$d.version;stage=$d.stage;from=$from.ToString('o');until=$until.ToString('o');seconds=($until-$from).TotalSeconds;recorded=[DateTimeOffset]::Now.ToString('o')}
        [IO.File]::WriteAllText($tmp,($entry|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
        if(Test-Path -LiteralPath $file){[IO.File]::Replace($tmp,$file,$null)}else{[IO.File]::Move($tmp,$file)}
    }
}
function Reconcile-Offline {
    $dir=Offline-Directory
    foreach($file in @(Get-ChildItem -LiteralPath $dir -Filter '*.json')){
        $entry=Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8|ConvertFrom-Json
        if(@($script:state.events|Where-Object {$_.offlineId -eq $entry.id}).Count){
            [IO.File]::Move($file.FullName,$file.FullName+'.resolved');continue
        }
        # Le temps hors réseau est toujours une proposition, jamais une fusion silencieuse.
        if(-not $script:state.PSObject.Properties['offlineConflicts']){$script:state|Add-Member -NotePropertyName offlineConflicts -NotePropertyValue @()}
        $entry|Add-Member -NotePropertyName status -NotePropertyValue 'À examiner'
        $doc=@($script:state.docs|Where-Object id -eq $entry.document)
        if($doc.Count -eq 1 -and $doc[0].worker -eq $entry.worker -and $doc[0].active){$doc[0].active=$false;$doc[0].started=$null;$doc[0].version++}
        $script:state.offlineConflicts+=@($entry)
        Event 'TEMPS_HORS_RESEAU_A_EXAMINER' $entry.document 'Temps conservé localement ; décision manager requise'
        $script:state.events[-1]|Add-Member -NotePropertyName offlineId -NotePropertyValue $entry.id
        Save-State;[IO.File]::Move($file.FullName,$file.FullName+'.resolved')
    }
}
function Resolve-OfflineTime($p){
    if(-not (Is-Manager $p.actor)){throw 'Décision réservée au manager'}
    $row=@($script:state.offlineConflicts|Where-Object {$_.id -eq $p.id -and $_.status -eq 'À examiner'})
    if($row.Count -ne 1){throw 'Proposition déjà résolue ou absente'};$row=$row[0]
    if($p.decision -notin @('Accepter','Refuser') -or -not ([string]$p.reason).Trim()){throw 'Décision et motif obligatoires'}
    $d=@($script:state.docs|Where-Object id -eq $row.document);if($d.Count -ne 1){throw 'Document absent'};$d=$d[0]
    if($p.decision -eq 'Accepter'){
        if($d.active){throw 'Mettre le document en pause avant de rapprocher les temps'}
        # L'identifiant de proposition ne peut être accepté qu'une fois ; le chrono a été suspendu au rapprochement.
        $seconds=[double]$row.seconds
        if($seconds -lt 0 -or $seconds -gt 86400){throw 'Durée hors limites'}
        $d.seconds=[double]$d.seconds+$seconds;$d.stageSeconds[[int]$row.stage]=[double]$d.stageSeconds[[int]$row.stage]+$seconds;$d.version++
    }
    $row.status=[string]$p.decision;$row|Add-Member -NotePropertyName reason -NotePropertyValue ([string]$p.reason)
    Event 'RAPPROCHEMENT_TEMPS_HORS_RESEAU' $d.id ($p.decision+' : '+$p.reason);Save-State
}
