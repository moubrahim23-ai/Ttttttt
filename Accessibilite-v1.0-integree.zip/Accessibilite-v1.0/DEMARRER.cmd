@echo off
cd /d "%~dp0"
echo ACCESSIBILITE - Livraison integree v1.0
echo 1 - Demonstration locale / reprendre les donnees locales
echo 2 - Espace partage avec session Windows
choice /C 12 /N /M "Choisir 1 ou 2 : "
if errorlevel 2 goto partage
call "%~dp0Lancer.cmd"
goto fin
:partage
call "%~dp0Lancer-Partage.cmd"
:fin
