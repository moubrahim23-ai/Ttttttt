# État au 2 octobre 2026

Livraison intégrée v1.0, sans nouvelle exécution de tests à la demande de Mohammed.

## Ajouts de cette livraison

- Verrou commun de données et lancement multi-postes avec session Windows.
- Surveillance récursive et inventaires en arrière-plan.
- Versions client motivées avec archivage de la précédente source.
- Import multifeuille Excel, provenance et homonymes conservés.
- Exports XLSX, archives des évaluations et brouillons Outlook sans envoi.
- Rapprochement manuel des temps conservés pendant une coupure réseau.
- Tirage hebdomadaire déclenché par un passage quotidien du manager et export quotidien.

Les limites fonctionnelles et les conditions de fonctionnement sont détaillées dans DEMARRER.md, notamment la lecture seule des sources clients. Aucun résultat des anciens tests ne vaut validation de cette version.
