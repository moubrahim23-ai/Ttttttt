# Sauvegarde et restauration — v0.9

## Créer et vérifier

En rôle Manager ou Suppléant, ouvrir **Sauvegardes**. L'écran affiche l'emplacement configuré, la dernière réussite, les erreurs et les 100 copies complètes les plus récentes. Les anciennes copies restent sur disque ; aucune purge automatique.

**Sauvegarder maintenant** copie les données, le journal, les snapshots, les sources, livrables et archives. Chaque fichier est contrôlé par SHA-256. La copie n'apparaît comme complète qu'après vérification. **Vérifier** relit une sauvegarde et contrôle à nouveau ses fichiers. Une liste affichée n'est pas une preuve d'intégrité actuelle.

Une copie est créée au premier fonctionnement de chaque journée. Elle correspond à cet instant, pas à la fin de journée. Pour conserver le travail effectué depuis, lancer une nouvelle sauvegarde manuelle. La planification fonctionne uniquement lorsque le serveur tourne ; elle ne crée aucune tâche Windows. Après échec, tentative suivante après 30 minutes de fonctionnement ou manuellement.

Le serveur traite les sauvegardes de manière séquentielle avec les autres opérations. Une copie volumineuse peut bloquer temporairement l'interface. Attendre la fin avant d'arrêter le serveur. Ne pas modifier manuellement les dossiers TEST-DATA et TEST-FILES pendant une sauvegarde.

Le dossier par défaut **SAUVEGARDES** est situé avec l'application. Pour se protéger de la perte du disque, renseigner un autre disque ou un emplacement autorisé dans l'interface. Les jonctions et liens symboliques sont refusés. Un partage réseau peut dépendre des droits Windows ; son fonctionnement n'a pas été testé ici.

## Contenu

Chaque dossier `ACC-date-heure-identifiant` contient :

- `manifest.json` : point de reprise, inventaire, tailles et empreintes.
- `payload/TEST-DATA` : données, paramètres et journal ; le verrou du serveur n'est pas copié.
- `payload/TEST-FILES` : documents, sources, versions archivées et traces des transactions.

Les répertoires de préparation `.partial-…` ne sont pas des sauvegardes réussies. Ils sont conservés pour diagnostic, sans purge automatique. La sauvegarde ne comprend pas le code de l'application ; conserver le ZIP de la même version.

## Restaurer sans écrasement

1. Extraire le ZIP v0.9 dans un dossier contenant `Restaurer.ps1`, `backup.ps1`, `server.ps1`, `seed.json`, `Lancer.cmd` et `web`.
2. Identifier le dossier complet de sauvegarde, celui qui contient `manifest.json`.
3. Choisir un **nouveau dossier inexistant** comme destination. La restauration refuse un dossier déjà présent.
4. Depuis une session PowerShell autorisée, ouverte dans le dossier de l'application, lancer cette commande en remplaçant les deux chemins d'exemple :

```powershell
.\Restaurer.ps1 -Sauvegarde 'D:\Sauvegardes\ACC-20260927-210000-12345678' -Destination 'C:\Accessibilite-Restauree'
```

Le script vérifie les fichiers, les copie, vérifie la copie restaurée puis rend le nouveau dossier disponible. Il conserve les anciens snapshots, ajoute un événement de restauration et remet les chronomètres en pause. La nouvelle installation sauvegarde par défaut dans son propre dossier SAUVEGARDES ; reconfigurer ensuite l'emplacement voulu.

5. Arrêter l'ancien serveur avant de lancer le nouveau, car le port par défaut est le même. L'ancien dossier reste intact. Le script ne lance aucun serveur automatiquement.
6. Ouvrir la nouvelle installation et contrôler la liste des documents et les fichiers téléchargés avant de reprendre le travail.

Si une étape échoue, la destination finale n'est pas publiée ; un dossier temporaire de restauration peut rester pour diagnostic. Le script ne supprime ni la sauvegarde ni l'installation existante. Il ne contourne pas les restrictions PowerShell du poste professionnel.

## Limites

Les empreintes détectent les modifications des fichiers par rapport au manifeste ; elles ne constituent pas une signature d'authenticité d'une sauvegarde provenant d'un tiers. Restaurer uniquement ses propres copies connues.

Les essais de restauration ont été exécutés sous PowerShell 7.4.14 sur Linux, y compris le lancement d'un serveur restauré et le téléchargement exact d'un document. Windows PowerShell 5.1 et les partages SMB restent à valider sur le poste cible. Le volume de production et les pannes matérielles n'ont pas été testés.
