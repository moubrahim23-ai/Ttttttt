﻿# Données CRM déclarées et règles qualité configurables, sans barème de prime implicite.
function HR-Request($p){
    . (Join-Path $root 'operations.ps1');$script:actor=[string]$p.actor
    if(-not (Is-Manager $script:actor)){throw 'Fonction réservée au manager'}
    if($p.action -eq 'hr:quality-rules'){
        if($p.confirm -ne $true){throw 'Confirmer les règles applicables'}
        $count=Config-Integer $p.count 1 31 'Nombre minimal de contrôles'
        $threshold=Config-Integer $p.threshold 0 100 'Seuil qualité'
        if($p.mode -notin @('Chaque contrôle','Moyenne des contrôles')){throw 'Mode de calcul inconnu'}
        $rule=[pscustomobject]@{count=$count;threshold=$threshold;mode=[string]$p.mode;reference=(Ops-Text $p.reference 1000 $true);actor=$script:actor;at=[DateTimeOffset]::Now.ToString('o')}
        $script:state|Add-Member -NotePropertyName qualityRules -NotePropertyValue $rule -Force
        Event 'REGLES_QUALITE_CONFIGUREES' '' ($rule|ConvertTo-Json -Compress);Save-State;return @{saved=$true}
    }
    if($p.action -ne 'hr:crm-import' -or $p.confirm -ne $true){throw 'Confirmer les données CRM'}
    if([string]$p.hash -notmatch '^[a-f0-9]{64}$'){throw 'Empreinte du fichier requise'}
    if(-not $script:state.PSObject.Properties['crm']){$script:state|Add-Member -NotePropertyName crm -NotePropertyValue @()}
    $source=Ops-Text $p.source 250 $true;$rows=@($p.rows)
    if($rows.Count -lt 1 -or $rows.Count -gt 10000){throw 'Entre 1 et 10000 lignes par import'}
    $added=0;$skipped=0;$keys=@{};foreach($r in $script:state.crm){$keys[$r.key]=$true}
    foreach($r in $rows){
        $owner=Ops-Text $r.owner 64 $true
        if($owner -notin @($script:state.config.users.id)){throw ('Compte Windows inconnu : '+$owner)}
        $day=Ops-Date $r.day;$line=Config-Integer $r.line 2 1048576 'Ligne'
        $connected=Config-Integer $r.connected 0 1440 'Minutes connectées';$pause=Config-Integer $r.pause 0 1440 'Minutes de pause'
        if($pause -gt $connected){throw 'Pause supérieure au temps connecté'}
        $key=[string]$p.hash+'|'+$line;if($keys.ContainsKey($key)){$skipped++;continue}
        if(@($script:state.crm|Where-Object {$_.owner -eq $owner -and $_.day -eq $day -and $_.current}).Count){
            if($p.replace -ne $true){throw ('Une journée CRM existe déjà pour '+$owner+' le '+$day+' ; autoriser explicitement la nouvelle version')}
            foreach($old in @($script:state.crm|Where-Object {$_.owner -eq $owner -and $_.day -eq $day -and $_.current})){$old.current=$false}
        }
        $script:state.crm+=@([pscustomobject]@{key=$key;owner=$owner;day=$day;connected=$connected;pause=$pause;net=($connected-$pause);source=$source;line=$line;current=$true;actor=$script:actor;at=[DateTimeOffset]::Now.ToString('o')});$keys[$key]=$true;$added++
    }
    Event 'IMPORT_CRM' '' ($source+' : '+$added+' journées, '+$skipped+' lignes déjà présentes ; déjeuner déconnecté non soustrait une seconde fois');Save-State;return @{added=$added;skipped=$skipped}
}
