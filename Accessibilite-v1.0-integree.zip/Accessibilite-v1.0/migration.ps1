﻿# Reprise documentaire de l'ancien suivi, sans créer de faux fichiers de production.
function Migration-Request($p){
    . (Join-Path $root 'operations.ps1')
    $script:actor=[string]$p.actor
    if(-not (Is-Manager $script:actor)){throw 'Import historique réservé au manager'}
    if($p.confirm -ne $true){throw 'Confirmer la sélection à conserver'}
    $source=Ops-Text $p.source 250 $true
    $hash=[string]$p.hash
    if($hash -notmatch '^[a-f0-9]{64}$'){throw 'Empreinte du classeur absente'}
    $rows=@($p.rows);if($rows.Count -lt 1 -or $rows.Count -gt 10000){throw 'Sélectionner entre 1 et 10000 lignes par import'}
    if(-not $script:state.PSObject.Properties['legacy']){$script:state|Add-Member -NotePropertyName legacy -NotePropertyValue @()}
    $known=@{};foreach($r in $script:state.legacy){$known[$r.key]=$true}
    $added=0;$skipped=0;$batch=[Guid]::NewGuid().ToString('N')
    foreach($r in $rows){
        $sheet=Ops-Text $r.sheet 100 $true;$line=Config-Integer $r.line 1 1048576 'Ligne'
        $key=$hash+'|'+$sheet+'|'+$line
        if($known.ContainsKey($key)){$skipped++;continue}
        $format=(Ops-Text $r.format 30).ToLowerInvariant().TrimStart('.')
        if($format -ne 'pdf'){throw 'Seules les lignes au format PDF sont importées'}
        $raw=@();foreach($cell in @($r.raw)){$raw+=@(Ops-Text $cell 4000)}
        if($raw.Count -gt 200){throw 'Trop de colonnes'}
        $item=[pscustomobject]@{key=$key;batch=$batch;source=$source;hash=$hash;sheet=$sheet;line=$line;name=(Ops-Text $r.name 500 $true);entity=(Ops-Text $r.entity 100);owner=(Ops-Text $r.owner 100);status=(Ops-Text $r.status 100);received=(Ops-Text $r.received 100);finished=(Ops-Text $r.finished 100);format='pdf';raw=$raw;actor=$script:actor;at=[DateTimeOffset]::Now.ToString('o');timeReliable=$false}
        $script:state.legacy+=@($item);$known[$key]=$true;$added++
    }
    Event 'IMPORT_HISTORIQUE_EXCEL' '' ($source+' : '+$added+' lignes ajoutées, '+$skipped+' lignes déjà présentes ; aucun rapprochement par nom')
    Save-State;return @{added=$added;skipped=$skipped;batch=$batch}
}
