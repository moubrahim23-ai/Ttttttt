﻿# Les tâches automatiques s'exécutent seulement tant qu'un poste manager reste ouvert.
function Schedule-Tick {
    $who=''
    if($UseWindowsSession){try{$who=Session-Actor}catch{return}}else{return}
    if(-not (Is-Manager $who)){return}
    . (Join-Path $root 'operations.ps1');Ensure-Operations
    $today=Get-Date -Format 'yyyy-MM-dd';$now=Get-Date
    if($null -eq (Day-Rule $now)){return}
    if(-not $script:state.PSObject.Properties['schedule']){$script:state|Add-Member -NotePropertyName schedule -NotePropertyValue ([pscustomobject]@{lastReport='';lastDraw='';lastError=''})}
    $s=$script:state.schedule
    if($s.lastDraw -ne $today){
        Operations-Request ([pscustomobject]@{actor=$who;action='ops:review-draw';opsVersion=$script:state.operations.version})
        $s.lastDraw=$today;$script:actor=$who;Event 'TIRAGE_QUALITE_AUTOMATIQUE' '' 'Un contrôle par agent et par semaine, candidats disponibles au passage quotidien';Save-State
    }
    if($s.lastReport -ne $today){
        try{
            $result=Office-Request ([pscustomobject]@{actor=$who;action='office:report-export'})
            $s.lastReport=$today;$s.lastError='';$s|Add-Member -NotePropertyName report -NotePropertyValue $result.relative -Force
            Event 'EXPORT_QUOTIDIEN_AUTOMATIQUE' '' $result.relative;Save-State
        }catch{$s.lastError=$_.Exception.Message;Save-State;throw}
    }
}
