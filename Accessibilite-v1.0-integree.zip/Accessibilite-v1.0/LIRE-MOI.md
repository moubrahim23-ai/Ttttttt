# Accessibilité v1.0 — livraison intégrée

Ouvrir **DEMARRER.cmd**. Le guide complet est dans **DEMARRER.md**.

Aucun nouveau test exécuté pour cette livraison. Les limites restantes y sont explicites : ne pas considérer cette version comme certifiée pour la production ou comme la fin de tout le périmètre initial.
