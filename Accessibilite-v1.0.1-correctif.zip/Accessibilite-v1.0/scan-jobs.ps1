﻿# Un seul inventaire à la fois, exécuté hors de la boucle HTTP. Aucun accès en écriture aux sources.
function Scan-Request($p,$config){
    if($p.operation -eq 'discover-poll'){
        if(-not $script:scanTask -or [string]$p.job -ne $script:scanTask.id){throw 'Inventaire introuvable ; relancez la recherche'}
        $t=$script:scanTask
        if($t.configVersion -ne $config.version){throw 'Configuration changée pendant le scan ; relancez la recherche'}
        if($null -ne $t.result){return [pscustomobject]@{status='done';job=$t.id;result=$t.result}}
        if($t.job.State -in @('Failed','Stopped')){
            $reason=[string]$t.job.ChildJobs[0].JobStateInfo.Reason
            throw ('Échec de l''inventaire : '+$reason)
        }
        if($t.job.State -ne 'Completed'){return [pscustomobject]@{status='running';job=$t.id;started=$t.started}}
        $output=@(Receive-Job -Job $t.job -ErrorAction Stop)
        if($output.Count -ne 1){throw 'Résultat inventaire invalide'}
        $result=$output[0]|ConvertFrom-Json
        $result|Add-Member -NotePropertyName configVersion -NotePropertyValue $t.configVersion
        $t.result=$result;Remove-Job -Job $t.job;$t.job=$null
        return [pscustomobject]@{status='done';job=$t.id;result=$result}
    }
    $row=@($config.rows|Where-Object entity -eq $p.entity)
    if($row.Count -ne 1 -or @($script:state.config.entities|Where-Object {$_.id -eq $p.entity -and $_.active}).Count -ne 1){throw 'Enregistrez une racine pour cette entité active'}
    if($script:scanTask -and $script:scanTask.job -and $script:scanTask.job.State -in @('Running','NotStarted')){
        if($script:scanTask.entity -eq $p.entity -and $script:scanTask.configVersion -eq $config.version){return [pscustomobject]@{status='running';job=$script:scanTask.id;started=$script:scanTask.started}}
        throw 'Un inventaire est déjà en cours ; attendre sa fin'
    }
    if($script:scanTask -and $script:scanTask.job){Remove-Job -Job $script:scanTask.job -Force}
    $id=[Guid]::NewGuid().ToString('N');$r=$row[0]
    $job=Start-Job -ArgumentList $root,$r.root,$r.entity,($r.folders|ConvertTo-Json -Compress) -ScriptBlock {
        param($appRoot,$scanRoot,$entity,$foldersJson)
        $ErrorActionPreference='Stop'
        . (Join-Path $appRoot 'backup.ps1')
        . (Join-Path $appRoot 'discovery.ps1')
        Discover-Documents $scanRoot $entity ($foldersJson|ConvertFrom-Json)|ConvertTo-Json -Depth 15 -Compress
    }
    $script:scanTask=[pscustomobject]@{id=$id;entity=$r.entity;job=$job;configVersion=$config.version;started=[DateTimeOffset]::Now.ToString('o');result=$null}
    return [pscustomobject]@{status='running';job=$id;started=$script:scanTask.started}
}
