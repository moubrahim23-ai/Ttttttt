# Correctif de lancement v1.0.1

Les apostrophes typographiques présentes dans quatre messages PowerShell étaient interprétées comme des délimiteurs de chaîne. Elles sont remplacées par des apostrophes échappées dans server.ps1 et scan-jobs.ps1. Les erreurs signalées plus loin dans les routes HTTP provenaient de ces chaînes interrompues.

Aucun test ni lancement de PowerShell exécuté pour ce correctif.

Fermer la fenêtre PowerShell, remplacer server.ps1 et scan-jobs.ps1 dans le dossier existant par ceux du ZIP, puis ouvrir DEMARRER.cmd. Conserver TEST-DATA, TEST-FILES, SAUVEGARDES, LOCAL-PENDING et poste.json. Le ZIP contient également toute l’application.
