﻿# RAPDF Studio V2 - Serveur 100% PowerShell / .NET, sans Python
# Ecoute uniquement 127.0.0.1:8096. Aucune requete Internet.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$utf8 = New-Object System.Text.UTF8Encoding($false)
$port = 8096
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://127.0.0.1:$port/")
function Send-Bytes($context,[byte[]]$bytes,[string]$mime,[int]$status=200) {
  $context.Response.StatusCode=$status
  $context.Response.ContentType=$mime
  $context.Response.Headers['X-Content-Type-Options']='nosniff'
  $context.Response.Headers['Cache-Control']='no-store'
  $context.Response.ContentLength64=$bytes.Length
  try { $context.Response.OutputStream.Write($bytes,0,$bytes.Length) } finally { $context.Response.OutputStream.Close() }
}
function Send-Json($ctx,$value,[int]$status=200) {
  $json=ConvertTo-Json -InputObject $value -Depth 18 -Compress
  Send-Bytes $ctx ($utf8.GetBytes($json)) 'application/json; charset=utf-8' $status
}
function Read-Body($req,[int]$max=52428800) {
  if ($req.ContentLength64 -gt $max) {throw 'Fichier trop volumineux (50 Mo max).'}
  $m=New-Object System.IO.MemoryStream
  $buf=New-Object byte[] 65536
  while (($n=$req.InputStream.Read($buf,0,$buf.Length)) -gt 0) {
    if ($m.Length+$n -gt $max) {throw 'Fichier trop volumineux (50 Mo max).'}
    $m.Write($buf,0,$n)
  }
  return ,$m.ToArray()
}
function Inspect-Pdf([byte[]]$b,[string]$name) {
  if ($b.Length -lt 8 -or [System.Text.Encoding]::ASCII.GetString($b,0,5) -ne '%PDF-') { throw 'Ce fichier ne possede pas une signature PDF valide.' }
  $latin=[System.Text.Encoding]::GetEncoding(28591)
  $s=$latin.GetString($b)
  $version=[regex]::Match($s,'^%PDF-([0-9.]+)').Groups[1].Value
  $pages=[regex]::Matches($s,'/Type\s*/Page\b').Count
  $checks=@(
    @{id='TECH-01';name='Signature PDF';state='detecte';details="Signature %PDF-$version verifiee."},
    @{id='PRE-01';name='Arbre de structure';state='indice';details='Recherche brute de /StructTreeRoot. Un flux compresse peut masquer cette information.';present=$s.Contains('/StructTreeRoot')},
    @{id='PRE-02';name='Marquage PDF';state='indice';details='Recherche brute de /MarkInfo et /Marked. Ce test ne valide pas le balisage.';present=$s.Contains('/MarkInfo')},
    @{id='PRE-03';name='Langue';state='indice';details='Recherche brute de /Lang, sans verification de valeur.';present=($s -match '/Lang\b')},
    @{id='PRE-04';name='Titre';state='a_verifier';details='Recherche brute de /Title, sans evaluation de pertinence.';present=($s -match '/Title\b')},
    @{id='PRE-05';name='Chiffrement';state='a_verifier';details='Recherche brute de /Encrypt. Une absence de resultat n est pas une preuve.';present=($s -match '/Encrypt\b')}
  )
  return @{file=$name;bytes=$b.Length;pdfVersion=$version;pagesIndicatives=$pages;checks=$checks;rapdf='Non evalue';mode='Pre-audit indicatif, sans certification';sha256=([BitConverter]::ToString(([System.Security.Cryptography.SHA256]::Create()).ComputeHash($b))).Replace('-','').ToLowerInvariant();generated=(Get-Date).ToString('o')}
}
$mime=@{'.html'='text/html; charset=utf-8';'.css'='text/css; charset=utf-8';'.js'='application/javascript; charset=utf-8';'.pdf'='application/pdf';'.json'='application/json; charset=utf-8'}
try { $listener.Start() } catch { Write-Host "Impossible d'ouvrir le port $port. Fermez l'ancienne application." -ForegroundColor Red; exit 1 }
Write-Host "RAPDF Studio V2 - PowerShell (sans Python)" -ForegroundColor Cyan
Write-Host "Adresse : http://127.0.0.1:$port/"
Write-Host 'Ctrl+C pour arreter le serveur.'
Start-Process "http://127.0.0.1:$port/"
try {
 while ($listener.IsListening) {
  $ctx=$listener.GetContext()
  try {
   $path=[Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath)
   if ($ctx.Request.HttpMethod -eq 'GET' -and ($path -eq '/' -or $path -eq '/index.html')) { $file=Join-Path $root 'web/index.html' }
   elseif ($ctx.Request.HttpMethod -eq 'GET' -and $path -match '^/web/(style\.css|app\.js)$') { $file=Join-Path $root ('web/'+$Matches[1]) }
   elseif ($ctx.Request.HttpMethod -eq 'GET' -and $path -eq '/sample.pdf') { $file=Join-Path $root 'data/originaux/FC Connect Initial.pdf' }
   elseif ($ctx.Request.HttpMethod -eq 'POST' -and $path -eq '/api/analyze') {
     $b=Read-Body $ctx.Request
     $name=[IO.Path]::GetFileName($ctx.Request.Headers['X-Filename'])
     if (-not $name) {$name='document.pdf'}
     $report=Inspect-Pdf $b $name
     $id=[guid]::NewGuid().ToString('N')
     [IO.File]::WriteAllBytes((Join-Path $root "data/originaux/$id.pdf"),$b)
     $report.id=$id
     [IO.File]::WriteAllText((Join-Path $root "data/rapports/$id.json"),(ConvertTo-Json -InputObject $report -Depth 18),$utf8)
     Send-Json $ctx $report
     continue
   }
   elseif ($ctx.Request.HttpMethod -eq 'POST' -and $path -eq '/api/proposal') {
     $body=Read-Body $ctx.Request 1048576
     $raw=$utf8.GetString($body)
     $obj=ConvertFrom-Json $raw
     if (-not $obj.id -or $obj.id -notmatch '^[a-f0-9]{32}$') {throw 'Identifiant invalide.'}
     if (-not (Test-Path (Join-Path $root "data/rapports/$($obj.id).json"))) {throw 'Audit inconnu.'}
     [IO.File]::WriteAllText((Join-Path $root "data/propositions/$($obj.id).json"),$raw,$utf8)
     Send-Json $ctx @{saved=$true;message='Proposition enregistree. Aucune balise n a ete ecrite dans le PDF.'}
     continue
   }
   else { Send-Json $ctx @{error='Route inconnue'} 404; continue }
   if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { Send-Json $ctx @{error='Fichier introuvable'} 404;continue }
   $ext=[IO.Path]::GetExtension($file).ToLowerInvariant()
   Send-Bytes $ctx ([IO.File]::ReadAllBytes($file)) $mime[$ext]
  } catch {try { Send-Json $ctx @{error=$_.Exception.Message} 400 } catch {}}
 }
} finally { $listener.Stop();$listener.Close() }
