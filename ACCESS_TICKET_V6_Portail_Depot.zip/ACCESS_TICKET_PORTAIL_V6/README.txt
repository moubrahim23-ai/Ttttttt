ACCESS TICKET V6 - PORTAIL DE DEPOT UNIQUEMENT
================================================
VERSION DE TEST LOCAL - NE PAS DEPLOYER EN PRODUCTION

PRE-REQUIS : Windows / PowerShell 5.1 / navigateur moderne.
Aucune dependance Node.js ou Python necessaire sur Windows.

1. Creer ces repertoires :
   C:\ACCESS_TICKET_TEST\ACM\Ass biens\A TRAITER
   C:\ACCESS_TICKET_TEST\ACM\Ass vie\A TRAITER
   C:\ACCESS_TICKET_TEST\COFIDIS\France\A TRAITER
   C:\ACCESS_TICKET_TEST\COFIDIS\Espagne\A TRAITER
   C:\ACCESS_TICKET_TEST\CREATIS\A TRAITER

2. Verifier config.json (root et chemins relatifs).
3. Depuis PowerShell, se placer dans le dossier extrait :
   cd C:\chemin\ACCESS_TICKET_PORTAIL_V6
   powershell.exe -NoProfile -File .\server.ps1
4. Ouvrir http://localhost:8090/
5. Tester avec des PDF/Word factices, sans donnees sensibles.
6. Arreter le serveur avec Ctrl+C.

REGLES
- Ticket groupe : un dossier AT-* et un bon PDF pour plusieurs documents.
- Tickets individuels : un dossier et un bon par document.
- Les documents sont places dans le sous-dossier AT-* de A TRAITER.
- Les bons PDF et metadonnees sont dans root\_ACCESS_TICKET\.
- Les bons n'ont aucun montant.
- Historique et export CSV depuis l'interface.

LIMITES A CORRIGER AVANT INTRANET / DP REEL
- HTTP uniquement sur localhost ; pas d'authentification ni gestion de droits.
- Pas de controle antivirus ni verification approfondie du format Word.
- PDF genere en texte ASCII avec translitteration des accents.
- Base64 JSON en memoire ; limite 30 fichiers de 12 Mo ; pas de streaming.
- Absence de transactions durables multi-postes ; rollback best-effort.
- Pas de tests PowerShell effectues ici : validation sur Windows requise.
- Le serveur ne doit pas etre expose au reseau avant revue de securite IT.
- Les chemins et la structure du DP reel doivent etre configures et valides.
- Les sous-dossiers de ticket necessitent la compatibilite recursive de l'application Agent/Manager existante.
