# Cree uniquement les dossiers de test definis dans config.json.
$ErrorActionPreference = 'Stop'
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$config = Get-Content (Join-Path $base 'config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$root = [IO.Path]::GetFullPath([string]$config.root)
if ($root -notmatch '^[A-Za-z]:\\ACCESS_TICKET_TEST(?:\\|$)') { throw 'Securite : ce script est reserve a C:\ACCESS_TICKET_TEST. Aucun dossier cree.' }
foreach ($e in $config.entities) { foreach ($sub in $e.subentities) {
  $dest = [IO.Path]::GetFullPath((Join-Path $root ([string]$sub.relativePath)))
  if (!$dest.StartsWith($root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Chemin non autorise' }
  $folder = Join-Path $dest 'A TRAITER'
  New-Item -ItemType Directory -Force -Path $folder | Out-Null
  Write-Host ('OK : ' + $folder)
}}
Write-Host 'Dossiers de test prets. Lancez ensuite .\server.ps1'
