ACCESS TICKET V7 — PORTAIL DE DEPOT, INTERFACE TYPE QUID
=========================================================
VERSION DE TEST LOCAL UNIQUEMENT — NE PAS EXPOSER SUR LE RESEAU.

1. Adapter config.json si necessaire. Par defaut root=C:\ACCESS_TICKET_TEST.
2. Creer manuellement les repertoires :
   C:\ACCESS_TICKET_TEST\ACM\Ass biens\A TRAITER
   C:\ACCESS_TICKET_TEST\ACM\Ass vie\A TRAITER
   C:\ACCESS_TICKET_TEST\COFIDIS\France\A TRAITER
   C:\ACCESS_TICKET_TEST\COFIDIS\Espagne\A TRAITER
   C:\ACCESS_TICKET_TEST\CREATIS\A TRAITER
3. Ouvrir PowerShell sur Windows dans le dossier de l'application.
4. Executer : .\server.ps1
5. Ouvrir http://localhost:8090/
6. Tester avec des fichiers NON CONFIDENTIELS et non professionnels.

NOUVEAUTES V7
- Navigation tableau de bord, nouveau depot, tickets, bons de commande.
- Fiche QUID modernisee : Synthese, Pieces jointes, Bon, Commentaires (lecture seule), Historique.
- Formulaire enrichi : priorite, reference metier, description.
- Recherche, filtres, export CSV, bons PDF.
- Moteur V6 conserve : tickets individuels/groupes, ecriture dans A TRAITER/[ticket].

LIMITES CONNUES
- PowerShell non teste dans cet environnement Linux.
- Serveur HTTP localhost seulement ; pas d'authentification Windows ni de controle des droits.
- Les onglets Commentaires et Historique affichent des informations limitees ; pas de journal de commentaires editable.
- Les champs priorite/reference/description sont enregistres dans le ticket mais ne figurent pas encore dans le bon PDF.
- Le PDF est simple, avec translitteration des accents et texte long tronque.
- L'historique retourne les 300 derniers tickets et n'est pas filtre par utilisateur.
- Le transfert utilise du JSON/base64, non adapte aux volumes tres importants.
- Ne pas mettre en production sans revue IT, HTTPS, authentification, autorisations et tests multiutilisateurs.
- Aucun changement a l'application Agent/Manager existante.
