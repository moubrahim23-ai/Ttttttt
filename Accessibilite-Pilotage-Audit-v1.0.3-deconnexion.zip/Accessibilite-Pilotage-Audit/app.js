const $=id=>document.getElementById(id);let dataset=null,report=null;
const statuses=['A TRAITER','EN COURS','TRAITES','NON CONFORME','A PUBLIER'];
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const isDoc=x=>x.kind==='file'&&['.pdf','.doc','.docx'].includes(x.extension);
function prepare(items){
 const groups=new Map(),entities=new Set();
 for(const x of items){if(x.kind==='folder'&&x.path.indexOf('\\')<0)entities.add(x.entity);if(!isDoc(x)||!statuses.includes(x.status))continue;
 const parts=x.path.split('\\'),idx=parts.findIndex((v,i)=>i>0&&statuses.includes(v.replace(/[-_]/g,' ').replace(/\s+/g,' ').trim().toUpperCase()));if(idx<0)continue;
 const status=parts[idx].replace(/[-_]/g,' ').replace(/\s+/g,' ').trim().toUpperCase();
 const relative=parts.slice(idx+1,-1),parent=parts.slice(0,-1).join('\\');
 const business=(status==='A PUBLIER'||status==='TRAITES'||status==='NON CONFORME')?relative.slice(0,-1).join(' / '):relative.join(' / ');
 const key=[x.entity,status,parent].join('|');if(!groups.has(key))groups.set(key,{entity:x.entity,status,parent,business,files:[]});groups.get(key).files.push(x);
 }
 const records=[];
 for(const g of groups.values()){
  if(['TRAITES','NON CONFORME','A PUBLIER'].includes(g.status)){
   // Un traitement = un dossier physique contenant au moins un PDF ou Word.
   records.push({entity:g.entity,business:g.business||'(racine)',status:g.status,path:g.parent});
  }else{
   // A traiter / En cours : PDF et Word de meme nom = un seul document.
   const names=new Set(g.files.map(f=>f.name.replace(/\.(pdf|docx|doc)$/i,'').toLowerCase()));
   for(const name of names)records.push({entity:g.entity,business:g.business||'(racine)',status:g.status,path:g.parent+'\\'+name});
  }
 }
 return {records,entities:[...entities].sort((a,b)=>a.localeCompare(b,'fr'))};
}
function counts(records,e,b){const a=records.filter(x=>x.entity===e&&(!b||x.business===b));return statuses.map(s=>a.filter(x=>x.status===s).length)}
function row(e,b,records,main){const n=counts(records,e,b);return `<tr class="${main?'entity-row':''}"><td>${main?esc(e):'↳ '+esc(b)}</td>${n.map(v=>`<td class="num">${v}</td>`).join('')}<td class="num">${n.reduce((a,b)=>a+b,0)}</td></tr>`}
function draw(){if(!dataset)return;const {records,entities}=dataset,chosen=$('entity').value,q=$('search').value.toLowerCase();$('rows').innerHTML=entities.filter(e=>(!chosen||chosen===e)).map(e=>{const bs=[...new Set(records.filter(x=>x.entity===e&&x.business!=='(racine)').map(x=>x.business))].sort();if(q&&!e.toLowerCase().includes(q)&&!bs.some(b=>b.toLowerCase().includes(q)))return '';return row(e,'',records,true)+bs.filter(b=>!q||e.toLowerCase().includes(q)||b.toLowerCase().includes(q)).map(b=>row(e,b,records,false)).join('')}).join('')||'<tr><td colspan="7">Aucun résultat</td></tr>'}
async function request(path){$('message').textContent='Analyse du réseau en cours…';try{const r=await fetch(path,{cache:'no-store'}),d=await r.json();if(!r.ok)throw Error(d.error||'Erreur serveur');$('message').textContent=d.errors?.length?`${d.errors.length} dossier(s) inaccessible(s) : résultats partiels.`:'';return d}catch(e){$('message').textContent='Erreur : '+e.message;return null}}
async function refresh(){const d=await request('/api/scan');if(!d)return;dataset=prepare(d.items||[]);const {records,entities}=dataset;$('kpis').innerHTML=[['Entités',entities.length],...statuses.map(s=>[s,records.filter(x=>x.status===s).length]),['Total traitements/documents',records.length]].map(([n,v])=>`<div class="kpi"><strong>${v.toLocaleString('fr-FR')}</strong><span>${esc(n)}</span></div>`).join('');const old=$('entity').value;$('entity').innerHTML='<option value="">Toutes les entités</option>'+entities.map(e=>`<option value="${esc(e)}">${esc(e)}</option>`).join('');$('entity').value=entities.includes(old)?old:'';$('info').textContent=`${d.root} · Actualisé le ${d.scanned}`;draw()}
async function audit(){const d=await request('/api/audit');if(!d)return;report=d;$('csv').disabled=false;$('auditSummary').textContent=`${d.checked} dossiers de traitement vérifiés · ${d.issues.length} alertes · ${d.scanned}. Contrôle documentaire uniquement (pas audit RAPDF).`;$('issues').innerHTML=d.issues.map(x=>`<tr><td>${esc(x.entity)}</td><td>${esc(x.business)}</td><td>${esc(x.document)}</td><td title="${esc(x.detail)}">${esc(x.type)}</td><td>${esc(x.path)}</td></tr>`).join('')||'<tr><td colspan="5">Aucune anomalie détectée.</td></tr>'}
function exportCsv(){if(!report)return;const lines=[['Entité','Métier','Document','Type','Détail','Chemin'],...report.issues.map(x=>[x.entity,x.business,x.document,x.type,x.detail,x.path])];const csv='\ufeff'+lines.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(';')).join('\r\n');const u=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'})),a=document.createElement('a');a.href=u;a.download='audit_accessibilite.csv';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)}
$('refresh').onclick=refresh;$('audit').onclick=audit;$('csv').onclick=exportCsv;$('search').oninput=draw;$('entity').onchange=draw;refresh();

// Arrêt explicite du serveur local, sans toucher aux documents du DP.
$('disconnect').addEventListener('click',async()=>{
 if(!confirm('Arrêter le serveur local ? Le tableau de bord ne sera plus accessible avant un nouveau lancement.'))return;
 $('disconnect').disabled=true;
 try{
  const r=await fetch('/api/shutdown',{method:'POST',cache:'no-store'});
  if(!r.ok)throw Error('Arrêt refusé ('+r.status+')');
  document.body.innerHTML='<main style="max-width:650px;margin:12vh auto;font-family:Segoe UI,Arial,sans-serif"><h1>Serveur déconnecté</h1><p>Le serveur local a reçu la demande d’arrêt. Vous pouvez fermer cet onglet. Pour reprendre, relancez LANCER.bat.</p></main>';
 }catch(e){$('disconnect').disabled=false;alert('Impossible de déconnecter le serveur : '+e.message);}
});
