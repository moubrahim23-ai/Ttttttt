ACCESS TICKET V4 — PROTOTYPE LOCAL, PAS UNE VERSION PRODUCTION

1. Sur un poste Windows de test, créer :
   C:\ACCESS_TICKET_TEST_DP\ACM\Ass biens\A TRAITER
   C:\ACCESS_TICKET_TEST_DP\ACM\Ass biens\EN COURS
   (ou adapter config.json à un DP de TEST autorisé).
2. Dans PowerShell 5.1 : cd vers ce dossier puis .\server.ps1 -Port 8090
3. Ouvrir http://localhost:8090/ sur CE MÊME poste.
4. Créer un ticket et réserver un document ; vérifier le déplacement physique.

IMPORTANT : Ne pas pointer sur le DP de production sans validation et sauvegarde.
Prototype mono-processus, non authentifié, limité à localhost, sans TLS.
Ne pas exposer sur le réseau. L'identité collaborateur est déclarative.
Pas de contrôle antivirus, de quotas centralisés, ni de gestion des accès par rôle.
Bon de commande : page HTML imprimable en PDF depuis le navigateur, pas de génération PDF serveur.
Une réservation déplace UN document seulement, en conservant le numéro du ticket.
Le stockage JSON et les déplacements ne constituent pas une transaction atomique inter-systèmes.
En cas de coupure, une réconciliation manuelle peut être nécessaire.
Tester avec des copies fictives avant de concevoir la version intranet sécurisée.
