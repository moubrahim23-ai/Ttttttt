# ACCESS TICKET V4 - Prototype local PowerShell 5.1 (HTTP localhost only)
param([int]$Port=8090)
$ErrorActionPreference='Stop'
$base=Split-Path -Parent $MyInvocation.MyCommand.Path
$config=Get-Content (Join-Path $base 'config.json') -Raw | ConvertFrom-Json
$root=[IO.Path]::GetFullPath($config.dpRoot)
if(!(Test-Path -LiteralPath $root -PathType Container)){throw "DP introuvable : $root"}
$dataDir=Join-Path $base 'data'; New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
$dbPath=Join-Path $dataDir 'tickets.json'; $logPath=Join-Path $dataDir 'journal.jsonl'
if(!(Test-Path $dbPath)){'[]' | Set-Content -LiteralPath $dbPath -Encoding UTF8}
$gate=New-Object object
function Save-Db($items){
  $temp="$dbPath.tmp"; ConvertTo-Json -InputObject @($items) -Depth 20 | Set-Content -LiteralPath $temp -Encoding UTF8
  Move-Item -LiteralPath $temp -Destination $dbPath -Force
}
function Read-Db { $v=Get-Content -LiteralPath $dbPath -Raw | ConvertFrom-Json; return ,@($v | Where-Object { $null -ne $_ }) }
function Log-Action($action,$ticket,$file,$detail){
  $entry=[ordered]@{time=(Get-Date).ToString('o');action=$action;ticket=$ticket;file=$file;detail=$detail}
  Add-Content -LiteralPath $logPath -Value (ConvertTo-Json -InputObject $entry -Compress) -Encoding UTF8
}
function Send-Json($ctx,$obj,[int]$status=200){
  $bytes=[Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $obj -Depth 20 -Compress))
  $ctx.Response.StatusCode=$status; $ctx.Response.ContentType='application/json; charset=utf-8'
  $ctx.Response.ContentLength64=$bytes.Length; $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length)
}
function Valid-Name([string]$name){
 if([string]::IsNullOrWhiteSpace($name) -or $name -in @('.','..') -or $name -match '[\\/:*?"<>|\x00-\x1f]' -or $name.EndsWith('.') -or $name.EndsWith(' ')){throw 'Nom de fichier invalide'}
 if([IO.Path]::GetExtension($name).ToLowerInvariant() -notin @('.pdf','.doc','.docx')){throw 'Format interdit (PDF, DOC, DOCX uniquement)'}
}
function Get-Destination([string]$entity,[string]$sub){
  $found=@($config.routes | Where-Object { $_.entity -ceq $entity -and $_.subentity -ceq $sub })
  if($found.Count -ne 1){throw 'Destination non autorisée'}
  $rel=[string]$found[0].relativePath
  if([IO.Path]::IsPathRooted($rel) -or $rel -match '(^|[\\/])\.\.([\\/]|$)'){throw 'Configuration de chemin dangereuse'}
  $path=[IO.Path]::GetFullPath((Join-Path $root $rel))
  if(!$path.StartsWith($root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase) -and !$path.StartsWith($root.TrimEnd('/')+'/',[StringComparison]::OrdinalIgnoreCase)){throw 'Chemin hors DP'}
  return $path
}
$listener=New-Object Net.HttpListener
$listener.Prefixes.Add("http://localhost:$Port/"); $listener.Start()
Write-Host "ACCESS TICKET V4 sur http://localhost:$Port/ (Ctrl+C pour arreter)"
try { while($listener.IsListening){
  $ctx=$listener.GetContext()
  try {
    $method=$ctx.Request.HttpMethod; $path=$ctx.Request.Url.AbsolutePath
    if($method -eq 'GET' -and $path -eq '/'){
      $bytes=[IO.File]::ReadAllBytes((Join-Path $base 'index.html'))
      $ctx.Response.ContentType='text/html; charset=utf-8';$ctx.Response.ContentLength64=$bytes.Length
      $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length)
    } elseif($method -eq 'GET' -and $path -eq '/api/routes'){
      Send-Json $ctx @{routes=$config.routes}
    } elseif($method -eq 'GET' -and $path -eq '/api/tickets'){
      [Threading.Monitor]::Enter($gate)
      try {Send-Json $ctx @{tickets=@(Read-Db)}} finally {[Threading.Monitor]::Exit($gate)}
    } elseif($method -eq 'POST' -and $path -in @('/api/create','/api/reserve')){
      if($ctx.Request.ContentLength64 -gt 25000000){throw 'Requête trop volumineuse (25 Mo maximum)'}
      $reader=New-Object IO.StreamReader($ctx.Request.InputStream,[Text.Encoding]::UTF8)
      $payload=$reader.ReadToEnd() | ConvertFrom-Json
      [Threading.Monitor]::Enter($gate)
      try {
        $db=@(Read-Db)
        if($path -eq '/api/create'){
          if([string]::IsNullOrWhiteSpace($payload.section) -or [string]::IsNullOrWhiteSpace($payload.requester)){throw 'Demandeur et code section obligatoires'}
          $dest=Get-Destination ([string]$payload.entity) ([string]$payload.subentity)
          if(!(Test-Path -LiteralPath $dest -PathType Container)){throw "Répertoire A TRAITER inexistant : $dest"}
          $files=@($payload.files)
          if($files.Count -lt 1 -or $files.Count -gt 30){throw 'Entre 1 et 30 fichiers requis'}
          $names=@{}; foreach($f in $files){Valid-Name ([string]$f.name);if($names.ContainsKey([string]$f.name)){throw 'Noms de fichiers dupliqués'};$names[[string]$f.name]=$true}
          $mode=[string]$payload.mode;if($mode -notin @('group','individual')){throw 'Mode invalide'}
          $newTickets=@();$createdFolders=@()
          try {
            $sets=@(); if($mode -eq 'group'){$sets+= ,@($files)} else {foreach($one in $files){$sets+= ,@($one)}}
            foreach($set in $sets){
              $id='AT-'+(Get-Date -Format yyyy)+'-'+([guid]::NewGuid().ToString('N').Substring(0,10).ToUpperInvariant())
              $folder=Join-Path $dest $id
              New-Item -ItemType Directory -Path $folder -ErrorAction Stop | Out-Null
              $createdFolders+= $folder;$docs=@()
              foreach($f in @($set)){
                $bytes=[Convert]::FromBase64String([string]$f.content)
                if($bytes.Length -gt 15000000){throw 'Fichier supérieur à 15 Mo'}
                $target=Join-Path $folder ([string]$f.name)
                [IO.File]::WriteAllBytes($target,$bytes)
                $docs+=@{name=[string]$f.name;status='A traiter';assignee='';path=$target;reservedAt=$null}
              }
              $newTickets+=@{id=$id;requester=[string]$payload.requester;entity=[string]$payload.entity;subentity=[string]$payload.subentity;section=[string]$payload.section;createdAt=(Get-Date).ToString('o');documents=$docs}
            }
            Save-Db (@($db)+@($newTickets))
            foreach($t in $newTickets){Log-Action 'CREATE' $t.id '' ($t.requester+' / '+$t.section)}
          } catch {foreach($dir in $createdFolders){if(Test-Path -LiteralPath $dir){Remove-Item -LiteralPath $dir -Recurse -Force}};throw}
          Send-Json $ctx @{tickets=$newTickets}
        } else {
          $ticket=@($db | Where-Object {$_.id -ceq [string]$payload.ticketId})
          if($ticket.Count -ne 1){throw 'Ticket introuvable'}
          $doc=@($ticket[0].documents | Where-Object {$_.name -ceq [string]$payload.fileName})
          if($doc.Count -ne 1 -or $doc[0].status -ne 'A traiter' -or $doc[0].assignee){throw 'Document déjà réservé ou indisponible'}
          $agent=[string]$payload.agent
          if([string]::IsNullOrWhiteSpace($agent)){throw 'Collaborateur obligatoire'}
          $source=[string]$doc[0].path
          if(!(Test-Path -LiteralPath $source -PathType Leaf)){throw 'Fichier source introuvable'}
          $route=Get-Destination $ticket[0].entity $ticket[0].subentity
          $inProgress=Join-Path (Split-Path $route -Parent) 'EN COURS'
          if(!(Test-Path -LiteralPath $inProgress -PathType Container)){throw 'Répertoire EN COURS inexistant'}
          $targetDir=Join-Path $inProgress $ticket[0].id
          if(!(Test-Path -LiteralPath $targetDir)){New-Item -ItemType Directory -Path $targetDir | Out-Null}
          $target=Join-Path $targetDir $doc[0].name
          if(Test-Path -LiteralPath $target){throw 'Fichier cible déjà existant'}
          Move-Item -LiteralPath $source -Destination $target -ErrorAction Stop
          $doc[0].path=$target;$doc[0].status='En cours';$doc[0].assignee=$agent;$doc[0].reservedAt=(Get-Date).ToString('o')
          try {Save-Db $db} catch {Move-Item -LiteralPath $target -Destination $source -ErrorAction SilentlyContinue;throw}
          Log-Action 'RESERVE' $ticket[0].id $doc[0].name $agent
          Send-Json $ctx @{ok=$true;ticket=$ticket[0].id;file=$doc[0].name;agent=$agent}
        }
      } finally {[Threading.Monitor]::Exit($gate)}
    } else {Send-Json $ctx @{error='Route inconnue'} 404}
  } catch {Send-Json $ctx @{error=$_.Exception.Message} 400}
  finally {$ctx.Response.Close()}
}} finally {$listener.Stop();$listener.Close()}
