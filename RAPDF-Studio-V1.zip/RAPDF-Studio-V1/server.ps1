$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$webroot = Join-Path $root 'web'
$data = Join-Path $root 'data'
$orig = Join-Path $data 'originaux'
$reports = Join-Path $data 'rapports'
New-Item -ItemType Directory -Force -Path $orig,$reports | Out-Null
$listener = New-Object System.Net.HttpListener
$port = 8097
while ($port -le 8110) {
  try { $listener.Prefixes.Clear(); $listener.Prefixes.Add("http://127.0.0.1:$port/"); $listener.Start(); break } catch { $port++ }
}
if (-not $listener.IsListening) { throw 'Aucun port disponible (8097-8110).' }
Write-Host "RAPDF Studio: http://127.0.0.1:$port/" -ForegroundColor Green
Start-Process "http://127.0.0.1:$port/"
function Respond($ctx,[int]$status,[byte[]]$bytes,[string]$type) {
  $ctx.Response.StatusCode = $status
  $ctx.Response.ContentType = $type
  $ctx.Response.Headers.Add('X-Content-Type-Options','nosniff')
  $ctx.Response.Headers.Add('Cache-Control','no-store')
  $ctx.Response.ContentLength64 = $bytes.Length
  $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length)
  $ctx.Response.Close()
}
function Json($ctx,$obj,[int]$status=200) {
  $raw = $obj | ConvertTo-Json -Depth 12 -Compress
  Respond $ctx $status ([Text.Encoding]::UTF8.GetBytes($raw)) 'application/json; charset=utf-8'
}
function Audit($bytes,$filename) {
  $latin = [Text.Encoding]::GetEncoding(28591).GetString($bytes)
  $validHeader = $latin.StartsWith('%PDF-')
  $pageMatches = [regex]::Matches($latin,'/Type\s*/Page(?!s)\b')
  $hasStruct = $latin -match '/StructTreeRoot\b'
  $hasMark = $latin -match '/MarkInfo\b'
  $hasLang = $latin -match '/Lang\s*(\(|<)'
  $hasTitle = $latin -match '/Title\s*(\(|<)'
  $hasEncrypt = $latin -match '/Encrypt\b'
  $checks = @(
    @{ id='TECH-01'; name='Signature PDF'; result=$(if($validHeader){'detecte'}else{'anomalie'}); detail='Vérification des premiers octets du fichier.' },
    @{ id='PRE-01'; name='Arbre de structure'; result=$(if($hasStruct){'indice'}else{'a_verifier'}); detail='Recherche indicative de /StructTreeRoot dans les octets; les objets compressés peuvent masquer cette information.' },
    @{ id='PRE-02'; name='Marquage PDF'; result=$(if($hasMark){'indice'}else{'a_verifier'}); detail='Recherche indicative de /MarkInfo.' },
    @{ id='PRE-03'; name='Langue du document'; result=$(if($hasLang){'indice'}else{'a_verifier'}); detail='Recherche indicative de /Lang; valeur et pertinence non vérifiées.' },
    @{ id='PRE-04'; name='Titre du document'; result=$(if($hasTitle){'indice'}else{'a_verifier'}); detail='Recherche indicative de /Title; qualité du titre non vérifiée.' },
    @{ id='PRE-05'; name='Chiffrement'; result=$(if($hasEncrypt){'indice'}else{'a_verifier'}); detail='Recherche indicative de /Encrypt; absence non concluante.' }
  )
  return @{ file=$filename; size=$bytes.Length; sha256=([BitConverter]::ToString(([Security.Cryptography.SHA256]::Create()).ComputeHash($bytes))).Replace('-','').ToLowerInvariant(); timestamp=(Get-Date).ToString('o'); pageCountHint=$pageMatches.Count; checks=$checks; disclaimer='Pré-audit technique limité : recherche de marqueurs binaires, PAS un audit RAPDF ni une validation PDF/UA. Les 46 critères restent à examiner. Les objets PDF compressés peuvent produire des faux négatifs.'; rapdfCriteria=46; status='pre-audit' }
}
try {
 while ($listener.IsListening) {
  $ctx = $listener.GetContext()
  try {
   $path = $ctx.Request.Url.AbsolutePath
   if ($ctx.Request.HttpMethod -eq 'GET' -and ($path -eq '/' -or $path -eq '/index.html')) {
     Respond $ctx 200 ([IO.File]::ReadAllBytes((Join-Path $webroot 'index.html'))) 'text/html; charset=utf-8'
   } elseif ($ctx.Request.HttpMethod -eq 'GET' -and $path -eq '/app.js') {
     Respond $ctx 200 ([IO.File]::ReadAllBytes((Join-Path $webroot 'app.js'))) 'text/javascript; charset=utf-8'
   } elseif ($ctx.Request.HttpMethod -eq 'GET' -and $path -eq '/style.css') {
     Respond $ctx 200 ([IO.File]::ReadAllBytes((Join-Path $webroot 'style.css'))) 'text/css; charset=utf-8'
   } elseif ($ctx.Request.HttpMethod -eq 'POST' -and $path -eq '/api/audit') {
     if ($ctx.Request.ContentLength64 -lt 1 -or $ctx.Request.ContentLength64 -gt 52428800) { Json $ctx @{error='Taille invalide (maximum 50 Mo).'} 413; continue }
     $ms = New-Object IO.MemoryStream
     $buf = New-Object byte[] 65536
     $total = 0
     while (($n=$ctx.Request.InputStream.Read($buf,0,$buf.Length)) -gt 0) { $total += $n; if($total -gt 52428800){break}; $ms.Write($buf,0,$n) }
     if($total -gt 52428800){ Json $ctx @{error='Fichier trop volumineux.'} 413; continue }
     $bytes = $ms.ToArray(); $ms.Dispose()
     $name = [IO.Path]::GetFileName([Uri]::UnescapeDataString($ctx.Request.Headers['X-Filename']))
     if ([string]::IsNullOrWhiteSpace($name)) { $name='document.pdf' }
     if (-not $name.ToLowerInvariant().EndsWith('.pdf')) { Json $ctx @{error='Seuls les fichiers PDF sont acceptés.'} 400; continue }
     $id = [guid]::NewGuid().ToString('N')
     $result = Audit $bytes $name
     if (-not $bytes.Length -or -not ([Text.Encoding]::ASCII.GetString($bytes,0,[Math]::Min(5,$bytes.Length)) -eq '%PDF-')) { Json $ctx @{error='En-tête PDF invalide.'} 400; continue }
     [IO.File]::WriteAllBytes((Join-Path $orig "$id.pdf"),$bytes)
     $json = $result | ConvertTo-Json -Depth 12
     [IO.File]::WriteAllText((Join-Path $reports "$id.json"),$json,[Text.Encoding]::UTF8)
     Json $ctx $result
   } else { Json $ctx @{error='Route inconnue.'} 404 }
  } catch { try { Json $ctx @{error=$_.Exception.Message} 500 } catch {} }
 }
} finally { $listener.Stop(); $listener.Close() }
