"use strict";
const $=id=>document.getElementById(id);let report=null,proposal=[],previewUrl=null,currentPdfBlob=null;
function download(name,obj){const b=new Blob([JSON.stringify(obj,null,2)],{type:'application/json'}),u=URL.createObjectURL(b),a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)}
function showReport(r,blob){currentPdfBlob=blob;report=r;proposal=[];renderTree();$('results').hidden=false;$('stats').replaceChildren();for(const t of [`Fichier : ${r.file}`,`Taille : ${(r.bytes/1024).toFixed(0)} Ko`,`Pages (indice, non garanti) : ${r.pagesIndicatives}`,`SHA-256 : ${r.sha256.slice(0,16)}…`]){const el=document.createElement('span');el.className='stat';el.textContent=t;$('stats').append(el)}$('checks').replaceChildren();for(const c of r.checks){const d=document.createElement('div');d.className='check';const b=document.createElement('b');b.textContent=`${c.id} — ${c.name} : ${c.state}`;const s=document.createElement('small');s.textContent=c.details+(c.present===undefined?'':` Présence textuelle : ${c.present?'oui':'non'}.`);d.append(b,s);$('checks').append(d)}if(previewUrl)URL.revokeObjectURL(previewUrl);previewUrl=URL.createObjectURL(blob);$('preview').src=previewUrl;$('status').textContent='Pré-audit terminé. Résultats indicatifs, pas une conformité RAPDF.'}
async function analyze(blob,name){$('status').textContent='Analyse en cours…';try{const res=await fetch('/api/analyze',{method:'POST',headers:{'X-Filename':encodeURIComponent(name)},body:blob});const data=await res.json();if(!res.ok)throw Error(data.error||'Erreur serveur');showReport(data,blob)}catch(e){$('status').textContent='Erreur : '+e.message}}
$('analyze').onclick=()=>{const f=$('file').files[0];if(!f){$('status').textContent='Sélectionne un PDF.';return}analyze(f,f.name)};
$('sample').onclick=async()=>{try{const r=await fetch('/sample.pdf');if(!r.ok)throw Error('Exemple introuvable');analyze(await r.blob(),'FC Connect Initial.pdf')}catch(e){$('status').textContent=e.message}};
function renderTree(){$('tree').replaceChildren();proposal.forEach((p,i)=>{const d=document.createElement('div');d.className='node';const s=document.createElement('span');s.textContent=`${i+1}. [${p.tag}] ${p.label}${p.confidence ? " — confiance indicative "+Math.round(p.confidence*100)+"%" : ""}`;const up=document.createElement('button');up.textContent='↑';up.title='Monter';up.onclick=()=>{if(i){[proposal[i-1],proposal[i]]=[proposal[i],proposal[i-1]];renderTree()}};const down=document.createElement('button');down.textContent='↓';down.title='Descendre';down.onclick=()=>{if(i<proposal.length-1){[proposal[i+1],proposal[i]]=[proposal[i],proposal[i+1]];renderTree()}};const del=document.createElement('button');del.textContent='×';del.title='Supprimer';del.onclick=()=>{proposal.splice(i,1);renderTree()};d.append(s,up,down,del);$('tree').append(d)})}
$('add').onclick=()=>{const label=$('label').value.trim();if(!label)return;proposal.push({tag:$('tag').value,label});$('label').value='';renderTree()};
function payload(){return {id:report.id,source:report.file,notice:'Proposition uniquement : aucune balise PDF ecrite',elements:proposal,generated:new Date().toISOString()}}
$('export').onclick=()=>report&&download('pre-audit-'+report.id+'.json',report);
$('proposalExport').onclick=()=>report&&download('proposition-'+report.id+'.json',payload());
$('save').onclick=async()=>{if(!report)return;try{const r=await fetch('/api/proposal',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload())});const d=await r.json();if(!r.ok)throw Error(d.error);$('savestatus').textContent=d.message}catch(e){$('savestatus').textContent='Erreur : '+e.message}};

$('suggest').onclick=()=>{
 if(!report){$('suggeststatus').textContent='Analyse un PDF d’abord.';return;}
 const lines=(report.textCandidates||[]).map(x=>String(x).trim()).filter(x=>x.length>3);
 if(!lines.length){$('suggeststatus').textContent='Aucun texte exploitable trouvé par le détecteur heuristique. Le PDF peut contenir des flux compressés. Saisis la structure manuellement ; ne conclus pas que le document est vide.';return;}
 proposal=lines.map((label,i)=>({tag:i===0?'H1':(label.length<75 && /[:?]$/.test(label)?'H2':'P'),label,origin:'heuristique_non_validee'}));
 renderTree();$('suggeststatus').textContent=proposal.length+' propositions indicatives générées. Vérifie et corrige chaque balise avant enregistrement.';
};

// Proposition de reference specifique au document de demonstration ; jamais presentee comme balisage PDF reel.
$('reference').onclick=()=>{
 if(!report){$('suggeststatus').textContent='Analyse d’abord le document.';return;}
 if(!/FC Connect Initial/i.test(report.file)){$('suggeststatus').textContent='Cette proposition est reservee au document FC Connect Initial.';return;}
 const rows=[
 ['H1','CONNECT INITIAL',1],['P','Une offre groupée de services proposant l’essentiel',1],
 ['H2','Quels sont les services ?',1],['H3','Un compte courant',1],
 ['P','Pour domicilier vos revenus et régler vos dépenses de la vie quotidienne',1],
 ['H3','Une carte de paiement internationale',1],['H3','Des services digitaux',1],
 ['L','Services digitaux : site internet et application mobile',1],
 ['H3','Une assurance du quotidien',1],['L','Liste des garanties',1],
 ['H3','Un découvert autorisé',2],['H3','Un crédit renouvelable',2],
 ['H2','Quel est son prix ?',2],['H2','Vous effectuez des opérations carte à l’étranger ?',2],
 ['H2','Autres informations précontractuelles',3],['L','Réclamations et médiation',3]
 ];
 proposal=rows.map(([tag,label,page])=>({tag,label,page,origin:'reference_manuelle_a_valider'}));
 renderTree();$('suggeststatus').textContent='16 éléments proposés depuis le document de référence. Vérifie les paragraphes, notes, listes et l’ordre de lecture. Aucune balise écrite dans le PDF.';
};
$('csv').onclick=()=>{
 if(!report)return;
 const lines=[['identifiant','controle','etat','presence','details'],...report.checks.map(c=>[c.id,c.name,c.state,c.present===undefined?'':String(c.present),c.details])];
 const csv='\uFEFF'+lines.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(';')).join('\r\n');
 const u=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=u;a.download='pre-audit-'+report.id+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);
};

$('pdfDownload').onclick=()=>{if(!currentPdfBlob||!report)return;const u=URL.createObjectURL(currentPdfBlob),a=document.createElement('a');a.href=u;a.download=report.file.replace(/\.pdf$/i,'')+'-original.pdf';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),10000);};

// Assistant de structure explicable, totalement local. Ne prétend pas être un modèle MiniLM.
function classifyLine(label,previousTag){
 const t=label.trim(), low=t.toLocaleLowerCase('fr');
 if (/^(?:[-•–]|\d+[.)])\s+/.test(t)) return {tag:'LI',confidence:0.82,reason:'Marqueur de liste détecté'};
 if (/^(?:attention\s*!|important\s*:)/i.test(t)) return {tag:'P',confidence:0.65,reason:'Avertissement, à vérifier'};
 if (/^(?:quels? |quel |comment |pourquoi |autres informations|vous effectuez)/i.test(t) && t.length<105) return {tag:'H2',confidence:0.73,reason:'Formulation typique de rubrique'};
 if (/^(?:un |une |des |les )/i.test(t) && t.length<65 && !/[.!]$/.test(t)) return {tag:'H3',confidence:0.63,reason:'Intitulé court de sous-rubrique'};
 if (t.length<55 && !/[.!?]$/.test(t)) return {tag:previousTag==='H1'?'H2':'H3',confidence:0.53,reason:'Texte court, hiérarchie incertaine'};
 return {tag:'P',confidence:0.72,reason:'Texte courant probable'};
}
$('smart').onclick=()=>{
 if(!report){$('suggeststatus').textContent='Analyse un PDF d’abord.';return;}
 let lines=(report.textCandidates||[]).map(x=>String(x).trim()).filter(x=>x.length>3);
 if(!lines.length && proposal.length){proposal=proposal.map(p=>({...p,confidence:p.confidence||0.5,reason:p.reason||'Structure existante : vérification humaine nécessaire'}));renderTree();$('suggeststatus').textContent='Proposition existante annotée. Aucun nouveau texte extrait du PDF.';return;}
 if(!lines.length){$('suggeststatus').textContent='Extraction impossible avec le moteur actuel : aucune proposition automatique fiable.';return;}
 proposal=lines.map((label,i)=>{let c=i===0?{tag:'H1',confidence:0.55,reason:'Premier élément : titre présumé'}:classifyLine(label,proposal[i-1]?.tag);return {...c,label,origin:'regles_locales_non_validees'};});
 renderTree();$('suggeststatus').textContent=proposal.length+' éléments proposés avec niveau de confiance indicatif. Validation humaine obligatoire.';
};
$('review').onclick=()=>{
 const issues=proposal.map((p,i)=>({p,i})).filter(({p})=>!p.confidence||p.confidence<0.8||['Table','TH','TD','Figure','Note','L','LI'].includes(p.tag));
 $('reviewResults').textContent=issues.length?issues.length+' élément(s) à vérifier : '+issues.slice(0,12).map(({p,i})=>'#'+(i+1)+' '+p.tag+' — '+p.label.slice(0,55)).join(' ; '):'Aucun signal dans les propositions. Cela ne prouve pas la conformité.';
};
