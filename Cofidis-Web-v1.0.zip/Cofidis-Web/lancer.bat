@echo off
setlocal
pushd "%~dp0"
powershell.exe -NoLogo -NoProfile -File "%~dp0server.ps1"
if errorlevel 1 pause
popd
endlocal
