﻿param([int]$Port = 0, [switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'core.ps1')
$listener=$null; $script:StoreLock=$null
try {
    $config=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($Port -eq 0) { $Port=[int]$config.Port }
    if ($Port -lt 1024 -or $Port -gt 65535) { throw 'Le port doit etre compris entre 1024 et 65535.' }
    $root=Resolve-AppPath $config.DataRoot $PSScriptRoot
    $exports=Resolve-AppPath $config.ExportRoot $PSScriptRoot
    $user=[Environment]::UserName
    if (!$user) { throw 'Session Windows introuvable.' }
    Initialize-Store $root $exports $user
    $token=[guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N')
    $baseUrl='http://localhost:' + $Port + '/'
    $listener=New-Object System.Net.HttpListener
    $listener.Prefixes.Add($baseUrl)
    try { $listener.Start() } catch { throw ('Impossible d ouvrir ' + $baseUrl + '. Port occupe ou autorisation Windows manquante. Detail : ' + $_.Exception.Message) }
    Write-Host ('COFIDIS WEB - ' + $user) -ForegroundColor Cyan
    Write-Host ('Adresse : ' + $baseUrl)
    Write-Host ('Donnees : ' + $script:DataPath)
    Write-Host 'Pour arreter : bouton Arreter l application, ou Ctrl+C dans cette fenetre.'
    if (!$NoBrowser) { Start-Process $baseUrl }
    $running=$true
    while ($running -and $listener.IsListening) {
        $context=$listener.GetContext(); $request=$context.Request; $response=$context.Response
        $response.Headers['X-Content-Type-Options']='nosniff'
        $response.Headers['Cache-Control']='no-store'
        $response.Headers['Referrer-Policy']='no-referrer'
        $response.Headers['Content-Security-Policy']="default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
        $status=200; $mime='application/json; charset=utf-8'; $bytes=$null
        try {
            if ($request.Url.Host -ne 'localhost' -or $request.Url.Port -ne $Port -or $request.UserHostName -ne ('localhost:' + $Port)) { $status=403; throw 'Hote non autorise.' }
            $path=$request.Url.AbsolutePath
            if ($path.StartsWith('/api/')) {
                if ($path -eq '/api/state' -and $request.HttpMethod -eq 'GET') {
                    $payload=@{ user=$user; token=$token; records=@($script:Store.records); events=@($script:Store.events); dataPath=$script:DataPath; exportRoot=$exports }
                } else {
                    if ($request.HttpMethod -ne 'POST') { $status=405; throw 'Methode non autorisee.' }
                    if ($request.Headers['X-Cofidis-Token'] -cne $token) { $status=403; throw 'Session expiree. Rechargez la page.' }
                    $origin=$request.Headers['Origin']
                    if ($origin -and $origin -ne $baseUrl.TrimEnd('/')) { $status=403; throw 'Origine non autorisee.' }
                    if ($request.ContentType -notlike 'application/json*') { $status=415; throw 'Format JSON requis.' }
                    if ($request.ContentLength64 -lt 0 -or $request.ContentLength64 -gt 65536) { $status=413; throw 'Requete trop volumineuse.' }
                    $reader=New-Object IO.StreamReader($request.InputStream,[Text.Encoding]::UTF8)
                    try { $raw=$reader.ReadToEnd() } finally { $reader.Dispose() }
                    $body=$raw | ConvertFrom-Json
                    if ($null -eq $body -or $body -isnot [pscustomobject]) { throw 'Objet JSON requis.' }
                    switch ($path) {
                        '/api/start' { $payload=Start-Record $body }
                        '/api/finish' { $payload=Finish-Record $body }
                        '/api/archive' { $payload=Archive-Records $body }
                        '/api/export' { $payload=Export-Records }
                        '/api/backup' { $payload=Backup-Store }
                        '/api/shutdown' { $payload=@{ message='Serveur arrete.' }; $running=$false }
                        default { $status=404; throw 'Route introuvable.' }
                    }
                }
                $bytes=[Text.Encoding]::UTF8.GetBytes(($payload | ConvertTo-Json -Depth 20 -Compress))
            } else {
                if ($request.HttpMethod -ne 'GET') { $status=405; throw 'Methode non autorisee.' }
                $assets=@{'/'='index.html'; '/index.html'='index.html'; '/style.css'='style.css'; '/app.js'='app.js'; '/domain.js'='domain.js'}
                if (!$assets.ContainsKey($path)) { $status=404; throw 'Fichier introuvable.' }
                $file=$assets[$path]
                $mime='text/html; charset=utf-8'
                if ($file.EndsWith('.js')) { $mime='application/javascript; charset=utf-8' }
                if ($file.EndsWith('.css')) { $mime='text/css; charset=utf-8' }
                $bytes=[IO.File]::ReadAllBytes((Join-Path (Join-Path $PSScriptRoot 'www') $file))
            }
        } catch {
            if ($status -eq 200) { $status=400 }
            $mime='application/json; charset=utf-8'
            $bytes=[Text.Encoding]::UTF8.GetBytes((@{ error=$_.Exception.Message } | ConvertTo-Json -Compress))
        }
        try { $response.StatusCode=$status; $response.ContentType=$mime; $response.ContentLength64=$bytes.Length; $response.OutputStream.Write($bytes,0,$bytes.Length) }
        catch { Write-Warning 'Le navigateur a ferme la connexion. Les actions deja enregistrees restent conservees.' }
        finally { $response.Close() }
    }
} catch {
    Write-Host ('ERREUR : ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
} finally {
    if ($null -ne $listener) { $listener.Close() }
    if ($null -ne $script:StoreLock) { $script:StoreLock.Dispose() }
}
