﻿# Logique metier partagee par le serveur et les tests locaux.
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$script:Utf8 = New-Object System.Text.UTF8Encoding($true)
$script:Types = @('N1','N2','CHALLENGER','ETUDEINC','SOLVA')
$script:Products = @('AUG ACC','OUV ACC','AUG PART','OUV PSM','OUV PSM/PSM',"OUV PSM d'AUG")
$script:Decisions = @('OCA','OCR','OCI','CPP','AUTDEJ','TRF FRD','TRF BL','DELEGATION','ABA','DEROGATION','DOSRISK')
function Resolve-AppPath([string]$Value, [string]$Base) {
    if ([string]::IsNullOrWhiteSpace($Value)) { throw 'Un chemin de configuration est vide.' }
    if ([IO.Path]::IsPathRooted($Value)) { return [IO.Path]::GetFullPath($Value) }
    return [IO.Path]::GetFullPath((Join-Path $Base $Value))
}
function Get-SafeUserKey([string]$UserName) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $hash = [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($UserName))).Replace('-','').Substring(0,12) } finally { $sha.Dispose() }
    return (($UserName -replace '[^a-zA-Z0-9_.-]','_') + '_' + $hash)
}
function Write-AtomicText([string]$Path, [string]$Text) {
    $tmp = $Path + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    try {
        [IO.File]::WriteAllText($tmp, $Text, $script:Utf8)
        if ([IO.File]::Exists($Path)) { [IO.File]::Replace($tmp, $Path, ($Path + '.bak')) }
        else { [IO.File]::Move($tmp, $Path) }
    } finally { if ([IO.File]::Exists($tmp)) { [IO.File]::Delete($tmp) } }
}
function Read-Store {
    $value = [IO.File]::ReadAllText($script:DataPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
    if ($null -eq $value -or $value.schema -ne 1 -or $value.user -ne $script:UserName) { throw 'Fichier de donnees incompatible. Ne le remplacez pas : utilisez une sauvegarde.' }
    if ($null -eq $value.records -or $null -eq $value.events) { throw 'Structure de donnees invalide.' }
    return $value
}
function Initialize-Store([string]$Root, [string]$Exports, [string]$UserName) {
    $script:UserName = $UserName; $script:UserKey = Get-SafeUserKey $UserName
    $script:ExportRoot = $Exports
    $script:UserDirectory = Join-Path $Root $script:UserKey
    [IO.Directory]::CreateDirectory($script:UserDirectory) | Out-Null
    $script:DataPath = Join-Path $script:UserDirectory 'dossiers.json'
    # Verrou conserve tant que le serveur tourne, y compris sur un partage SMB.
    try { $script:StoreLock = [IO.File]::Open((Join-Path $script:UserDirectory 'application.lock'), [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None) }
    catch { throw 'Ces donnees sont deja utilisees par une autre instance, ou le dossier est inaccessible. Fermez l autre instance puis relancez.' }
    try {
        if ([IO.File]::Exists($script:DataPath)) { $script:Store = Read-Store }
        else {
            $script:Store = [pscustomobject]@{ schema=1; user=$UserName; records=@(); events=@() }
            Write-AtomicText $script:DataPath ($script:Store | ConvertTo-Json -Depth 15)
        }
    } catch { $script:StoreLock.Dispose(); throw }
}
function Add-Event([string]$Action, [string]$Reference, [string]$Detail, $Before = $null, $After = $null) {
    $event = [pscustomobject]@{ id=[guid]::NewGuid().ToString(); at=[DateTimeOffset]::Now.ToString('o'); user=$script:UserName; action=$Action; reference=$Reference; detail=$Detail; before=$Before; after=$After }
    $script:Store.events = @($script:Store.events) + @($event)
}
function Save-Store {
    try { Write-AtomicText $script:DataPath ($script:Store | ConvertTo-Json -Depth 15) }
    catch {
        $problem = $_.Exception.Message
        $script:Store = Read-Store
        throw ('Enregistrement impossible. Aucune modification validee. Detail : ' + $problem)
    }
}
function Get-Field($Body, [string]$Name, [int]$Max = 200) {
    $property = $Body.PSObject.Properties[$Name]
    if ($null -eq $property) { return '' }
    if ($null -ne $property.Value -and $property.Value -isnot [string] -and $Name -ne 'revision') { throw ('Champ invalide : ' + $Name) }
    $value = ([string]$property.Value).Trim()
    if ($value.Length -gt $Max -or $value.Contains([char]0)) { throw ('Champ trop long ou invalide : ' + $Name) }
    return $value
}
function Require-Choice([string]$Value, [string[]]$Choices, [string]$Label) {
    if ($Choices -cnotcontains $Value) { throw ('Veuillez choisir une valeur valide pour : ' + $Label) }
}
function Get-Group([string]$Type) { if ($Type -eq 'SOLVA') { return 'solva' }; return 'standard' }
function Start-Record($Body) {
    $type = Get-Field $Body 'typology'; Require-Choice $type $script:Types 'Typologie'
    $channel = Get-Field $Body 'channel'; Require-Choice $channel @('Back-Office','Front-Office') 'Canal'
    $reference = Get-Field $Body 'reference' 150
    if (!$reference) { throw 'Veuillez saisir une reference dossier.' }
    $group = Get-Group $type
    $working = @($script:Store.records | Where-Object { !$_.archived -and (Get-Group $_.typology) -eq $group })
    if (@($working | Where-Object { !$_.end }).Count -gt 0) { throw 'Terminez le dossier en cours de cette liste avant d en demarrer un autre.' }
    if (@($working | Where-Object { $_.reference -ieq $reference }).Count -gt 0) { throw 'Cette reference existe deja dans la liste de travail. Archivez la liste avant un nouveau passage.' }
    $credit=''; $product=''; $solvability=''
    if ($type -eq 'SOLVA') { $solvability = Get-Field $Body 'solvability'; if (!$solvability) { throw 'Veuillez renseigner la solvabilite.' } }
    else {
        $credit = Get-Field $Body 'credit'; $product = Get-Field $Body 'product'
        $credits = @('AUG','OUV'); if ($type -eq 'ETUDEINC') { $credits = @('ETUDEINC','CLOSUIVI','INFOCLT','APPELCLT') }
        Require-Choice $credit $credits 'Type de credit'; Require-Choice $product $script:Products 'Type de produit'
    }
    $record = [pscustomobject]@{ id=[guid]::NewGuid().ToString(); revision=1; user=$script:UserName; typology=$type; channel=$channel; reference=$reference; credit=$credit; product=$product; solvability=$solvability; start=[DateTimeOffset]::Now.ToString('o'); end=''; signature=''; decision=''; solvaType=''; solvaDecision=''; comment=''; seconds=0.0; archived=$false }
    $script:Store.records = @($script:Store.records) + @($record)
    Add-Event 'Demarrage' $reference $type $null ($record | ConvertTo-Json -Compress)
    Save-Store
    return @{ id=$record.id }
}
function Finish-Record($Body) {
    $id = Get-Field $Body 'id'; $matches = @($script:Store.records | Where-Object { $_.id -eq $id })
    if ($matches.Count -ne 1) { throw 'Dossier introuvable. Actualisez la liste.' }
    $record = $matches[0]; $revision = Get-Field $Body 'revision'
    if ($revision -ne [string]$record.revision) { throw 'Ce dossier a change dans un autre onglet. Actualisez avant de poursuivre.' }
    $comment = Get-Field $Body 'comment' 4000
    $signature=''; $decision=''; $solvaType=''; $solvaDecision=''; $solvability=$record.solvability
    if ($record.typology -eq 'SOLVA') {
        $solvaType = Get-Field $Body 'solvaType'; $solvaDecision = Get-Field $Body 'solvaDecision'; $solvability=Get-Field $Body 'solvability'
        Require-Choice $solvaDecision @('OK','KO') 'Decision SOLVA'
        if ($solvaType) { Require-Choice $solvaType @('GRILLE','WEB','SOL_SIT_FAM') 'Type SOLVA' }
        if (!$solvability) { throw 'Veuillez renseigner la solvabilite.' }
    } else {
        $signature=Get-Field $Body 'signature'; $decision=Get-Field $Body 'decision'
        Require-Choice $signature @('SE','Papier') 'Signature'; Require-Choice $decision $script:Decisions 'Decision'
    }
    $before=$record | ConvertTo-Json -Compress; $action='Correction'
    if (!$record.end) {
        $now=[DateTimeOffset]::Now; $start=[DateTimeOffset]::Parse($record.start)
        if ($now -lt $start) { throw 'L horloge du poste precede l heure de debut du dossier. Corrigez l horloge avant de terminer.' }
        $record.end=$now.ToString('o'); $record.seconds=($now-$start).TotalSeconds; $action='Cloture'
    }
    $record.signature=$signature; $record.decision=$decision; $record.solvaType=$solvaType; $record.solvaDecision=$solvaDecision; $record.solvability=$solvability; $record.comment=$comment; $record.revision++
    Add-Event $action $record.reference $record.typology $before ($record | ConvertTo-Json -Compress)
    Save-Store
    return @{ id=$record.id }
}
function Archive-Records($Body) {
    $group=Get-Field $Body 'group'; Require-Choice $group @('standard','solva') 'Liste'
    $items=@($script:Store.records | Where-Object { !$_.archived -and (Get-Group $_.typology) -eq $group })
    if (@($items | Where-Object { !$_.end }).Count -gt 0) { throw 'La liste contient un dossier en cours. Terminez-le avant le vidage.' }
    foreach ($r in $items) { $r.archived=$true; $r.revision++ }
    Add-Event 'Archivage' '' ($group + ' : ' + $items.Count + ' dossier(s)')
    Save-Store
    return @{ message=($items.Count.ToString() + ' dossier(s) archives. Historique conserve.') }
}
function Get-CsvField($Value) {
    $s=[string]$Value
    # Neutralise les formules lors de l ouverture des CSV dans Excel.
    if ($s -match '^\s*[=+@-]' -or $s -match '^[\t\r\n]') { $s="'" + $s }
    return ('"' + $s.Replace('"','""') + '"')
}
function Get-CsvLine($Record) {
    $start=[DateTimeOffset]::Parse($Record.start).ToString('dd/MM/yyyy HH:mm:ss')
    $end=[DateTimeOffset]::Parse($Record.end).ToString('dd/MM/yyyy HH:mm:ss')
    # Excel VBA stockait une fraction de jour dans DMT ; meme unite ici.
    $dmt=([double]$Record.seconds / 86400.0).ToString('0.###############', [Globalization.CultureInfo]::GetCultureInfo('fr-FR'))
    if ($Record.typology -eq 'SOLVA') { $values=@($Record.user,$Record.typology,$start,$end,$Record.solvability,$Record.reference,$Record.solvaType,$Record.solvaDecision,$Record.comment,$dmt,$Record.channel) }
    else { $values=@($Record.user,$Record.typology,$start,$end,$Record.credit,$Record.product,$Record.reference,$Record.signature,$Record.decision,$Record.comment,$dmt,$Record.channel) }
    return (($values | ForEach-Object { Get-CsvField $_ }) -join ';')
}
function Export-Records {
    $complete=@($script:Store.records | Where-Object { $_.end })
    if (!$complete.Count) { return @{ message='Aucun dossier termine a exporter.'; files=@() } }
    $groups=@{}
    foreach ($r in $complete) {
        $family='OCAOCR'; if ($r.typology -eq 'SOLVA') { $family='SOLVA' }
        $month=[DateTimeOffset]::Parse($r.start).ToString('MM_yyyy')
        $key=$family + '/' + $month
        if (!$groups.ContainsKey($key)) { $groups[$key]=@() }
        $groups[$key]+=@($r)
    }
    $files=@()
    try {
        foreach ($key in ($groups.Keys | Sort-Object)) {
            $parts=$key.Split('/'); $folder=Join-Path $script:ExportRoot $parts[0]
            [IO.Directory]::CreateDirectory($folder) | Out-Null
            $path=Join-Path $folder ($script:UserKey + '_' + $parts[1] + '_WEB.csv')
            $header='Collaborateur;Typologies;Date debut;Date fin;Type Credit;type Produit;Référence dossier;Type Signature;Decision;Commentaire;DMT;CANAL'
            if ($parts[0] -eq 'SOLVA') { $header='Collaborateur;Typologies;Date debut;Date fin;Solvabilité;Référence de dossier;Type;Décision;Commentaire;Dmt;CANAL' }
            $lines=@($header) + @($groups[$key] | Sort-Object start,id | ForEach-Object { Get-CsvLine $_ })
            Write-AtomicText $path (($lines -join "`r`n") + "`r`n")
            $files+=@($path)
        }
    } catch { throw ('Export incomplet (' + $files.Count + ' fichier(s) ecrit(s)). Vos dossiers sont conserves ; relancez l export apres correction du chemin ou des droits. ' + $_.Exception.Message) }
    Add-Event 'Export CSV' '' ($complete.Count.ToString() + ' dossier(s), ' + $files.Count + ' fichier(s)')
    Save-Store
    return @{ message=($complete.Count.ToString() + ' dossier(s) exportes. Les fichiers WEB sont regeneres sans doublons ; les CSV VBA restent intacts.'); files=@($files) }
}
function Backup-Store {
    $folder=Join-Path $script:UserDirectory 'sauvegardes'; [IO.Directory]::CreateDirectory($folder) | Out-Null
    $path=Join-Path $folder ('dossiers_' + (Get-Date -Format 'yyyyMMdd_HHmmss_fff') + '_' + [guid]::NewGuid().ToString('N').Substring(0,6) + '.json')
    [IO.File]::Copy($script:DataPath,$path,$false)
    return @{ path=$path }
}
