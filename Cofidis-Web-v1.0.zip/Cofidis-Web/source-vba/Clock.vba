Attribute VB_Name = "Clock"
Public runclock As Double
Sub StartClock()
With UserForm1.lblDate
.Caption = Format(Now, "dddd, mmmm dd, yyyy")
.AutoSize = True
End With

With UserForm1.lblHeure
.Caption = Format(Now, "h:mm:ss AM/PM")
.AutoSize = True
End With
runclock = Now + TimeSerial(0, 0, 1)
Application.OnTime runclock, "StartClock", , True
End Sub
Sub StopClock()
Application.OnTime runclock, "StartClock", , False
End Sub

