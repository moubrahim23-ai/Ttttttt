'use strict';
const assert = require('node:assert/strict');
const d = require('../www/domain.js');
assert.deepEqual(d.credits('ETUDEINC'), ['ETUDEINC', 'CLOSUIVI', 'INFOCLT', 'APPELCLT']);
assert.deepEqual(d.credits('N2'), ['AUG', 'OUV']);
assert.equal(d.duration(90061), '25:01:01');
const rows = [
  { id: '1', typology: 'N1', reference: '000123', channel: 'Back-Office', start: '2026-10-08T09:00:00+01:00', end: '', seconds: 0, archived: false },
  { id: '2', typology: 'SOLVA', reference: 'ABC', channel: 'Front-Office', start: '2026-09-30T09:00:00+01:00', end: 'x', seconds: 120, archived: true },
  { id: '3', typology: 'N2', reference: '456', channel: 'Back-Office', start: '2026-10-08T10:00:00+01:00', end: 'x', seconds: 60, archived: false }
];
assert.equal(d.filter(rows, { active: true }).length, 2);
assert.equal(d.filter(rows, { type: 'SOLVA', search: 'abc' })[0].id, '2');
assert.equal(d.filter(rows, { from: '2026-10-01', to: '2026-10-08', status: 'done' })[0].id, '3');
assert.equal(d.filter(rows, { channel: 'Front-Office' }).length, 1);
assert.deepEqual(d.stats(rows), { total: 3, open: 1, done: 2, mean: 90 });
assert.equal(d.stats([]).mean, null);
console.log('Tests JavaScript : OK');
