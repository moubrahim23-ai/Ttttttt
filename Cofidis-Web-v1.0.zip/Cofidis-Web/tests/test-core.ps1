﻿# Tests isoles : aucune donnee de production et aucun acces au partage metier.
$ErrorActionPreference='Stop'
. (Join-Path (Split-Path $PSScriptRoot -Parent) 'core.ps1')
function Assert($Condition,[string]$Message) { if (!$Condition) { throw ('ECHEC : ' + $Message) } }
function Must-Fail([scriptblock]$Action,[string]$Message) { $failed=$false; try { & $Action | Out-Null } catch { $failed=$true }; Assert $failed $Message }
$testRoot=Join-Path ([IO.Path]::GetTempPath()) ('Cofidis-test-' + [guid]::NewGuid().ToString('N'))
try {
    Initialize-Store (Join-Path $testRoot 'data') (Join-Path $testRoot 'exports') 'TEST_COFIDIS'
    $new=[pscustomobject]@{typology='N1';channel='Back-Office';reference='000123';credit='AUG';product='AUG ACC'}
    $start=Start-Record $new
    Assert ($script:Store.records.Count -eq 1) 'Creation'
    Must-Fail { Start-Record $new } 'Deux dossiers standard en cours interdits'
    Must-Fail { Archive-Records ([pscustomobject]@{group='standard'}) } 'Archivage en cours interdit'
    $finish=[pscustomobject]@{id=$start.id;revision=1;signature='SE';decision='OCA';comment="Texte; avec `"guillemets`"`net retour"}
    Finish-Record $finish | Out-Null
    $end=$script:Store.records[0].end
    Assert ($end -ne '') 'Cloture'
    Must-Fail { Finish-Record $finish } 'Revision obsolete rejetee'
    $finish.revision=2; $finish.comment='Correction'; Finish-Record $finish | Out-Null
    Assert ($script:Store.records[0].end -eq $end) 'Correction sans changement de duree'
    Must-Fail { Start-Record $new } 'Doublon reference interdit'
    $export=Export-Records
    $first=[IO.File]::ReadAllText($export.files[0]); Export-Records | Out-Null
    Assert ($first -eq [IO.File]::ReadAllText($export.files[0])) 'Export idempotent'
    $csv=Import-Csv -LiteralPath $export.files[0] -Delimiter ';' -Encoding UTF8
    Assert ($csv.'Référence dossier' -eq '000123') 'Reference conservee en texte dans CSV'
    Archive-Records ([pscustomobject]@{group='standard'}) | Out-Null
    $again=Start-Record $new
    Assert ($again.id -ne $start.id) 'Nouveau passage avec identifiant distinct'
    $solva=Start-Record ([pscustomobject]@{typology='SOLVA';channel='Front-Office';reference='S1';solvability='Analyse'})
    Finish-Record ([pscustomobject]@{id=$solva.id;revision=1;solvaType='GRILLE';solvaDecision='OK';solvability='Validee';comment='=1+1'}) | Out-Null
    $result=Export-Records
    Assert ($result.files.Count -eq 2) 'Exports des deux familles'
    $solvaFile=@($result.files | Where-Object { $_ -like '*SOLVA*' })[0]
    $solvaCsv=Import-Csv -LiteralPath $solvaFile -Delimiter ';' -Encoding UTF8
    Assert ($solvaCsv.Commentaire -eq "'=1+1") 'Formule CSV neutralisee'
    Assert ($solvaCsv.Solvabilité -eq 'Validee') 'Modification solvabilite propagee a l export'
    Assert ((Read-Store).records.Count -eq 3) 'Persistance'
    $backup=Backup-Store; Assert ([IO.File]::Exists($backup.path)) 'Sauvegarde'
    # Un mois distinct doit produire un fichier distinct, quelle que soit la locale du poste.
    $script:Store.records[0].start='2025-12-31T23:00:00+01:00'
    $months=Export-Records
    Assert (@($months.files | Where-Object { $_ -like '*12_2025_WEB.csv' }).Count -eq 1) 'Partition mensuelle'
    Write-Host 'TOUS LES TESTS POWERSHELL SONT VALIDES.' -ForegroundColor Green
} finally {
    if ($null -ne $script:StoreLock) { $script:StoreLock.Dispose() }
    if (Test-Path -LiteralPath $testRoot) { Remove-Item -LiteralPath $testRoot -Recurse -Force }
}
