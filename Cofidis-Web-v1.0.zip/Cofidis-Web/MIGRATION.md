# Correspondance avec Cofidis.xlsm

Source analysée : classeur fourni le 8 octobre 2026. Les feuilles temp, extraction, temp_Solva et extraction_solva contiennent des en-têtes, sans dossiers. Aucun ancien CSV réseau n’a été fourni ou importé. Les macros n’ont pas été exécutées.

| VBA / comportement | Migration |
|---|---|
| UserForm1, initialisation | Interface française ; N1, N2, CHALLENGER, ETUDEINC, SOLVA |
| Crédit N1/N2/CHALLENGER | AUG, OUV |
| Crédit ETUDEINC | ETUDEINC, CLOSUIVI, INFOCLT, APPELCLT |
| Produits | AUG ACC, OUV ACC, AUG PART, OUV PSM, OUV PSM/PSM, OUV PSM d'AUG |
| Signature | SE, Papier |
| Décision standard | OCA, OCR, OCI, CPP, AUTDEJ, TRF FRD, TRF BL, DELEGATION, ABA, DEROGATION, DOSRISK ; doublon CPP retiré |
| SOLVA | Solvabilité libre ; GRILLE, WEB, SOL_SIT_FAM facultatifs ; OK/KO obligatoire à la clôture |
| Canal | Back-Office / Front-Office obligatoire |
| cmb_Ajouter_Click et log_*_Etape1 | Démarrage atomique ; identité Windows et date serveur ; un en cours par famille ; contrôle de référence dans la liste active |
| cmb_Terminer_Click et log_*_Etape2 | Clôture ou correction par identifiant unique ; signature/décision validées ; journal avant/après |
| RefreshListView / vue_Click | Tableau paginé et sélection par référence visible, identifiant technique unique |
| SearchData_REF/Cred/Type/Sign | Recherche libre de tous les champs, plus filtres typologie/canal/statut/dates ; SOLVA inclus |
| cmb_vider_Click | Archivage de la famille choisie, sans destruction des dossiers ; blocage si traitement en cours |
| cmb_Sauvegarder_Click / SauvegarderSolva | Export indépendant des deux familles, par utilisateur et mois, sans purge de la base |
| Clock / StartClock / StopClock | Horloge et chronomètre de sélection |
| temp et extraction distincts | Une source JSON persistante ; liste active et historique sont deux vues des mêmes dossiers |

## Corrections par rapport au code source

- La condition de visibilité VBA répète N1 et omet N2 : corrigée.
- La recherche de référence VBA n’exécute rien dans la branche SOLVA : corrigée.
- Le bouton d’export VBA abandonne avant SOLVA quand la feuille standard est vide : corrigé.
- Une référence réutilisée pouvait mettre à jour la première ligne d’extraction portant ce nom : identifiants uniques ajoutés.
- Une correction d’un dossier terminé ne remet plus son heure de fin à l’heure courante.
- Une correction de solvabilité est reflétée dans le CSV, au lieu de conserver la valeur initiale dans l’extraction.
- L’export VBA concatène les cellules sans échapper les caractères CSV : échappement ajouté.
- Le mois est calculé à partir de la date enregistrée, sans découpage d’un texte dépendant de la locale Windows.
- L’historique est conservé ; export répété sans ajout en double ; protection des anciennes sorties par suffixe WEB.

Les listes métier viennent des instructions AddItem du code VBA. Le formulaire a été reconstruit fonctionnellement ; son apparence n’est pas une reproduction graphique du UserForm Excel. La source originale du classeur reste inchangée.
