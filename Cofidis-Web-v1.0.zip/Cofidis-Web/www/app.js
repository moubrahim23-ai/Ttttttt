'use strict';
const $ = id => document.getElementById(id);
let state = { records: [], events: [] }, selected = null, mode = 'active', page = 0, busy = false, stopped = false;
const pageSize = 50;
function notice(message, error = false) { $('notice').hidden = false; $('notice').className = error ? 'error' : ''; $('notice').textContent = message; }
function fill(id, values, placeholder = 'Choisir…') { $(id).replaceChildren(new Option(placeholder, ''), ...values.map(v => new Option(v, v))); }
Object.entries(Cofidis.options).forEach(([id, values]) => fill(id, values));
fill('filterType', Cofidis.options.typology, 'Toutes');
$('typology').value = 'N1';
function toggleForm() {
  const solva = $('typology').value === 'SOLVA';
  $('standardStart').hidden = solva; $('standardEnd').hidden = solva;
  $('solvaStart').hidden = !solva; $('solvaEnd').hidden = !solva;
  fill('credit', Cofidis.credits($('typology').value));
  for (const id of ['credit', 'product']) $(id).required = !solva;
  $('solvability').required = solva;
  $('signature').required = !!selected && !solva;
  $('decision').required = !!selected && !solva;
  $('solvaDecision').required = !!selected && solva;
}
function resetForm() {
  const type = $('typology').value || 'N1', channel = $('channel').value;
  selected = null; $('recordForm').reset(); $('typology').value = type; $('channel').value = channel;
  for (const id of ['typology', 'channel', 'reference', 'credit', 'product', 'solvability']) $(id).disabled = false;
  $('completion').hidden = true; $('formTitle').textContent = 'Nouveau traitement'; $('submit').textContent = 'Démarrer le dossier';
  $('submit').disabled = busy || stopped; $('formHint').textContent = 'Le chronomètre démarre à l’enregistrement du dossier.';
  toggleForm(); render();
}
function selectRecord(id) {
  const r = state.records.find(x => x.id === id); if (!r) return;
  selected = r; $('typology').value = r.typology; toggleForm();
  for (const key of ['channel', 'reference', 'credit', 'product', 'solvability', 'signature', 'decision', 'solvaType', 'solvaDecision', 'comment']) $(key).value = r[key] || '';
  for (const key of ['typology', 'channel', 'reference', 'credit', 'product', 'solvability']) $(key).disabled = true;
  // The VBA permits updating SOLVA's solvability at completion.
  $('solvability').disabled = r.typology !== 'SOLVA';
  $('completion').hidden = false; $('formTitle').textContent = r.end ? 'Consulter / corriger' : 'Terminer le dossier';
  $('submit').textContent = r.end ? 'Enregistrer la correction' : 'Terminer le dossier';
  $('formHint').textContent = r.end ? 'La correction conserve les dates et la durée initiales.' : 'La durée inclut tout le temps écoulé depuis le démarrage, comme dans le VBA.';
  render();
}
async function api(path, data) {
  const response = await fetch('/api/' + path, { method: data === undefined ? 'GET' : 'POST', cache: 'no-store', headers: data === undefined ? {} : { 'Content-Type': 'application/json', 'X-Cofidis-Token': state.token }, body: data === undefined ? undefined : JSON.stringify(data) });
  const result = await response.json(); if (!response.ok) throw new Error(result.error || 'Erreur du serveur.'); return result;
}
async function refresh() {
  state = await api('state'); $('user').textContent = 'Bonjour, ' + state.user;
  $('storage').textContent = 'Données : ' + state.dataPath + ' · Exports : ' + state.exportRoot;
  if (selected) { const current = state.records.find(r => r.id === selected.id); if (!current) resetForm(); else selected = current; }
  render();
}
async function action(fn) {
  if (busy || stopped) return; busy = true;
  const controls = [...document.querySelectorAll('button')], previous = controls.map(b => b.disabled);
  controls.forEach(b => b.disabled = true);
  try { await fn(); } catch (e) { notice(e.message, true); }
  finally { busy = false; controls.forEach((b, i) => b.disabled = stopped || previous[i]); if (!stopped) render(); }
}
function filtered() { return Cofidis.filter(state.records, { active: mode === 'active', type: $('filterType').value, status: $('filterStatus').value, channel: $('filterChannel').value, from: $('dateFrom').value, to: $('dateTo').value, search: $('search').value.trim() }).sort((a, b) => b.start.localeCompare(a.start)); }
function dateText(s) { return s ? new Date(s).toLocaleString('fr-FR') : '—'; }
function cell(row, value) { const td = document.createElement('td'); td.textContent = value; row.append(td); return td; }
function render() {
  const items = filtered(), summary = Cofidis.stats(items);
  for (const k of ['total', 'open', 'done']) $(k).textContent = summary[k]; $('mean').textContent = summary.mean === null ? '—' : Cofidis.duration(summary.mean);
  const maxPage = Math.max(0, Math.ceil(items.length / pageSize) - 1); page = Math.min(page, maxPage);
  $('previous').disabled = busy || page === 0; $('next').disabled = busy || page >= maxPage;
  $('rows').replaceChildren();
  for (const r of items.slice(page * pageSize, (page + 1) * pageSize)) {
    const row = document.createElement('tr'); if (selected?.id === r.id) row.className = 'chosen';
    const ref = cell(row, ''), link = document.createElement('button'); link.textContent = r.reference; link.disabled = busy; link.addEventListener('click', () => selectRecord(r.id)); ref.append(link);
    const detail = document.createElement('small'); detail.textContent = r.typology === 'SOLVA' ? [r.solvability, r.solvaType].filter(Boolean).join(' · ') : [r.credit, r.product, r.signature].filter(Boolean).join(' · '); ref.append(detail);
    cell(row, r.typology); cell(row, r.channel); cell(row, dateText(r.start)); const status = cell(row, '');
    const badge = document.createElement('span'); badge.className = 'badge' + (r.end ? ' done' : ''); badge.textContent = r.end ? (r.archived ? 'Archivé' : 'Terminé') : 'En cours'; status.append(badge);
    cell(row, r.end ? Cofidis.duration(r.seconds) : Cofidis.duration((Date.now() - Date.parse(r.start)) / 1000)); cell(row, r.typology === 'SOLVA' ? r.solvaDecision : r.decision);
    $('rows').append(row);
  }
  if (!items.length) { const row = document.createElement('tr'), td = cell(row, 'Aucun dossier dans cette sélection.'); td.colSpan = 7; td.className = 'empty'; $('rows').append(row); }
  $('count').textContent = items.length + ' dossier(s) · Page ' + (page + 1) + ' / ' + (maxPage + 1);
  $('events').replaceChildren();
  for (const e of [...state.events].reverse().slice(0, 200)) { const li = document.createElement('li'); li.textContent = e.action + (e.reference ? ' · ' + e.reference : '') + (e.detail ? ' · ' + e.detail : ''); const meta = document.createElement('small'); meta.textContent = dateText(e.at) + ' · ' + e.user; li.append(meta); $('events').append(li); }
  tick();
}
function tick() { $('clock').textContent = new Date().toLocaleString('fr-FR'); $('timer').textContent = selected ? (selected.end ? Cofidis.duration(selected.seconds) : Cofidis.duration((Date.now() - Date.parse(selected.start)) / 1000)) : 'Prêt'; }
$('typology').addEventListener('change', toggleForm);
$('reset').addEventListener('click', resetForm);
$('recordForm').addEventListener('submit', e => { e.preventDefault(); action(async () => {
  const data = {}; for (const key of ['typology', 'channel', 'reference', 'credit', 'product', 'solvability', 'signature', 'decision', 'solvaType', 'solvaDecision', 'comment']) data[key] = $(key).value;
  const finishing = !!selected;
  if (selected) { data.id = selected.id; data.revision = selected.revision; }
  const result = await api(selected ? 'finish' : 'start', data); await refresh();
  if (finishing) resetForm(); else selectRecord(result.id);
  notice(finishing ? 'Dossier enregistré.' : 'Dossier démarré. Vous pouvez maintenant renseigner sa clôture.');
}); });
for (const id of ['search', 'filterType', 'filterStatus', 'filterChannel', 'dateFrom', 'dateTo']) $(id).addEventListener('input', () => { page = 0; render(); });
for (const [id, view] of [['activeTab', 'active'], ['historyTab', 'history'], ['journalTab', 'journal']]) $(id).addEventListener('click', () => {
  mode = view; page = 0; for (const tab of ['activeTab', 'historyTab', 'journalTab']) { $(tab).classList.toggle('selected', tab === id); $(tab).setAttribute('aria-pressed', String(tab === id)); }
  $('recordsView').hidden = view === 'journal'; $('journalView').hidden = view !== 'journal'; render();
});
$('previous').addEventListener('click', () => { page--; render(); }); $('next').addEventListener('click', () => { page++; render(); });
$('refresh').addEventListener('click', () => action(async () => { await refresh(); notice('Données actualisées.'); }));
$('export').addEventListener('click', () => action(async () => { const r = await api('export', {}); await refresh(); notice(r.message + (r.files?.length ? '\n' + r.files.join('\n') : '')); }));
$('backup').addEventListener('click', () => action(async () => { const r = await api('backup', {}); notice('Sauvegarde créée : ' + r.path); }));
$('archive').addEventListener('click', () => { if (confirm('Archiver la liste choisie ? Les dossiers restent consultables dans l’historique. Un dossier en cours bloque le vidage.')) action(async () => { const r = await api('archive', { group: $('archiveGroup').value }); resetForm(); await refresh(); notice(r.message); }); });
$('shutdown').addEventListener('click', () => { if (confirm('Arrêter le serveur local ? Les dossiers sont déjà enregistrés. Un dossier en cours reprendra avec sa durée écoulée au prochain lancement.')) action(async () => { await api('shutdown', {}); stopped = true; notice('Application arrêtée. Vous pouvez fermer cet onglet. Pour reprendre, relancez lancer.bat.'); }); });
toggleForm(); setInterval(tick, 1000); action(refresh);
