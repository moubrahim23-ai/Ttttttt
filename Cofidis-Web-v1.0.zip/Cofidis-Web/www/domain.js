(function (root) {
  'use strict';
  const options = {
    typology: ['N1', 'N2', 'CHALLENGER', 'ETUDEINC', 'SOLVA'],
    product: ['AUG ACC', 'OUV ACC', 'AUG PART', 'OUV PSM', 'OUV PSM/PSM', "OUV PSM d'AUG"],
    signature: ['SE', 'Papier'],
    decision: ['OCA', 'OCR', 'OCI', 'CPP', 'AUTDEJ', 'TRF FRD', 'TRF BL', 'DELEGATION', 'ABA', 'DEROGATION', 'DOSRISK'],
    solvaType: ['GRILLE', 'WEB', 'SOL_SIT_FAM'], solvaDecision: ['OK', 'KO']
  };
  function credits(type) { return type === 'ETUDEINC' ? ['ETUDEINC', 'CLOSUIVI', 'INFOCLT', 'APPELCLT'] : ['AUG', 'OUV']; }
  function duration(seconds) { const n = Math.max(0, Math.floor(seconds || 0)); return [Math.floor(n / 3600), Math.floor(n / 60) % 60, n % 60].map(v => String(v).padStart(2, '0')).join(':'); }
  function filter(records, f) {
    return records.filter(r => (!f.active || !r.archived) && (!f.type || r.typology === f.type) && (!f.channel || r.channel === f.channel) && (!f.status || (f.status === 'done' ? !!r.end : !r.end)) && (!f.from || r.start.slice(0, 10) >= f.from) && (!f.to || r.start.slice(0, 10) <= f.to) && (!f.search || Object.values(r).join(' ').toLocaleLowerCase('fr').includes(f.search.toLocaleLowerCase('fr'))));
  }
  function stats(records) { const done = records.filter(r => r.end); return { total: records.length, open: records.length - done.length, done: done.length, mean: done.length ? done.reduce((s, r) => s + r.seconds, 0) / done.length : null }; }
  const api = { options, credits, duration, filter, stats };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.Cofidis = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
