# Cofidis Web — migration du classeur Cofidis.xlsm

Application locale HTML / CSS / JavaScript avec serveur PowerShell. Version 1.0 de migration, à valider sur un poste Windows avant utilisation en production.

## Démarrage

1. Extraire entièrement le ZIP dans un dossier où vous avez le droit d’écrire, par exemple `C:\Outils\Cofidis-Web`.
2. Double-cliquer sur **lancer.bat**. Garder la fenêtre PowerShell ouverte.
3. Le navigateur ouvre `http://localhost:8091`. Si l’onglet ne s’ouvre pas, saisir cette adresse dans Edge ou Chrome.
4. Pour fermer proprement, utiliser **Arrêter l’application** dans la page. Fermer seulement l’onglet ne ferme pas le serveur.

Commande alternative, depuis le dossier extrait :

```powershell
powershell.exe -NoProfile -File .\server.ps1
```

Si le port est occupé :

```powershell
powershell.exe -NoProfile -File .\server.ps1 -Port 8092
```

Le programme ne change pas la politique d’exécution Windows. Si Windows bloque le script téléchargé, faire vérifier/débloquer le dossier selon la procédure IT. Si HttpListener indique « Accès refusé », transmettre à l’IT l’URL exacte et le message ; une autorisation d’écoute HTTP locale peut être nécessaire. Ne pas lancer systématiquement sous un autre compte administrateur : l’identité enregistrée serait celle de ce compte.

## Utilisation

- **Démarrer** : choisir typologie et canal, saisir la référence, puis le crédit et le produit, ou la solvabilité pour SOLVA. La date et l’identité Windows viennent du serveur.
- **Terminer** : cliquer sur la référence, remplir signature et décision, ou décision SOLVA et type facultatif, puis terminer.
- **Corriger** : sélectionner un dossier terminé et enregistrer sa décision ou son commentaire corrigé. Les dates de traitement et la durée restent inchangées. La solvabilité peut être corrigée pour SOLVA.
- **Rechercher** : recherche libre, typologie, canal, statut et intervalle de dates de début. Les indicateurs suivent les filtres. La liste est paginée par 50 dossiers.
- **Vider la liste** : choisir standard ou SOLVA. L’application archive les dossiers terminés ; elle refuse tant qu’un dossier de cette famille est en cours. Les données restent dans « Tout l’historique ».
- **Exporter** : génère tous les CSV mensuels des dossiers terminés, quelle que soit la sélection à l’écran. SOLVA peut être exporté seul. Les dossiers en cours restent enregistrés mais ne sont pas exportés.
- **Sauvegarder** : crée une copie datée de l’ensemble des données et du journal de l’utilisateur.

Comme dans le VBA, une seule référence peut être en cours dans la famille standard (N1, N2, CHALLENGER, ETUDEINC), et une dans SOLVA. Une même référence peut être reprise après archivage ; chaque passage possède son propre identifiant.

La durée correspond à **fin − début**, sans déduction des pauses. Un arrêt du serveur ou du poste ne met pas le chronomètre en pause. La durée à l’écran est en heures:minutes:secondes ; le calcul enregistré est effectué par PowerShell. Ne pas modifier l’horloge pendant un traitement.

## Données et fonctionnement à plusieurs collaborateurs

L’adresse localhost est propre à chaque poste. Chaque collaborateur lance son serveur sous sa session Windows ; ce n’est pas un serveur central accessible par IP.

Les données sont enregistrées dans `data\<utilisateur_et_identifiant>\dossiers.json`. Chaque modification crée aussi `dossiers.json.bak`, copie de la version précédente. Un verrou empêche deux instances de modifier simultanément le même fichier. Plusieurs onglets sont possibles ; les révisions évitent de clôturer avec un formulaire devenu obsolète.

Avec des copies locales de l’application, les données restent sur chaque poste. Pour retrouver les mêmes données depuis plusieurs postes, l’IT peut configurer un `DataRoot` partagé stable et des permissions adaptées. Un même collaborateur ne doit lancer qu’une instance à la fois sur ce répertoire. Le verrou partagé doit être vérifié sur votre infrastructure SMB. Ne pas travailler sur deux copies de données indépendantes pour le même utilisateur puis exporter vers le même emplacement : la seconde pourrait remplacer les CSV de la première.

Le serveur écoute seulement sur localhost. Il n’utilise aucun service Internet, aucune API distante, aucun CDN, aucune bibliothèque à télécharger, ni Excel, ni Node.js. Il accède au disque et, si configuré, au partage réseau interne. Les permissions de fichiers restent celles de Windows ; ce programme n’ajoute pas de contrôle d’accès manager ni de protection contre la modification manuelle des fichiers par une personne qui dispose des droits d’écriture.

## Configuration des exports

Par défaut, les exports de test sont dans `exports\OCAOCR` et `exports\SOLVA`. Pour utiliser le partage relevé dans le VBA, arrêter l’application et modifier `ExportRoot` dans `config.json` :

```json
"ExportRoot": "\\\\UEIDSTU1.cm-cic.fr\\COFIDIS_TC\\COFIDIS_CSV"
```

Les doubles antislashs sont nécessaires en JSON. `NetworkExportExample` est une information ; seul `ExportRoot` est utilisé. L’accès au partage exige vos droits Windows habituels. `DataRoot` peut rester local. Si vous changez DataRoot, déplacer aussi les données existantes, serveur arrêté, afin de ne pas démarrer une base vide.

Les fichiers sont nommés `<utilisateur_et_identifiant>_MM_AAAA_WEB.csv`. L’identifiant dans le nom distingue les noms qui deviendraient identiques après suppression des caractères interdits. Le mois est celui du début de traitement. Les deux familles ont les mêmes intitulés et ordre de colonnes que les feuilles d’extraction VBA. Les CSV sont en UTF-8 avec BOM et séparateur point-virgule.

Le champ Collaborateur reprend le nom Windows comme `Environ("USERNAME")` dans le VBA. DMT reste une **fraction de jour**, avec virgule décimale, pour préserver la convention Excel. Dans Power Query, utiliser la locale française pour le nombre puis, si souhaité, multiplier par 24 pour les heures, par 1440 pour les minutes ou par 86400 pour les secondes. Importer les références comme **texte** pour garder les zéros initiaux ; ouvrir directement le CSV dans Excel peut entraîner une conversion automatique.

Chaque export régénère les fichiers WEB depuis les données conservées : cliquer deux fois n’ajoute pas de doublons. Les commentaires contenant point-virgule, guillemets ou retours à la ligne sont protégés selon le format CSV ; les débuts de formules sont neutralisés par une apostrophe.

Les anciens CSV VBA sont conservés. Au passage en production, fixer une date de bascule et adapter la source Power Query pour éviter de compter le même traitement dans les anciens et nouveaux fichiers. Les fichiers `.bak` ne doivent pas être inclus dans les requêtes CSV. Ne pas effacer l’historique JSON après export : il sert à régénérer les fichiers. Une erreur d’export peut laisser certains mois déjà mis à jour ; corriger l’accès puis relancer, sans risque d’ajout en double.

## Sauvegarde et restauration

Les sauvegardes manuelles se trouvent dans `data\<utilisateur_et_identifiant>\sauvegardes`. Pour restaurer : arrêter le serveur, copier le fichier courant en lieu sûr, puis remplacer `dossiers.json` par la sauvegarde choisie du même utilisateur. Ne pas restaurer une ancienne version sans tenir compte des traitements saisis depuis : ils seraient absents de cette version. Une sauvegarde sur le même disque ne protège pas contre une panne du disque ; intégrer le dossier de données aux sauvegardes habituelles.

## Vérifications réalisées et recette Windows

Réalisé dans l’environnement de création : extraction et lecture des modules VBA, contrôle des feuilles de données (vides), validation syntaxique JavaScript, tests automatisés des filtres, durées et indicateurs, contrôle de cohérence des identifiants HTML/JS et revue du serveur.

**Limite de validation : PowerShell et un navigateur exécutable ne sont pas disponibles dans cet environnement. Le serveur PowerShell, l’affichage réel et l’accès au partage n’y ont donc pas été exécutés.** La première validation sur votre poste Windows reste nécessaire ; la livraison ne constitue pas une homologation de production.

Un test PowerShell isolé est fourni ; il écrit uniquement dans un dossier temporaire qu’il nettoie ensuite :

```powershell
powershell.exe -NoProfile -File .\tests\test-core.ps1
```

Il vérifie notamment les doublons, les dossiers en cours, les révisions, les exports, les formules CSV, la correction SOLVA, les sauvegardes et la séparation par mois.

Recette recommandée avec la configuration locale par défaut :

1. Démarrer un N1 de test ; vérifier qu’un deuxième dossier standard est bloqué.
2. Le terminer avec signature SE et décision OCA, puis corriger le commentaire.
3. Démarrer et terminer un SOLVA ; contrôler les champs et les recherches.
4. Exporter deux fois et vérifier un seul exemplaire de chaque ligne, dans les deux familles.
5. Arrêter puis relancer : retrouver les dossiers, leur historique et leurs durées.
6. Archiver une liste et reprendre la même référence : contrôler deux passages distincts dans l’historique.
7. Une fois les essais validés, utiliser un DataRoot et un ExportRoot de production séparés des essais, avant tout branchement Power Query.

## Contenu du dossier

- `server.ps1` : serveur HTTP local et routes.
- `core.ps1` : validations, données, journal et exports.
- `www\index.html`, `style.css`, `app.js`, `domain.js` : interface et calculs d’affichage.
- `config.json`, `lancer.bat` : réglages et lancement.
- `tests` : tests locaux ; Node est seulement utile au développeur pour le test JavaScript, jamais au lancement de l’application.
- `MIGRATION.md` et `source-vba` : correspondance fonctionnelle et code extrait de l’original pour traçabilité.
