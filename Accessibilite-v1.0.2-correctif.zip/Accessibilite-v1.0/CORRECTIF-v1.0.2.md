# Correctif v1.0.2 : transactions sur dossier partage

Ce correctif remplace uniquement le mecanisme de sauvegarde du journal des
deplacements dans server.ps1. Il ne change pas les autorisations Windows.

## Installation sur les deux postes

1. Fermer les serveurs de l'application sur tous les postes utilisant cet espace.
2. Faire une copie de sauvegarde du dossier ACCESSIBILITE_TEST_COMMUN pendant
   cet arret, ainsi que des anciens scripts server.ps1 locaux.
3. Extraire ce ZIP dans un dossier distinct. Copier uniquement son server.ps1
   dans le dossier de l'application installee sur le poste manager ET sur celui
   de HAMDANI, en remplacant l'ancien server.ps1.
4. Conserver poste.json, TEST-DATA, TEST-FILES, SAUVEGARDES et tous les fichiers
   existants. Ne pas supprimer pending.json, les .tmp ou les dossiers staging.
5. Relancer d'abord le manager avec le mode partage habituel. La console doit
   afficher v1.0.2. Ne relancer l'agent qu'apres un demarrage sans erreur.
6. Verifier la liste des documents avant de refaire l'import une seule fois.

Ne pas utiliser un ancien serveur sur ce meme espace apres la mise a jour.
Une ancienne version ne sait pas lire les nouveaux points de reprise.

## Reprise de l'incident existant

Le fichier pending.json existant reste lisible. Si l'import n'a pas ete inscrit
dans l'etat de l'application, les deplacements deja effectues sont annules vers
staging, sans suppression des fichiers. Le PDF peut donc revenir d'Historique
vers staging : c'est la remise en coherence de l'import non termine.
Si la transaction est deja enregistree, ses deplacements sont conserves.
En cas de conflit entre source et destination, le serveur s'arrete avec une
erreur au lieu d'ecraser les fichiers. Conserver alors tous les fichiers.

## Modification technique et verification

Le premier manifeste pending.json est publie par renommage d'un temporaire.
Chaque mise a jour suivante est un nouveau fichier id-step-NNNNNNNNNNNN.json,
ecrit et vide sur disque avant renommage, sous le verrou partage existant.
La reprise lit le dernier point de reprise publie de la transaction active.
Les anciens points de reprise restent conserves apres finalisation.
L'appel File.Replace est retire de ce chemin d'execution. Les autorisations
ordinaires de creation et de renommage restent necessaires.
Les autres modules et leurs appels Replace ne sont pas modifies par ce correctif.

Relecture statique des chemins de commit, annulation et reprise effectuee.
PowerShell n'etant pas disponible dans l'environnement de preparation, aucune
execution PowerShell ni validation sur le partage professionnel n'est revendiquee.
Le test d'import sur vos postes reste a effectuer.
