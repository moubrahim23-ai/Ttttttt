param([string]$Root='\\UF11-A03\EIDS-EAA-PDF-STATIQUES\ACCESSIBILITE',[int]$Port=8090)
$ErrorActionPreference='Stop'
$base=Split-Path -Parent $MyInvocation.MyCommand.Path
$statuses=@('A TRAITER','EN COURS','TRAITES','NON CONFORME','A PUBLIER')
function Scan {
 if(!(Test-Path -LiteralPath $Root -PathType Container)){throw "Dossier inaccessible : $Root"}
 $items=New-Object System.Collections.Generic.List[object]
 $errors=New-Object System.Collections.Generic.List[string]
 $stack=New-Object 'System.Collections.Generic.Stack[string]';$stack.Push($Root)
 while($stack.Count -gt 0){
  $dir=$stack.Pop()
  try { $children=Get-ChildItem -LiteralPath $dir -Force -ErrorAction Stop } catch { $errors.Add("$dir : $($_.Exception.Message)");continue }
  foreach($c in $children){
   if($c.PSIsContainer){if(($c.Attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0){$stack.Push($c.FullName)}}
   $rel=$c.FullName.Substring($Root.TrimEnd('\').Length).TrimStart('\')
   $parts=$rel -split '\\'
   $entity=$parts[0];$status='HORS STATUT';$business='(racine)'
   for($i=1;$i -lt $parts.Length;$i++){
    $normalized=($parts[$i] -replace '[-_]',' ' -replace '\s+',' ').Trim().ToUpperInvariant()
    if($statuses -contains $normalized){$status=$normalized;if($i+1 -lt $parts.Length-1){$business=($parts[($i+1)..($parts.Length-2)] -join ' / ')};break}
   }
   $items.Add([pscustomobject]@{path=$rel;name=$c.Name;entity=$entity;status=$status;business=$business;kind=$(if($c.PSIsContainer){'folder'}else{'file'});extension=$(if($c.PSIsContainer){''}else{$c.Extension.ToLowerInvariant()});modified=$c.LastWriteTime.ToString('yyyy-MM-dd HH:mm')})
  }
 }
 return @{items=@($items.ToArray());errors=@($errors.ToArray());scanned=(Get-Date).ToString('yyyy-MM-dd HH:mm:ss');root=$Root}
}
function Audit($data){
 $pdfs=@($data.items | Where-Object {$_.kind -eq 'file' -and $_.extension -eq '.pdf' -and $_.status -eq 'TRAITES'})
 $all=@($data.items | Where-Object {$_.kind -eq 'file'})
 $index=@{};foreach($f in $all){$index[$f.path.ToLowerInvariant()]=$true}
 $issues=New-Object System.Collections.Generic.List[object]
 foreach($p in $pdfs){
  $folder=Split-Path $p.path -Parent
  $stem=[IO.Path]::GetFileNameWithoutExtension($p.name)
  $hasAudit=$false
  foreach($ext in @('.xlsx','.xlsm','.xls')){if($index.ContainsKey(($folder+'\'+$stem+$ext).ToLowerInvariant())){$hasAudit=$true;break}}
  if(!$hasAudit){$issues.Add([pscustomobject]@{entity=$p.entity;business=$p.business;document=$p.name;type='FICHE ABSENTE';detail='Aucune fiche Excel portant le même nom de base dans le même dossier';path=$p.path})}
 }
 $groups=$pdfs | Group-Object {($_.entity+'|'+$_.name).ToLowerInvariant()}
 foreach($g in $groups){if($g.Count -gt 1){foreach($p in $g.Group){$issues.Add([pscustomobject]@{entity=$p.entity;business=$p.business;document=$p.name;type='NOM REPETE';detail='Nom PDF présent plusieurs fois dans les TRAITES de cette entité (versions possibles)';path=$p.path})}}}
 return @{checked=$pdfs.Count;issues=@($issues.ToArray());scanned=$data.scanned;errors=$data.errors}
}
$listener=New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$Port/")
$listener.Start()
Write-Host "Application : http://localhost:$Port/" -ForegroundColor Green
Write-Host "Dossier : $Root";Write-Host 'Ctrl+C pour arreter.'
while($listener.IsListening){
 try{
  $ctx=$listener.GetContext();$path=$ctx.Request.Url.AbsolutePath
  $response=$ctx.Response;$response.Headers.Add('Cache-Control','no-store')
  if($path -eq '/api/scan' -or $path -eq '/api/audit'){
   try{$data=Scan;if($path -eq '/api/audit'){$data=Audit $data};$bytes=[Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $data -Depth 12 -Compress));$response.ContentType='application/json; charset=utf-8'}
   catch{$response.StatusCode=500;$bytes=[Text.Encoding]::UTF8.GetBytes((ConvertTo-Json @{error=$_.Exception.Message} -Compress));$response.ContentType='application/json; charset=utf-8'}
  }else{
   $filename=if($path -eq '/'){'index.html'}else{$path.TrimStart('/')}
   if($filename -notin @('index.html','style.css','app.js')){$response.StatusCode=404;$bytes=[byte[]]@()}
   else{$file=Join-Path $base $filename;$bytes=[IO.File]::ReadAllBytes($file);$response.ContentType=switch([IO.Path]::GetExtension($file)){'.css'{'text/css; charset=utf-8'}'.js'{'application/javascript; charset=utf-8'}default{'text/html; charset=utf-8'}}}
  }
  $response.ContentLength64=$bytes.Length;$response.OutputStream.Write($bytes,0,$bytes.Length);$response.Close()
 }catch{Write-Warning $_.Exception.Message}
}
