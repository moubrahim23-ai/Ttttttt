'use strict';
const entities=[['Bouygues Telecom',9],['CONTRATHEQUE',9],['CMO',4.5],['DIRCO',4.5],['ACM',9],['CMMABN',4.5],['DIRCOM',9],['MONABANQ',9],['CREATIS',9],['CIC CIB ASSET SERVICING',4.5],['COFIDIS France',9]];
const $=id=>document.getElementById(id);
const fmt=n=>Number(n.toFixed(2)).toLocaleString('fr-FR');
const num=id=>Math.max(0,Number($(id).value)||0);
const time=h=>{const m=Math.round(h*60);return `${Math.floor(m/60)} h ${String(m%60).padStart(2,'0')}`};
let result={};
entities.forEach(([name,dmt],i)=>{const tr=document.createElement('tr');tr.innerHTML=`<td>${name}</td><td><input type="number" min="0.1" step="0.5" value="${dmt}" id="dmt${i}" aria-label="DMT en heures ${name}"></td><td><input type="number" min="0" step="1" value="0" id="qty${i}" aria-label="Documents ${name}"></td><td><select id="priority${i}" aria-label="Priorité ${name}"><option value="2">Normale</option><option value="1">Haute</option><option value="0">Urgente</option></select></td><td><input type="number" min="1" step="1" id="maxAgents${i}" placeholder="Tous" aria-label="Agents maximum ${name}"></td><td><select id="assigned${i}" aria-label="Agent affecté ${name}"></select></td><td><input type="date" id="deadline${i}" aria-label="Échéance ${name}"></td><td id="load${i}">0 h</td><td id="day${i}">—</td><td id="capacity${i}">—</td><td id="month${i}">—</td>`;$('rows').appendChild(tr)});
function update(){const agents=Math.floor(num('agents')),planned=num('planned'),breaks=num('breaks'),productivity=num('productivity')/100,unavailable=num('unavailable');const perAgent=Math.max(0,planned-breaks/60),team=perAgent*agents,available=Math.max(0,team-unavailable),effective=available*productivity;const periods=[['Day',1/5],['Week',1],['Month',52/12]];periods.forEach(([suffix,mult])=>{ $('plan'+suffix).textContent=time(planned*mult);$('pause'+suffix).textContent=time(breaks/60*mult);$('net'+suffix).textContent=time(perAgent*mult);$('teamPlan'+suffix).textContent=time(planned*agents*mult);$('teamNet'+suffix).textContent=time(team*mult);});let documents=0,load=0;const lines=[];entities.forEach(([name,defaultDmt],i)=>{const dmt=num('dmt'+i),qty=Math.floor(num('qty'+i)),hours=qty*dmt;documents+=qty;load+=hours;$('load'+i).textContent=fmt(hours)+' h';$('day'+i).textContent=dmt>0?fmt(effective/5/dmt)+' équiv.':'—';$('capacity'+i).textContent=dmt>0?fmt(effective/dmt)+' équiv.':'—';$('month'+i).textContent=dmt>0?fmt(effective*52/12/dmt)+' équiv.':'—';lines.push({name,dmt,qty,hours,priority:Number($('priority'+i).value),maxAgents:Math.floor(num('maxAgents'+i))||agents,deadline:$('deadline'+i).value,assigned:$('assigned'+i).value})});const weeks=effective>0?load/effective:null;$('agentCapacity').textContent=time(perAgent);$('teamCapacity').textContent=time(team);$('effectiveCapacity').textContent=fmt(effective)+' h';$('documents').textContent=fmt(documents);$('load').textContent=fmt(load)+' h';$('weeks').textContent=load===0?'0':weeks===null?'Non calculable':fmt(weeks);$('totalDocs').textContent=fmt(documents);$('totalLoad').textContent=fmt(load)+' h';$('progressFill').style.width=(load>0?Math.min(100,effective/load*100):0)+'%';$('forecast').textContent=load===0?'Saisis des volumes pour afficher la prévision.':effective===0?'Aucune capacité disponible : vérifie les paramètres.':`Une semaine couvre ${fmt(Math.min(100,effective/load*100))} % de la charge. Prévoir environ ${Math.ceil(weeks)} semaine(s) de capacité, en supposant une charge constante et sans nouveaux dépôts.`;$('details').innerHTML=`<div class="detail"><span>Heures disponibles / semaine</span><strong>${fmt(available)} h</strong></div><div class="detail"><span>Productivité simulée</span><strong>${fmt(productivity*100)} %</strong></div><div class="detail"><span>Équivalent jours ouvrés (5 j / semaine)</span><strong>${weeks===null&&load>0?'—':fmt((weeks||0)*5)} j</strong></div><div class="detail"><span>Heures de charge restantes après 1 semaine</span><strong>${fmt(Math.max(0,load-effective))} h</strong></div>`;result={agents,planned,breaks,productivity:productivity*100,unavailable,perAgent,team,available,effective,documents,load,weeks,lines};renderSchedule()}
document.querySelectorAll('input').forEach(el=>el.addEventListener('input',update));$('reset').addEventListener('click',()=>{entities.forEach((e,i)=>{$('qty'+i).value=0;$('dmt'+i).value=e[1]});update()});$('print').addEventListener('click',()=>window.print());$('export').addEventListener('click',()=>{const r=result;const rows=[['Calculateur capacité Accessibilité PDF'],['Agents',r.agents],['Heures planifiées par agent',r.planned],['Pauses minutes par agent',r.breaks],['Productivité %',r.productivity],['Autres indisponibilités équipe',r.unavailable],['Heures planifiées / agent / jour',r.planned/5],['Heures planifiées / agent / semaine',r.planned],['Heures planifiées / agent / mois',r.planned*52/12],['Pauses / agent / jour',r.breaks/60/5],['Pauses / agent / semaine',r.breaks/60],['Pauses / agent / mois',r.breaks/60*52/12],['Heures nettes / agent / jour',r.perAgent/5],['Heures nettes / agent / semaine',r.perAgent],['Heures nettes / agent / mois',r.perAgent*52/12],['Heures planifiées / équipe / jour',r.planned*r.agents/5],['Heures planifiées / équipe / semaine',r.planned*r.agents],['Heures planifiées / équipe / mois',r.planned*r.agents*52/12],['Heures nettes / équipe / jour',r.team/5],['Heures nettes / équipe / semaine',r.team],['Heures nettes / équipe / mois',r.team*52/12],['Capacité équipe ajustée / lundi-jeudi (h)',r.effective* (8.25/(40+20/60))],['Capacité équipe ajustée / vendredi (h)',r.effective*((8-40/60)/(40+20/60))],['Capacité équipe ajustée / jour moyen (h)',r.effective/5],['Capacité équipe ajustée / semaine (h)',r.effective],['Capacité équipe ajustée / mois moyen (h)',r.effective*52/12],[],['Entité','DMT h','Documents','Charge théorique h','Capacité / jour équiv.','Capacité / semaine équiv.','Capacité / mois équiv.'],...r.lines.map(x=>[x.name,x.dmt,x.qty,x.hours,x.dmt?r.effective/5/x.dmt:0,x.dmt?r.effective/x.dmt:0,x.dmt?r.effective*52/12/x.dmt:0]),['TOTAL','',r.documents,r.load],['Semaines nécessaires','', '',r.weeks===null?'Non calculable':r.weeks]];const csv='\ufeff'+rows.map(row=>row.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(';')).join('\r\n');const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='capacite_accessibilite.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)});

// Planning prévisionnel local : allocation simultanée, priorité, échéance.
const pad=n=>String(n).padStart(2,'0');
const iso=d=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
const parseDate=s=>{const [y,m,d]=s.split('-').map(Number);return new Date(y,m-1,d)};
const addDays=(d,n)=>{const x=new Date(d);x.setDate(x.getDate()+n);return x};
const isWork=d=>d.getDay()!==0&&d.getDay()!==6;
const labelDate=d=>d.toLocaleDateString('fr-FR',{day:'2-digit',month:'short'});
const colors=['#dbeafe','#dcfce7','#fef3c7','#fce7f3','#e0e7ff','#ccfbf1','#fee2e2','#f3e8ff','#e2e8f0','#fae8ff','#cffafe'];
let reservations=[],schedules=[];
const startInput=$('startDate'),viewInput=$('viewDate');
function refreshAgentSelectors(){
 const count=Math.floor(num('agents'));
 entities.forEach((_,i)=>{const select=$('assigned'+i),old=select.value;select.innerHTML='<option value="">Choisir un agent</option>'+Array.from({length:count},(_,a)=>`<option value="${a+1}">Agent ${a+1}</option>`).join('');if(old && Number(old)<=count)select.value=old;});
}
refreshAgentSelectors();$('agents').addEventListener('change',()=>{refreshAgentSelectors();update()});
$('assignmentMode').addEventListener('change',renderSchedule);

startInput.value=iso(new Date());viewInput.value=startInput.value;
function computeSchedule(){
 const start=parseDate(startInput.value||iso(new Date())),agentCount=result.agents;
 const manual=$('assignmentMode').value==='manual';
 const jobs=result.lines.flatMap((x,i)=>Array.from({length:x.qty},(_,k)=>({
  ...x,index:i,docId:`${x.name} #${k+1}`,remaining:x.dmt,hours:x.dmt,
  agent:null,first:null,last:null
 }))).filter(x=>x.hours>0);
 const days=[];
 if(!agentCount||!result.effective)return {days,jobs,unfinished:jobs.length};
 const order=(a,b)=>a.priority-b.priority||(a.deadline||'9999').localeCompare(b.deadline||'9999')||a.index-b.index;
 const baseWeekly=4*8.25+(8-40/60);
 const factor=Math.max(0,result.effective/(agentCount*baseWeekly));
 const active=Array(agentCount).fill(null);
 const pending=[...jobs].sort(order);
 for(let offset=0;offset<3650 && jobs.some(j=>j.remaining>0.000001);offset++){
  const date=addDays(start,offset);if(!isWork(date))continue;
  const key=iso(date),capacity=(date.getDay()===5?8-40/60:8.25)*factor;
  const day={key,date,items:[]};
  for(let a=0;a<agentCount;a++){
   let free=capacity;
   while(free>0.000001){
    let job=active[a];
    if(!job){
     job=pending.find(j=>j.remaining>0.000001 && j.agent===null && (!manual || Number(j.assigned)===a+1));
     if(!job)break;
     job.agent=a+1;active[a]=job;
    }
    const h=Math.min(free,job.remaining);job.remaining=Math.max(0,job.remaining-h);free-=h;
    if(!job.first)job.first=key;job.last=key;
    let item=day.items.find(x=>x.index===job.index);
    if(!item){item={index:job.index,name:job.name,hours:0,agents:[],documents:[]};day.items.push(item)}
    item.hours+=h;if(!item.agents.includes(a+1))item.agents.push(a+1);
    item.documents.push({id:job.docId,agent:a+1,hours:h});
    if(job.remaining<0.000001)active[a]=null;
   }
  }
  if(day.items.length)days.push(day);
  if(manual && pending.every(j=>j.remaining<0.000001 || !j.assigned))break;
 }
 return {days,jobs,unfinished:jobs.filter(j=>j.remaining>0.000001).length};
}
function renderSchedule(){
 if(!result.lines)return;
 const plan=computeSchedule();reservations=plan.days;schedules=plan.jobs;
 const body=$('scheduleRows');body.innerHTML='';
 const docBody=$('documentRows');docBody.innerHTML='';
 for(const doc of plan.jobs){const tr=document.createElement('tr');
 [doc.docId,doc.agent?'Agent '+doc.agent:'Non affecté',doc.first||'—',doc.last||'—',fmt(doc.hours)+' h'].forEach(v=>{const td=document.createElement('td');td.textContent=v;tr.appendChild(td)});docBody.appendChild(tr)}
 for(const job of result.lines.map((line,i)=>{const docs=plan.jobs.filter(x=>x.index===i);return {...line,first:docs.map(x=>x.first).filter(Boolean).sort()[0],last:docs.map(x=>x.last).filter(Boolean).sort().slice(-1)[0],remaining:docs.reduce((n,x)=>n+x.remaining,0)}}).filter(x=>x.qty>0)){const tr=document.createElement('tr');const late=job.deadline&&job.last&&job.last>job.deadline;[job.name,job.first||'—',job.last||'—',fmt(job.hours)+' h',job.deadline||'—',job.remaining>0.001?'Non planifié':late?'Échéance dépassée':'Planifié'].forEach((v,i)=>{const td=document.createElement('td');td.textContent=v;if(i===5&&late)td.style.color='#b91c1c';tr.appendChild(td)});body.appendChild(tr)}
 const view=$('calendarView').value;let anchor=parseDate(viewInput.value||startInput.value);let from,to;
 if(view==='day'){from=anchor;to=anchor}else if(view==='week'){from=addDays(anchor,-((anchor.getDay()+6)%7));to=addDays(from,6)}else{from=new Date(anchor.getFullYear(),anchor.getMonth(),1);to=new Date(anchor.getFullYear(),anchor.getMonth()+1,0)}
 const root=$('calendar');root.innerHTML='';root.className='calendar '+view;
 const weekdays=['Lun','Mar','Mer','Jeu','Ven','Sam','Dim'];
 if(view==='month') weekdays.forEach(x=>{const head=document.createElement('div');head.className='weekday-title';head.textContent=x;root.appendChild(head)});
 if(view==='month'){const offset=(from.getDay()+6)%7;for(let i=0;i<offset;i++){const blank=document.createElement('div');blank.className='calblank';root.appendChild(blank)}}
 let displayed=0,used=0;
 for(let date=new Date(from);date<=to;date=addDays(date,1)){
  if(!isWork(date)&&view!=='month')continue;
  const day=reservations.find(x=>x.key===iso(date));const cell=document.createElement('div');cell.className='calday'+(!isWork(date)?' weekend':'');
  const head=document.createElement('div');head.className='calheading';
  const dateLabel=document.createElement('strong');dateLabel.textContent=date.toLocaleDateString('fr-FR',{weekday:'short',day:'numeric',month:view==='month'?undefined:'short'});head.appendChild(dateLabel);
  const capacity=result.agents>0?result.effective/result.agents*(date.getDay()===5? (8-40/60):(9-45/60))/(40+20/60)*result.agents:0;
  const usedDay=day?day.items.reduce((a,x)=>a+x.hours,0):0;
  const cap=document.createElement('span');cap.className='calcapacity';cap.textContent=isWork(date)?`${fmt(usedDay)} / ${fmt(capacity)} h`:'Repos';head.appendChild(cap);cell.appendChild(head);
  if(day){displayed++;for(const item of day.items){used+=item.hours;const chip=document.createElement('div');chip.className='calchip';chip.style.background=colors[item.index%colors.length];const name=document.createElement('strong');name.textContent=item.name;const meta=document.createElement('small');meta.textContent=`${fmt(item.hours)} h · ${item.documents.length} affectation(s) · agent(s) ${item.agents.join(", ")}`;chip.append(name,meta);chip.title=item.documents.map(d=>`${d.id} : ${fmt(d.hours)} h · agent ${d.agent}`).join("\n");cell.appendChild(chip)}}
  if(isWork(date)){const remain=document.createElement('div');remain.className='calremaining';remain.textContent=`${fmt(Math.max(0,capacity-usedDay))} h disponibles`;cell.appendChild(remain)}
  root.appendChild(cell)
 }
 $('scheduleSummary').textContent=`${displayed} jour(s) réservé(s) dans la période affichée · ${fmt(used)} h affectées · ${plan.unfinished} document(s) non planifié(s). Un document reste affecté à un seul agent. ${$('assignmentMode').value==='manual'?'Sélectionner un agent pour chaque entité avec des volumes.':'Répartition automatique.'}`;
}
[startInput,viewInput,$('calendarView')].forEach(el=>el.addEventListener('change',renderSchedule));
function shiftCalendar(direction){let d=parseDate(viewInput.value);const v=$('calendarView').value;if(v==='day')d=addDays(d,direction);else if(v==='week')d=addDays(d,7*direction);else d=new Date(d.getFullYear(),d.getMonth()+direction,Math.min(d.getDate(),28));viewInput.value=iso(d);renderSchedule()}
$('previous').addEventListener('click',()=>shiftCalendar(-1));$('next').addEventListener('click',()=>shiftCalendar(1));$('today').addEventListener('click',()=>{viewInput.value=iso(new Date());renderSchedule()});
$('exportCalendar').addEventListener('click',()=>{const rows=[['Date','Entité','Document','Agent','Heures réservées'],...reservations.flatMap(day=>day.items.flatMap(item=>item.documents.map(d=>[day.key,item.name,d.id,d.agent,d.hours.toFixed(2)])))];const csv='\ufeff'+rows.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(';')).join('\r\n');const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='planning_accessibilite.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)});
document.querySelectorAll('select[id^="priority"],input[id^="maxAgents"],input[id^="deadline"],select[id^="assigned"]').forEach(el=>el.addEventListener('change',update));
update();
