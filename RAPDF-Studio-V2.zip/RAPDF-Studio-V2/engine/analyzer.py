import fitz,re,hashlib,datetime

def inspect(path):
 d=fitz.open(path); elements=[]; stats={}; total=0
 for n,page in enumerate(d):
  blocks=[]
  for b in page.get_text('dict',sort=True)['blocks']:
   if b.get('type')!=0: continue
   lines=[]; sizes=[]; bold=False
   for line in b.get('lines',[]):
    spans=[s for s in line.get('spans',[]) if s.get('text','').strip()]
    if spans:
     lines.append(''.join(s['text'] for s in spans).strip());sizes += [s['size'] for s in spans];bold |= any('bold' in s['font'].lower() for s in spans)
   value=' '.join(lines).strip()
   if not value:continue
   blocks.append(dict(text=value,bbox=[round(v,1) for v in b['bbox']],size=max(sizes or [0]),bold=bold))
  stats[n+1]=len(blocks)
  for i,b in enumerate(blocks):
   s=b['text']; typ='P';confidence=.65
   if re.match(r'^\s*[-•–]\s+',s):typ='LI';confidence=.86
   elif re.match(r'^(?:\d+[.)]\s+)',s) and len(s)<150:typ='LI';confidence=.72
   elif re.search(r'Page\s+\d+\s*/\s*\d+',s,re.I) and b['bbox'][1]>page.rect.height*.84:typ='Artifact';confidence=.9
   elif len(s)<110 and (b['bold'] or b['size']>=13) and not s.endswith('.'):typ='H1' if b['size']>=15 else 'H2';confidence=.72
   elif len(s)<85 and not s.endswith(('.',',',';')) and b['size']>=10.5:typ='H2';confidence=.55
   elif b['bbox'][1]>page.rect.height*.80 and b['size']<9:typ='Note';confidence=.48
   total+=1
   elements.append(dict(id=f'p{n+1}-b{i+1}',page=n+1,text=s[:1200],bbox=b['bbox'],fontSize=round(b['size'],1),suggestion=typ,confidence=confidence))
  for j,im in enumerate(page.get_images(full=True)):
   total+=1;elements.append(dict(id=f'p{n+1}-img{j+1}',page=n+1,text='Image à examiner',bbox=[],fontSize=0,suggestion='Figure',confidence=.25))
 meta=d.metadata; catalog=d.pdf_catalog(); root=d.xref_get_key(catalog,'StructTreeRoot');mark=d.xref_get_key(catalog,'MarkInfo');lang=d.xref_get_key(catalog,'Lang')
 tagged=root[0]!='null' and root[1]!='null'; haslang=lang[0]!='null' and lang[1]!='null'
 checks=[{'id':'STRUCT','label':'Arbre de structure','state':'present' if tagged else 'missing','detail':str(root)}, {'id':'MARK','label':'Marquage PDF','state':'present' if mark[0]!='null' else 'missing','detail':str(mark)}, {'id':'LANG','label':'Langue du document','state':'present' if haslang else 'missing','detail':str(lang)}, {'id':'TITLE','label':'Titre des métadonnées','state':'present' if meta.get('title') else 'missing','detail':meta.get('title','')}, {'id':'ENCRYPT','label':'Chiffrement','state':'attention' if d.is_encrypted else 'clear','detail':'Document chiffré' if d.is_encrypted else 'Pas de chiffrement détecté'}]
 sha=hashlib.sha256(open(path,'rb').read()).hexdigest()
 return dict(file=path.split('/')[-1].split('\\')[-1],pages=len(d),sha256=sha,created=datetime.datetime.now().isoformat(timespec='seconds'),metadata=meta,checks=checks,elements=elements,tagged=tagged,counts=stats,limitations=['Propositions heuristiques, non validées par un humain','Aucune balise PDF n’est écrite par ce moteur','Aucune conformité RAPDF globale n’est déduite de ces tests'])

def fix_metadata(path,out,title,language):
 d=fitz.open(path)
 if d.is_encrypted:raise ValueError('Document chiffré')
 m=d.metadata;m['title']=title;d.set_metadata(m)
 if language:
  cat=d.pdf_catalog();d.xref_set_key(cat,'Lang',fitz.get_pdf_str(language))
 d.save(out,garbage=3,deflate=True);d.close()
 return inspect(out)
