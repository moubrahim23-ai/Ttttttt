import os,sys,json,uuid,urllib.parse,mimetypes,traceback
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
from engine.analyzer import inspect,fix_metadata
ROOT=Path(__file__).resolve().parent;DATA=ROOT/'data'; WEB=ROOT/'web'; MAX=30*1024*1024
for x in ['originaux','rapports','propositions','corriges']: (DATA/x).mkdir(parents=True,exist_ok=True)
class Handler(BaseHTTPRequestHandler):
 def send(self,status,body,typ='application/json'):
  if isinstance(body,(dict,list)):body=json.dumps(body,ensure_ascii=False).encode()
  elif isinstance(body,str):body=body.encode()
  self.send_response(status);self.send_header('Content-Type',typ+('; charset=utf-8' if typ.startswith(('text/','application/json')) else ''));self.send_header('Content-Length',str(len(body)));self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(body)
 def do_GET(self):
  url=urllib.parse.urlparse(self.path);p=url.path
  if p=='/api/sample':
   f=DATA/'rapports'/'exemple.json';return self.send(200,json.loads(f.read_text(encoding='utf8')))
  if p.startswith('/pdf/'):
   name=p[5:];f=DATA/'originaux'/name
   if f.name!=name or not f.is_file():return self.send(404,{'error':'Introuvable'})
   return self.send(200,f.read_bytes(),'application/pdf')
  if p.startswith('/web/'):f=(WEB/p[5:]).resolve()
  elif p=='/':f=WEB/'index.html'
  else:return self.send(404,{'error':'Introuvable'})
  if not f.is_relative_to(WEB.resolve()) or not f.is_file():return self.send(404,{'error':'Introuvable'})
  typ=mimetypes.guess_type(str(f))[0] or 'application/octet-stream';return self.send(200,f.read_bytes(),typ)
 def do_POST(self):
  try:
   size=int(self.headers.get('Content-Length','0'))
   if size<=0 or size>MAX:return self.send(413,{'error':'Taille non autorisée (max 30 Mo)'})
   if self.path=='/api/analyze':
    data=self.rfile.read(size)
    if not data.startswith(b'%PDF-'):return self.send(400,{'error':'Fichier non PDF'})
    key=uuid.uuid4().hex[:12];f=DATA/'originaux'/(key+'.pdf');f.write_bytes(data)
    report=inspect(str(f));report['key']=key
    (DATA/'rapports'/(key+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');return self.send(200,report)
   payload=json.loads(self.rfile.read(size));key=payload.get('key','')
   if not (len(key)==12 and all(c in '0123456789abcdef' for c in key)):return self.send(400,{'error':'Identifiant invalide'})
   source=DATA/'originaux'/(key+'.pdf')
   if not source.is_file():return self.send(404,{'error':'Original absent'})
   if self.path=='/api/proposal':
    elements=payload.get('elements',[])
    if len(elements)>10000 or not all(e.get('suggestion') in ('H1','H2','H3','H4','P','L','LI','Figure','Artifact','Note','Link','Table','TR','TH','TD') for e in elements):return self.send(400,{'error':'Proposition invalide'})
    dest=DATA/'propositions'/(key+'.json');dest.write_text(json.dumps({'key':key,'elements':elements,'validated':False,'note':'Structure proposée seulement; non intégrée au PDF'},ensure_ascii=False,indent=2),encoding='utf8');return self.send(200,{'ok':True,'path':str(dest)})
   if self.path=='/api/metadata':
    title=str(payload.get('title','')).strip()[:250];lang=str(payload.get('language','')).strip()
    if not title or lang not in ('fr-FR','en-US',''):return self.send(400,{'error':'Titre ou langue invalide'})
    dest=DATA/'corriges'/(key+'-metadonnees.pdf');result=fix_metadata(str(source),str(dest),title,lang)
    return self.send(200,{'ok':True,'path':str(dest),'checks':result['checks'],'note':'Métadonnées uniquement; PDF non balisé'})
   return self.send(404,{'error':'Route inconnue'})
  except Exception as e:return self.send(500,{'error':str(e)})
 def log_message(self,fmt,*args):print('%s %s'%(self.address_string(),fmt%args))
if __name__=='__main__':
 try:import fitz
 except ImportError:print('Installer PyMuPDF : py -m pip install pymupdf');sys.exit(2)
 print('RAPDF Studio V2 : http://127.0.0.1:8096');ThreadingHTTPServer(('127.0.0.1',8096),Handler).serve_forever()
