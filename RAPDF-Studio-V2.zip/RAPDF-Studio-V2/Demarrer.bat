@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (set "PY=py") else (set "PY=python")
%PY% -c "import fitz" >nul 2>nul
if errorlevel 1 (
 echo PyMuPDF est necessaire. Installer Python puis executer :
 echo py -m pip install pymupdf
 pause
 exit /b 1
)
start "" http://127.0.0.1:8096
%PY% server.py
pause
