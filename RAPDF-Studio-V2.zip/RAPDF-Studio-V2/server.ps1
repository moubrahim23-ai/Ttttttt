Set-Location $PSScriptRoot
if (Get-Command py -ErrorAction SilentlyContinue) { & py server.py }
elseif (Get-Command python -ErrorAction SilentlyContinue) { & python server.py }
else { Write-Host 'Python introuvable. Installer Python 3.10+ et PyMuPDF.' }
