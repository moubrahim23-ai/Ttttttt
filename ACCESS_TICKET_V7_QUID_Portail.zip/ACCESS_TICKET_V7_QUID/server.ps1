# ACCESS TICKET V7 - PORTAIL DE DEPOT - TEST LOCAL UNIQUEMENT
# Do not expose to other workstations before authentication and IT validation.
$ErrorActionPreference='Stop'
$base=Split-Path -Parent $MyInvocation.MyCommand.Path
$config=Get-Content (Join-Path $base 'config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$root=[IO.Path]::GetFullPath($config.root)
New-Item -ItemType Directory -Force -Path $root | Out-Null
$admin=Join-Path $root '_ACCESS_TICKET'
$orders=Join-Path $admin 'bons-commande'
$records=Join-Path $admin 'tickets'
@($admin,$orders,$records) | ForEach-Object { New-Item -ItemType Directory -Force -Path $_ | Out-Null }
function PdfEscape([string]$s) {
  $s=$s.Normalize([Text.NormalizationForm]::FormD)
  $s=[regex]::Replace($s,'\p{Mn}','')
  $s=[regex]::Replace($s,'[^\x20-\x7E]','?')
  return $s.Replace('\','\\').Replace('(','\(').Replace(')','\)')
}
function New-Pdf([string]$path,[string[]]$lines) {
  # PDF multipage ASCII (accents transliterated); 44 lines per page
  $pages=@(); $per=44
  for($start=0;$start -lt $lines.Count;$start+=$per){
    $end=[Math]::Min($lines.Count-1,$start+$per-1)
    $chunk=@($lines[$start..$end])
    $content="BT /F1 10 Tf 42 795 Td 16 TL `n"
    foreach($line in $chunk){
      $clean=PdfEscape ([string]$line)
      if($clean.Length -gt 95){$clean=$clean.Substring(0,95)}
      $content+='('+ $clean + ") Tj T*`n"
    }
    $content+="ET`n"
    $pages+=,$content
  }
  if($pages.Count -eq 0){$pages+=,"BT ET`n"}
  $objs=New-Object System.Collections.Generic.List[string]
  $objs.Add('<< /Type /Catalog /Pages 2 0 R >>')
  $kids=@(); for($i=0;$i -lt $pages.Count;$i++){$kids+=([string](4+2*$i)+' 0 R')}
  $objs.Add(('<< /Type /Pages /Kids ['+($kids -join ' ')+'] /Count '+$pages.Count+' >>'))
  $objs.Add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>')
  for($i=0;$i -lt $pages.Count;$i++){
    $pageId=4+2*$i; $streamId=$pageId+1
    $objs.Add("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents $streamId 0 R >>")
    $c=$pages[$i]
    $objs.Add("<< /Length $([Text.Encoding]::ASCII.GetByteCount($c)) >>`nstream`n$c`nendstream")
  }
  $pdf="%PDF-1.4`n"; $offsets=@(0)
  for($i=0;$i -lt $objs.Count;$i++){
    $offsets+= [Text.Encoding]::ASCII.GetByteCount($pdf)
    $pdf+="$($i+1) 0 obj`n$($objs[$i])`nendobj`n"
  }
  $xref=[Text.Encoding]::ASCII.GetByteCount($pdf)
  $pdf+="xref`n0 $($objs.Count+1)`n0000000000 65535 f `n"
  foreach($offset in ($offsets | Select-Object -Skip 1)){$pdf+=('{0:D10} 00000 n ' -f $offset)+"`n"}
  $pdf+="trailer << /Size $($objs.Count+1) /Root 1 0 R >>`nstartxref`n$xref`n%%EOF"
  [IO.File]::WriteAllBytes($path,[Text.Encoding]::ASCII.GetBytes($pdf))
}
function Reply($ctx,[int]$status,$data,[string]$mime='application/json; charset=utf-8') {
  $ctx.Response.StatusCode=$status
  $ctx.Response.ContentType=$mime
  $ctx.Response.Headers.Add('Cache-Control','no-store')
  $bytes=if($data -is [byte[]]){$data}else{[Text.Encoding]::UTF8.GetBytes([string]$data)}
  $ctx.Response.ContentLength64=$bytes.Length
  $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length)
  $ctx.Response.Close()
}
function Json($obj) { ConvertTo-Json -InputObject $obj -Depth 12 -Compress }
function CleanName([string]$s){
  $s=[IO.Path]::GetFileName($s)
  if($s -notmatch '^[^\\/:*?"<>|\x00-\x1f]{1,160}\.(pdf|doc|docx)$'){throw 'Nom ou extension de fichier non autorise'}
  return $s
}
function Save-JsonAtomic([string]$path,$value) {
  $tmp=$path+'.tmp-'+[guid]::NewGuid().ToString('N')
  [IO.File]::WriteAllText($tmp,(Json $value),(New-Object Text.UTF8Encoding($false)))
  Move-Item -LiteralPath $tmp -Destination $path -ErrorAction Stop
}
function New-Order([string]$id,[string]$pdf,$req,$fileList,[string]$now) {
  $lines=@('ACCESS TICKET - BON DE COMMANDE','',"Ticket : $id","Date : $now","Demandeur : $($req.requester)","Email : $($req.email)","Entite : $($req.entity)","Sous-entite : $($req.subentity)","Code section : $($req.section)","Objet : $($req.subject)","Mode : $($req.mode)","Quantite : $($fileList.Count)",'','DOCUMENTS :')
  $lines+=@($fileList | ForEach-Object {$_.name})
  New-Pdf $pdf $lines
}
$listener=New-Object Net.HttpListener
$listener.Prefixes.Add("http://localhost:$($config.port)/")
$listener.Start()
Write-Host "ACCESS TICKET V7 TEST : http://localhost:$($config.port)/"
try {
while($listener.IsListening){
  $ctx=$listener.GetContext()
  try {
    $path=$ctx.Request.Url.AbsolutePath
    if($ctx.Request.HttpMethod -eq 'GET' -and $path -eq '/'){
      Reply $ctx 200 ([IO.File]::ReadAllBytes((Join-Path $base 'index.html'))) 'text/html; charset=utf-8'; continue
    }
    if($ctx.Request.HttpMethod -eq 'GET' -and $path -in @('/style.css','/app.js')){
      $filename=$path.TrimStart('/')
      $mime=if($filename -eq 'style.css'){'text/css; charset=utf-8'}else{'application/javascript; charset=utf-8'}
      Reply $ctx 200 ([IO.File]::ReadAllBytes((Join-Path $base $filename))) $mime;continue
    }
    if($ctx.Request.HttpMethod -eq 'GET' -and $path -eq '/api/config'){
      Reply $ctx 200 (Json @{entities=$config.entities;maxFiles=$config.maxFiles;maxFileMB=$config.maxFileMB}); continue
    }
    if($ctx.Request.HttpMethod -eq 'GET' -and $path -eq '/api/history'){
      $items=@(Get-ChildItem -LiteralPath $records -Filter '*.json' -File | Sort-Object LastWriteTime -Descending | Select-Object -First 300 | ForEach-Object {try {Get-Content -LiteralPath $_.FullName -Raw -Encoding UTF8 | ConvertFrom-Json}catch{$null}} | Where-Object {$_ -ne $null})
      Reply $ctx 200 (Json @{items=$items});continue
    }
    if($ctx.Request.HttpMethod -eq 'GET' -and $path -match '^/api/order/(AT-[0-9]{8}-[0-9a-f]{12})$'){
      $id=$Matches[1]; $f=Join-Path $orders ($id+'.pdf')
      if(!(Test-Path -LiteralPath $f)){Reply $ctx 404 (Json @{error='Bon introuvable'});continue}
      $ctx.Response.Headers.Add('Content-Disposition',('attachment; filename="BC-'+$id+'.pdf"'))
      Reply $ctx 200 ([IO.File]::ReadAllBytes($f)) 'application/pdf';continue
    }
    if($ctx.Request.HttpMethod -ne 'POST' -or $path -ne '/api/deposit'){Reply $ctx 404 (Json @{error='Route inconnue'});continue}
    if($ctx.Request.ContentLength64 -lt 1 -or $ctx.Request.ContentLength64 -gt (1MB + [int64]$config.maxFiles*[int64]$config.maxFileMB*1400000)){throw 'Taille de requete invalide'}
    $reader=New-Object IO.StreamReader($ctx.Request.InputStream,[Text.Encoding]::UTF8)
    $req=$reader.ReadToEnd() | ConvertFrom-Json
    foreach($field in @('requester','section','entity','subentity','mode')){if([string]::IsNullOrWhiteSpace([string]$req.$field)){throw "Champ obligatoire: $field"}}
    if(([string]$req.requester).Length -gt 120 -or ([string]$req.section).Length -gt 80){throw 'Champ trop long'}
    if($req.mode -notin @('group','individual')){throw 'Mode invalide'}
    $entry=$null
    foreach($e in $config.entities){if($e.name -eq $req.entity){foreach($s in $e.subentities){if($s.name -eq $req.subentity){$entry=$s}}}}
    if($null -eq $entry){throw 'Entite/sous-entite non configuree'}
    $files=@($req.files)
    if($files.Count -lt 1 -or $files.Count -gt [int]$config.maxFiles){throw 'Nombre de fichiers invalide'}
    if(([string]$req.subject).Length -gt 240 -or ([string]$req.email).Length -gt 160){throw 'Objet ou email trop long'}
    $names=@{}; $validated=@()
    foreach($f in $files){
      $name=CleanName ([string]$f.name)
      if($names.ContainsKey($name.ToLowerInvariant())){throw 'Noms de fichiers en double'}
      $names[$name.ToLowerInvariant()]=$true
      $bytes=[Convert]::FromBase64String([string]$f.content)
      if($bytes.Length -lt 1 -or $bytes.Length -gt [int64]$config.maxFileMB*1MB){throw 'Fichier vide ou trop volumineux'}
      if($name.ToLowerInvariant().EndsWith('.pdf') -and $bytes.Length -ge 5){
        if([Text.Encoding]::ASCII.GetString($bytes,0,5) -ne '%PDF-'){throw "PDF invalide : $name"}
      }
      $validated+=@{name=$name;bytes=$bytes;size=$bytes.Length}
    }
    $entry=$null
    foreach($e in $config.entities){if($e.name -eq $req.entity){foreach($sub in $e.subentities){if($sub.name -eq $req.subentity){$entry=$sub}}}}
    if($null -eq $entry){throw 'Destination non configuree'}
    $targetRoot=[IO.Path]::GetFullPath((Join-Path $root ([string]$entry.relativePath)))
    if(!$targetRoot.StartsWith($root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Chemin non autorise'}
    $toProcess=Join-Path $targetRoot 'A TRAITER'
    if(!(Test-Path -LiteralPath $toProcess -PathType Container)){throw 'Repertoire A TRAITER absent'}
    $batches=@()
    if($req.mode -eq 'group'){$batches+=,@($validated)}else{foreach($file in $validated){$batches+=,@($file)}}
    $created=New-Object System.Collections.ArrayList
    $results=New-Object System.Collections.ArrayList
    try {
      foreach($batch in $batches){
        $id='AT-'+(Get-Date -Format yyyyMMdd)+'-'+[guid]::NewGuid().ToString('N').Substring(0,12)
        $final=Join-Path $toProcess $id
        $staging=Join-Path $toProcess ('.upload-'+$id)
        $pdf=Join-Path $orders ($id+'.pdf')
        $meta=Join-Path $records ($id+'.json')
        [void]$created.Add(@{staging=$staging;final=$final;pdf=$pdf;meta=$meta})
        New-Item -ItemType Directory -Path $staging -ErrorAction Stop | Out-Null
        foreach($file in $batch){[IO.File]::WriteAllBytes((Join-Path $staging $file.name),$file.bytes)}
        $now=(Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
        $record=@{id=$id;createdAt=$now;requester=[string]$req.requester;email=[string]$req.email;section=[string]$req.section;entity=[string]$req.entity;subentity=[string]$req.subentity;subject=[string]$req.subject;priority=[string]$req.priority;reference=[string]$req.reference;description=[string]$req.description;mode=[string]$req.mode;count=$batch.Count;files=@($batch | ForEach-Object {@{name=$_.name;size=$_.size}});path=$final;status='Depose'}
        New-Order $id $pdf $req $batch $now
        Save-JsonAtomic $meta $record
        Move-Item -LiteralPath $staging -Destination $final -ErrorAction Stop
        [void]$results.Add(@{id=$id;count=$batch.Count;orderUrl=('/api/order/'+$id)})
      }
      Reply $ctx 201 (Json @{tickets=@($results.ToArray());count=$validated.Count;mode=$req.mode})
    } catch {
      foreach($c in $created){
        foreach($key in @('staging','final')){if(Test-Path -LiteralPath $c[$key]){Remove-Item -LiteralPath $c[$key] -Recurse -Force -ErrorAction SilentlyContinue}}
        foreach($key in @('pdf','meta')){if(Test-Path -LiteralPath $c[$key]){Remove-Item -LiteralPath $c[$key] -Force -ErrorAction SilentlyContinue}}
      }
      throw
    }
  } catch {
    if($ctx.Response.OutputStream.CanWrite){Reply $ctx 400 (Json @{error=$_.Exception.Message})}
    Write-Warning $_.Exception.Message
  }
}
} finally {$listener.Stop();$listener.Close()}
